package com.example

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.model.SourceLanguage
import com.example.model.StudioSheet
import com.example.ui.components.ApiSettingsDialog
import com.example.ui.components.ExportOptionsDialog
import com.example.ui.components.ExportStatusDialog
import com.example.ui.components.GlossarySheet
import com.example.ui.components.MultiTrackTimeline
import com.example.ui.components.SrtEditorSheet
import com.example.ui.components.StudioTopBar
import com.example.ui.components.ValidationAlertDialog
import com.example.ui.components.VideoPreviewStage
import com.example.ui.components.VoiceoverSheet
import com.example.ui.components.WorkflowToolbar
import com.example.ui.theme.MatchaCutTheme
import com.example.ui.theme.MatchaGreenDark
import com.example.ui.theme.MatchaGreenDeep
import com.example.ui.theme.MatchaLightBg
import com.example.ui.theme.MatchaSurface
import com.example.ui.theme.PeachPink
import com.example.util.LocalAppStrings
import com.example.util.stringsForLanguage
import com.example.viewmodel.EditorViewModel
import kotlinx.coroutines.delay
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK)
        )
        setContent {
            MatchaCutTheme {
                MatchaCutStudioScreen()
            }
        }
    }
}

@Composable
fun MatchaCutStudioScreen(
    viewModel: EditorViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val appStrings = stringsForLanguage(uiState.appLanguage)

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build()
    }
    val voiceoverPlayer = remember {
        MediaPlayer()
    }
    val voiceoverPreparedPath = remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                viewModel.setPlaying(isPlaying)
                if (voiceoverPreparedPath.value != null && uiState.previewWithVoiceover) {
                    runCatching {
                        if (isPlaying) {
                            voiceoverPlayer.seekTo(exoPlayer.currentPosition.toInt())
                            voiceoverPlayer.start()
                        } else if (voiceoverPlayer.isPlaying) {
                            voiceoverPlayer.pause()
                        }
                    }
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    viewModel.setPlaying(false)
                    runCatching {
                        if (voiceoverPlayer.isPlaying) voiceoverPlayer.pause()
                    }
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            runCatching { voiceoverPlayer.release() }
        }
    }

    LaunchedEffect(uiState.videoMetadata?.uriString) {
        val uriStr = uiState.videoMetadata?.uriString
        if (uriStr != null) {
            exoPlayer.setMediaItem(MediaItem.fromUri(Uri.parse(uriStr)))
            exoPlayer.prepare()
            exoPlayer.seekTo(0L)
        } else {
            exoPlayer.clearMediaItems()
        }
    }

    LaunchedEffect(uiState.voiceoverWavPath) {
        val path = uiState.voiceoverWavPath
        if (path != null && File(path).exists()) {
            runCatching {
                voiceoverPlayer.reset()
                voiceoverPlayer.setDataSource(path)
                voiceoverPlayer.prepare()
                voiceoverPreparedPath.value = path
            }
        } else {
            runCatching { voiceoverPlayer.reset() }
            voiceoverPreparedPath.value = null
        }
    }

    LaunchedEffect(uiState.voiceoverWavPath, uiState.previewWithVoiceover) {
        val useVo = uiState.voiceoverWavPath != null && uiState.previewWithVoiceover
        exoPlayer.volume = if (useVo) 0f else 1f
        if (!useVo) {
            runCatching { if (voiceoverPlayer.isPlaying) voiceoverPlayer.pause() }
        } else if (exoPlayer.isPlaying && voiceoverPreparedPath.value != null) {
            runCatching {
                voiceoverPlayer.seekTo(exoPlayer.currentPosition.toInt())
                voiceoverPlayer.start()
            }
        }
    }

    LaunchedEffect(uiState.isPlaying) {
        while (uiState.isPlaying) {
            viewModel.updatePlaybackPosition(exoPlayer.currentPosition)
            delay(65L)
        }
    }

    LaunchedEffect(uiState.statusBanner) {
        val msg = uiState.statusBanner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.importVideo(uri)
        }
    }

    val importSrtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importSrtFromUri(uri)
        }
    }

    val pendingExportTranslated = remember { mutableStateOf(true) }

    val exportSrtLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri ->
        if (uri != null) {
            viewModel.exportSrtToUri(uri, useTranslatedIfAvailable = pendingExportTranslated.value)
        }
    }

    val saveMp4CopyLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("video/mp4")
    ) { uri ->
        if (uri != null) {
            viewModel.copyExportedMp4ToUri(uri)
        }
    }

    val launchVideoPicker = {
        videoPickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
        )
    }

    val launchSrtPicker = {
        importSrtLauncher.launch(
            arrayOf("application/x-subrip", "text/plain", "text/*", "application/octet-stream", "*/*")
        )
    }

    val seekTo: (Long) -> Unit = { targetMs ->
        exoPlayer.seekTo(targetMs)
        viewModel.updatePlaybackPosition(targetMs)
        if (voiceoverPreparedPath.value != null && uiState.previewWithVoiceover) {
            runCatching { voiceoverPlayer.seekTo(targetMs.toInt()) }
        }
    }

    CompositionLocalProvider(LocalAppStrings provides appStrings) {
        // Outer letterbox layout: ONLY top & bottom black bars, ZERO left/right black bars
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Top black letterbox bar (full width, no side padding)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .height(16.dp)
                    .testTag("top_black_letterbox")
            )

            // Full-width main MatchaCut studio UI (no left/right black bars)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Scaffold(
                    containerColor = MatchaLightBg,
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    topBar = {
                        StudioTopBar(
                            appLanguage = uiState.appLanguage,
                            workflowStep = uiState.workflowStep,
                            videoMetadata = uiState.videoMetadata,
                            onSelectAppLanguage = viewModel::setAppLanguage,
                            onOpenSettings = { viewModel.openSheet(StudioSheet.API_SETTINGS) },
                            onExportClick = { viewModel.openSheet(StudioSheet.EXPORT_OPTIONS) }
                        )
                    }
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(MatchaLightBg),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        AnimatedVisibility(visible = uiState.isBusy) {
                            Surface(
                                color = MatchaSurface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = uiState.busyLabel,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MatchaGreenDeep,
                                            modifier = Modifier.weight(1f)
                                        )
                                        uiState.busyProgress?.let { p ->
                                            Text(
                                                text = "${(p * 100).toInt()}%",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MatchaGreenDark
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    val progress = uiState.busyProgress
                                    if (progress != null) {
                                        LinearProgressIndicator(
                                            progress = { progress.coerceIn(0f, 1f) },
                                            color = PeachPink,
                                            trackColor = MatchaLightBg,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    } else {
                                        LinearProgressIndicator(
                                            color = PeachPink,
                                            trackColor = MatchaLightBg,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }

                        // 1. Top CapCut-style Video Preview Player + Below-Video Controls & Subtitle Preview
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState()),
                            contentAlignment = Alignment.Center
                        ) {
                            VideoPreviewStage(
                                exoPlayer = exoPlayer,
                                videoMetadata = uiState.videoMetadata,
                                isPlaying = uiState.isPlaying,
                                playbackPositionMs = uiState.playbackPositionMs,
                                cropBox = uiState.cropBox,
                                showOcrBox = uiState.showOcrBox,
                                activeSubtitle = uiState.activeSubtitleAtPlayhead,
                                hasVoiceover = uiState.voiceoverWavPath != null,
                                previewWithVoiceover = uiState.previewWithVoiceover,
                                onImportClick = launchVideoPicker,
                                onPlayPauseClick = {
                                    if (exoPlayer.isPlaying) {
                                        exoPlayer.pause()
                                    } else {
                                        if (exoPlayer.playbackState == Player.STATE_ENDED) {
                                            seekTo(0L)
                                        }
                                        exoPlayer.play()
                                    }
                                },
                                onCropBoxChange = viewModel::updateCropBox,
                                onResetCropBox = viewModel::resetCropBox,
                                onToggleOcrBox = viewModel::toggleOcrBoxVisibility,
                                onToggleVoiceoverPreview = viewModel::togglePreviewVoiceover,
                                onUpdateSegment = viewModel::updateSegment,
                                onUpdateSegmentTiming = viewModel::updateSegmentTiming,
                                onDeleteSegment = viewModel::deleteSegment
                            )
                        }

                        // 2. Middle Action Toolbar
                        WorkflowToolbar(
                            workflowStep = uiState.workflowStep,
                            isBusy = uiState.isBusy,
                            hasVideo = uiState.videoMetadata != null,
                            hasSubtitles = uiState.segments.isNotEmpty(),
                            isVoiceoverUnlocked = uiState.isVoiceoverUnlocked,
                            sourceLanguage = uiState.sourceLanguage,
                            targetLanguage = uiState.targetLanguage,
                            translationProvider = uiState.apiConfig.translationProvider,
                            onSelectSourceLanguage = viewModel::setSourceLanguage,
                            onSelectTargetLanguage = viewModel::setTargetLanguage,
                            onRunOcr = viewModel::runOcrExtraction,
                            onRunAudioSrt = viewModel::runAudioToSrt,
                            onImportSrt = launchSrtPicker,
                            onOpenSrtEditor = { viewModel.openSheet(StudioSheet.SRT_EDITOR) },
                            onOpenGlossary = { viewModel.openSheet(StudioSheet.GLOSSARY) },
                            onTranslateGemini = { viewModel.translateWithGemini(forceRetranslateAll = false) },
                            onOpenVoiceover = { viewModel.openSheet(StudioSheet.VOICEOVER) }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // 3. Bottom Multi-Track Timeline
                        MultiTrackTimeline(
                            videoMetadata = uiState.videoMetadata,
                            filmstrip = uiState.filmstrip,
                            segments = uiState.segments,
                            selectedSegmentIndex = uiState.selectedSegmentIndex,
                            activeTrack = uiState.activeTrack,
                            playbackPositionMs = uiState.playbackPositionMs,
                            isVoiceoverUnlocked = uiState.isVoiceoverUnlocked,
                            voiceoverVoiceName = uiState.voiceoverVoiceName,
                            voiceoverWaveformPeaks = uiState.voiceoverWaveformPeaks,
                            onSeek = seekTo,
                            onSelectTrack = viewModel::setActiveTrack,
                            onSelectSegment = { seg ->
                                viewModel.selectSegment(seg.index)
                                seekTo(seg.startMs)
                                viewModel.openSheet(StudioSheet.SRT_EDITOR)
                            },
                            onLockedVoiceoverClick = { viewModel.openSheet(StudioSheet.VOICEOVER) }
                        )
                    }
                }
            }

            // Bottom black letterbox bar (full width, no side padding)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .height(16.dp)
                    .testTag("bottom_black_letterbox")
            )
        }

        // Active sheets & dialogs
        when (uiState.activeSheet) {
            StudioSheet.API_SETTINGS -> {
                ApiSettingsDialog(
                    appLanguage = uiState.appLanguage,
                    currentConfig = uiState.apiConfig,
                    onSelectAppLanguage = viewModel::setAppLanguage,
                    onSave = viewModel::saveApiConfig,
                    onDismiss = viewModel::closeSheet
                )
            }

            StudioSheet.SRT_EDITOR -> {
                SrtEditorSheet(
                    segments = uiState.segments,
                    targetLanguage = uiState.targetLanguage,
                    onUpdateSegment = viewModel::updateSegment,
                    onUpdateSegmentTiming = viewModel::updateSegmentTiming,
                    onDeleteSegment = viewModel::deleteSegment,
                    onSeekToMs = { ms -> seekTo(ms) },
                    onImportSrtClick = launchSrtPicker,
                    onExportSrtClick = { useTranslated ->
                        pendingExportTranslated.value = useTranslated
                        val baseName = uiState.videoMetadata?.displayName
                            ?.substringBeforeLast('.')
                            ?.ifBlank { "subtitles" }
                            ?: "subtitles"
                        val suffix = if (useTranslated) "_${uiState.targetLanguage.code}" else "_src"
                        exportSrtLauncher.launch("${baseName}${suffix}.srt")
                    },
                    onOpenGlossary = { viewModel.openSheet(StudioSheet.GLOSSARY) },
                    onTranslateClick = { forceAll -> viewModel.translateWithGemini(forceRetranslateAll = forceAll) },
                    onDismiss = viewModel::closeSheet
                )
            }

            StudioSheet.GLOSSARY -> {
                GlossarySheet(
                    rules = uiState.glossaryRules,
                    onAddRule = viewModel::addGlossaryRule,
                    onToggleRule = viewModel::toggleGlossaryRule,
                    onDeleteRule = viewModel::deleteGlossaryRule,
                    onLoadStarterPreset = viewModel::loadStarterGlossaryPreset,
                    onDismiss = viewModel::closeSheet
                )
            }

            StudioSheet.VOICEOVER -> {
                VoiceoverSheet(
                    segments = uiState.segments,
                    selectedVoiceId = uiState.selectedVoiceId,
                    targetLanguage = uiState.targetLanguage,
                    apiConfig = uiState.apiConfig,
                    onSelectVoice = viewModel::setSelectedVoice,
                    onGenerateVoiceover = viewModel::generateVoiceover,
                    onOpenSettings = { viewModel.openSheet(StudioSheet.API_SETTINGS) },
                    onDismiss = viewModel::closeSheet
                )
            }

            StudioSheet.EXPORT_OPTIONS -> {
                ExportOptionsDialog(
                    initialConfig = uiState.exportConfig,
                    hasSubtitles = uiState.segments.isNotEmpty(),
                    hasVoiceover = uiState.voiceoverWavPath != null,
                    onStartExport = viewModel::startVideoExport,
                    onDismiss = viewModel::closeSheet
                )
            }

            StudioSheet.NONE -> Unit
        }

        ExportStatusDialog(
            exportState = uiState.exportState,
            onCancel = viewModel::cancelVideoExport,
            onSaveCopyAs = {
                val baseName = uiState.videoMetadata?.displayName
                    ?.substringBeforeLast('.')
                    ?.ifBlank { "matchacut_export" }
                    ?: "matchacut_export"
                saveMp4CopyLauncher.launch("${baseName}_dubbed.mp4")
            },
            onShareMp4 = { filePath ->
                val file = File(filePath)
                if (file.exists()) {
                    val shareUri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        file
                    )
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "video/mp4"
                        putExtra(Intent.EXTRA_STREAM, shareUri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Exported MP4"))
                }
            },
            onDismiss = viewModel::dismissExportResult
        )

        uiState.validationAlert?.let { alert ->
            ValidationAlertDialog(
                alert = alert,
                onFixToChinese = { viewModel.setSourceLanguage(SourceLanguage.CHINESE) },
                onTranslateNow = { viewModel.translateWithGemini(forceRetranslateAll = false) },
                onDismiss = viewModel::dismissValidationAlert
            )
        }
    }
}
