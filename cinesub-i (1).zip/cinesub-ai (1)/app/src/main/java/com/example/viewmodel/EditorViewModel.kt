package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SettingsRepository
import com.example.media.AudioSrtExtractor
import com.example.media.AudioSrtResult
import com.example.media.OcrExtractionResult
import com.example.media.OcrSubtitleExtractor
import com.example.media.VideoExportResult
import com.example.media.VideoExporter
import com.example.media.VideoInspector
import com.example.model.ActiveTrack
import com.example.model.ApiConfig
import com.example.model.AppLanguage
import com.example.model.ExportConfig
import com.example.model.ExportState
import com.example.model.ExtractionMethod
import com.example.model.FilmstripFrame
import com.example.model.GlossaryRule
import com.example.model.NormalizedRect
import com.example.model.SourceLanguage
import com.example.model.SrtSegment
import com.example.model.StudioSheet
import com.example.model.TargetLanguage
import com.example.model.TranslationProvider
import com.example.model.VideoMetadata
import com.example.model.WorkflowStep
import com.example.network.GeminiTranslator
import com.example.network.TranslationResult
import com.example.network.VoiceCatalog
import com.example.network.VoiceoverGenerator
import com.example.network.VoiceoverResult
import com.example.util.SanitationResult
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.example.util.stringsForLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ValidationAlert(
    val title: String,
    val message: String,
    val showLanguageFixButton: Boolean = false,
    val showTranslateActionButton: Boolean = false
)

data class EditorUiState(
    val appLanguage: AppLanguage = AppLanguage.VIETNAMESE,
    val workflowStep: WorkflowStep = WorkflowStep.EMPTY,
    val videoMetadata: VideoMetadata? = null,
    val filmstrip: List<FilmstripFrame> = emptyList(),
    val isPlaying: Boolean = false,
    val playbackPositionMs: Long = 0L,
    val cropBox: NormalizedRect = NormalizedRect(),
    val showOcrBox: Boolean = true,
    val sourceLanguage: SourceLanguage = SourceLanguage.CHINESE,
    val targetLanguage: TargetLanguage = TargetLanguage.VIETNAMESE,
    val extractionMethod: ExtractionMethod = ExtractionMethod.OCR,
    val segments: List<SrtSegment> = emptyList(),
    val selectedSegmentIndex: Int? = null,
    val activeTrack: ActiveTrack = ActiveTrack.VIDEO,
    val audioWaveformPeaks: List<Float> = emptyList(),
    val voiceoverWavPath: String? = null,
    val voiceoverWaveformPeaks: List<Float> = emptyList(),
    val voiceoverVoiceName: String? = null,
    val selectedVoiceId: String = "ngoc_huyen",
    val previewWithVoiceover: Boolean = true,
    val apiConfig: ApiConfig = ApiConfig(),
    val glossaryRules: List<GlossaryRule> = TextSanitizer.defaultStarterGlossary(),
    val exportConfig: ExportConfig = ExportConfig(),
    val exportState: ExportState = ExportState.Idle,
    val activeSheet: StudioSheet = StudioSheet.NONE,
    val isBusy: Boolean = false,
    val busyLabel: String = "",
    val busyProgress: Float? = null,
    val validationAlert: ValidationAlert? = null,
    val statusBanner: String? = null
) {
    val isVoiceoverUnlocked: Boolean
        get() = segments.isNotEmpty()

    val activeSubtitleAtPlayhead: SrtSegment?
        get() = segments.firstOrNull { playbackPositionMs in it.startMs..it.endMs }
            ?: segments.firstOrNull { it.index == selectedSegmentIndex }
}

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepo = SettingsRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepo.appLanguageFlow.collect { lang ->
                _uiState.update { it.copy(appLanguage = lang) }
            }
        }
        viewModelScope.launch {
            settingsRepo.apiConfigFlow.collect { cfg ->
                _uiState.update { it.copy(apiConfig = cfg) }
            }
        }
        viewModelScope.launch {
            settingsRepo.targetLanguageFlow.collect { lang ->
                _uiState.update { it.copy(targetLanguage = lang) }
            }
        }
        viewModelScope.launch {
            settingsRepo.selectedVoiceIdFlow.collect { voiceId ->
                _uiState.update { it.copy(selectedVoiceId = voiceId) }
            }
        }
        viewModelScope.launch {
            settingsRepo.glossaryRulesFlow.collect { rules ->
                _uiState.update { it.copy(glossaryRules = rules) }
            }
        }
    }

    fun setAppLanguage(language: AppLanguage) {
        _uiState.update { it.copy(appLanguage = language) }
        viewModelScope.launch { settingsRepo.saveAppLanguage(language) }
    }

    fun importVideo(uri: Uri) {
        val context = getApplication<Application>().applicationContext
        val strings = stringsForLanguage(_uiState.value.appLanguage)
        val keepPreloadedSrt = _uiState.value.videoMetadata == null && _uiState.value.segments.isNotEmpty()
        val preservedSegments = if (keepPreloadedSrt) _uiState.value.segments else emptyList()

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = strings.inspectingVideoBusy,
                    busyProgress = null,
                    validationAlert = null,
                    statusBanner = null
                )
            }
            try {
                val metadata = VideoInspector.inspect(context, uri)
                val frames = VideoInspector.extractFilmstrip(context, uri, metadata.durationMs, count = 12)
                _uiState.value.filmstrip.forEach { old ->
                    if (!old.bitmap.isRecycled) old.bitmap.recycle()
                }
                _uiState.update {
                    val nextStep = when {
                        preservedSegments.any { s -> s.translatedText.isNotBlank() } -> WorkflowStep.TRANSLATED
                        preservedSegments.isNotEmpty() -> WorkflowStep.SUBTITLES_EXTRACTED
                        else -> WorkflowStep.VIDEO_IMPORTED
                    }
                    it.copy(
                        workflowStep = nextStep,
                        videoMetadata = metadata,
                        filmstrip = frames,
                        playbackPositionMs = 0L,
                        isPlaying = false,
                        segments = preservedSegments,
                        selectedSegmentIndex = null,
                        audioWaveformPeaks = emptyList(),
                        voiceoverWavPath = null,
                        voiceoverWaveformPeaks = emptyList(),
                        voiceoverVoiceName = null,
                        activeTrack = if (preservedSegments.isNotEmpty()) ActiveTrack.SUBTITLE else ActiveTrack.VIDEO,
                        showOcrBox = true,
                        exportState = ExportState.Idle,
                        isBusy = false,
                        busyLabel = "",
                        statusBanner = "${metadata.displayName} (${metadata.resolutionLabel} · ${metadata.fpsLabel})"
                    )
                }
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        busyLabel = "",
                        validationAlert = ValidationAlert(
                            title = "Không thể nhập video",
                            message = t.message ?: "Không đọc được thông số từ file video đã chọn."
                        )
                    )
                }
            }
        }
    }

    fun importSrtFromUri(uri: Uri) {
        val context = getApplication<Application>().applicationContext
        viewModelScope.launch {
            val rawResult = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        stream.bufferedReader(Charsets.UTF_8).readText()
                    }.orEmpty()
                }
            }
            if (rawResult.isFailure) {
                _uiState.update {
                    it.copy(
                        validationAlert = ValidationAlert(
                            title = "Lỗi đọc file .SRT",
                            message = rawResult.exceptionOrNull()?.message ?: "Không thể mở file phụ đề đã chọn."
                        )
                    )
                }
                return@launch
            }

            val parsed = SrtUtils.parseSrtContent(rawResult.getOrThrow())
            if (parsed.isEmpty()) {
                _uiState.update {
                    it.copy(
                        validationAlert = ValidationAlert(
                            title = "File .SRT không hợp lệ",
                            message = "Không tìm thấy mốc thời gian chuẩn (HH:MM:SS,mmm --> HH:MM:SS,mmm) hoặc nội dung phụ đề trong file này."
                        )
                    )
                }
                return@launch
            }

            val alreadyTranslatedCount = parsed.count { it.translatedText.isNotBlank() }
            val nextStep = if (alreadyTranslatedCount == parsed.size) {
                WorkflowStep.TRANSLATED
            } else {
                WorkflowStep.SUBTITLES_EXTRACTED
            }

            _uiState.update {
                it.copy(
                    segments = parsed,
                    selectedSegmentIndex = parsed.firstOrNull()?.index,
                    workflowStep = nextStep,
                    activeTrack = ActiveTrack.SUBTITLE,
                    voiceoverWavPath = null,
                    voiceoverWaveformPeaks = emptyList(),
                    voiceoverVoiceName = null,
                    validationAlert = null,
                    statusBanner = "Đã nhập ${parsed.size} dòng phụ đề từ file .SRT!"
                )
            }
        }
    }

    fun updateCropBox(newBox: NormalizedRect) {
        _uiState.update { it.copy(cropBox = newBox.clamped()) }
    }

    fun resetCropBox() {
        _uiState.update { it.copy(cropBox = NormalizedRect()) }
    }

    fun toggleOcrBoxVisibility() {
        _uiState.update { it.copy(showOcrBox = !it.showOcrBox) }
    }

    fun setSourceLanguage(language: SourceLanguage) {
        _uiState.update { it.copy(sourceLanguage = language, validationAlert = null) }
    }

    fun setTargetLanguage(language: TargetLanguage) {
        _uiState.update { it.copy(targetLanguage = language) }
        viewModelScope.launch { settingsRepo.saveTargetLanguage(language) }
    }

    fun setSelectedVoice(voiceId: String) {
        _uiState.update { it.copy(selectedVoiceId = voiceId) }
        viewModelScope.launch { settingsRepo.saveSelectedVoiceId(voiceId) }
    }

    fun setActiveTrack(track: ActiveTrack) {
        _uiState.update { it.copy(activeTrack = track) }
    }

    fun updatePlaybackPosition(positionMs: Long) {
        _uiState.update { it.copy(playbackPositionMs = positionMs) }
    }

    fun setPlaying(playing: Boolean) {
        _uiState.update { it.copy(isPlaying = playing) }
    }

    fun selectSegment(index: Int?) {
        _uiState.update { it.copy(selectedSegmentIndex = index) }
    }

    fun dismissValidationAlert() {
        _uiState.update { it.copy(validationAlert = null) }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun openSheet(sheet: StudioSheet) {
        if (sheet == StudioSheet.VOICEOVER) {
            val state = _uiState.value
            val strings = stringsForLanguage(state.appLanguage)
            if (state.segments.isEmpty()) {
                _uiState.update {
                    it.copy(
                        validationAlert = ValidationAlert(
                            title = strings.voiceoverLockedTitle,
                            message = strings.voiceoverLockedMsg
                        )
                    )
                }
                return
            }
            if (TextSanitizer.validateSanitizedVoiceoverScript(state.segments) is SanitationResult.Blocked) {
                _uiState.update {
                    it.copy(
                        validationAlert = ValidationAlert(
                            title = "Cần dịch phụ đề sang ngôn ngữ đích",
                            message = "Phụ đề hiện tại vẫn còn chữ gốc chưa dịch. Bạn có muốn dịch ngay bằng Google Dịch (miễn phí) để tạo giọng đọc không?",
                            showTranslateActionButton = true
                        )
                    )
                }
                return
            }
        }
        _uiState.update { it.copy(activeSheet = sheet) }
    }

    fun closeSheet() {
        _uiState.update { it.copy(activeSheet = StudioSheet.NONE) }
    }

    fun saveApiConfig(config: ApiConfig) {
        _uiState.update { it.copy(apiConfig = config, statusBanner = "Đã lưu cài đặt Dịch thuật & Giọng đọc") }
        viewModelScope.launch { settingsRepo.saveApiConfig(config) }
    }

    // Glossary rule CRUD
    fun addGlossaryRule(sourceTerm: String, targetTerm: String) {
        val src = sourceTerm.trim()
        val dst = targetTerm.trim()
        if (src.isEmpty() || dst.isEmpty()) return
        val newRule = GlossaryRule(
            id = "g_${System.currentTimeMillis()}",
            sourceTerm = src,
            targetTerm = dst,
            enabled = true
        )
        val updated = listOf(newRule) + _uiState.value.glossaryRules.filterNot {
            it.sourceTerm.equals(src, ignoreCase = true)
        }
        _uiState.update { it.copy(glossaryRules = updated, statusBanner = "Đã thêm thuật ngữ: $src → $dst") }
        viewModelScope.launch { settingsRepo.saveGlossaryRules(updated) }
    }

    fun toggleGlossaryRule(id: String) {
        val updated = _uiState.value.glossaryRules.map {
            if (it.id == id) it.copy(enabled = !it.enabled) else it
        }
        _uiState.update { it.copy(glossaryRules = updated) }
        viewModelScope.launch { settingsRepo.saveGlossaryRules(updated) }
    }

    fun deleteGlossaryRule(id: String) {
        val updated = _uiState.value.glossaryRules.filterNot { it.id == id }
        _uiState.update { it.copy(glossaryRules = updated) }
        viewModelScope.launch { settingsRepo.saveGlossaryRules(updated) }
    }

    fun loadStarterGlossaryPreset() {
        val existingKeys = _uiState.value.glossaryRules.map { it.sourceTerm }.toSet()
        val missing = TextSanitizer.defaultStarterGlossary().filterNot { it.sourceTerm in existingKeys }
        val updated = _uiState.value.glossaryRules + missing
        _uiState.update { it.copy(glossaryRules = updated, statusBanner = "Đã nạp thêm ${missing.size} thuật ngữ mẫu") }
        viewModelScope.launch { settingsRepo.saveGlossaryRules(updated) }
    }

    // Step 2A: Upgraded ML Kit OCR with corner/watermark rejection & glitch healing
    fun runOcrExtraction() {
        val state = _uiState.value
        val metadata = state.videoMetadata ?: return
        val context = getApplication<Application>().applicationContext

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = "Đang tách & lọc nhiễu OCR (${state.sourceLanguage.displayName})...",
                    busyProgress = 0f,
                    extractionMethod = ExtractionMethod.OCR,
                    validationAlert = null,
                    statusBanner = null
                )
            }

            when (
                val result = OcrSubtitleExtractor.extractSubtitles(
                    context = context,
                    uri = Uri.parse(metadata.uriString),
                    durationMs = metadata.durationMs,
                    cropBox = state.cropBox,
                    sourceLanguage = state.sourceLanguage,
                    onProgress = { p ->
                        _uiState.update { it.copy(busyProgress = p) }
                    }
                )
            ) {
                is OcrExtractionResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            workflowStep = WorkflowStep.SUBTITLES_EXTRACTED,
                            segments = result.segments,
                            selectedSegmentIndex = result.segments.firstOrNull()?.index,
                            activeTrack = ActiveTrack.SUBTITLE,
                            voiceoverWavPath = null,
                            voiceoverWaveformPeaks = emptyList(),
                            voiceoverVoiceName = null,
                            statusBanner = "Đã tách ${result.segments.size} dòng phụ đề chuẩn (${result.chineseCharactersFound} ký tự Trung)"
                        )
                    }
                }

                is OcrExtractionResult.ValidationBlocked -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            showOcrBox = true,
                            validationAlert = ValidationAlert(
                                title = result.title,
                                message = result.message,
                                showLanguageFixButton = result.isWrongLanguageConfig
                            )
                        )
                    }
                }

                is OcrExtractionResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert("Lỗi tách OCR", result.message)
                        )
                    }
                }
            }
        }
    }

    // Step 2B: Real Audio-to-SRT speech recognition with missing-model warning
    fun runAudioToSrt() {
        val state = _uiState.value
        val metadata = state.videoMetadata ?: return
        val context = getApplication<Application>().applicationContext
        val strings = stringsForLanguage(state.appLanguage)

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = strings.decodingAudioBusy,
                    busyProgress = 0f,
                    extractionMethod = ExtractionMethod.AUDIO,
                    validationAlert = null,
                    statusBanner = null
                )
            }

            when (
                val result = AudioSrtExtractor.extractAudioSrt(
                    context = context,
                    uri = Uri.parse(metadata.uriString),
                    durationMs = metadata.durationMs,
                    sourceLanguage = state.sourceLanguage,
                    apiConfig = state.apiConfig,
                    onProgress = { p, label ->
                        _uiState.update { it.copy(busyProgress = p, busyLabel = label) }
                    }
                )
            ) {
                is AudioSrtResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            workflowStep = WorkflowStep.SUBTITLES_EXTRACTED,
                            segments = result.segments,
                            selectedSegmentIndex = result.segments.firstOrNull()?.index,
                            audioWaveformPeaks = result.waveformPeaks,
                            activeTrack = ActiveTrack.SUBTITLE,
                            voiceoverWavPath = null,
                            voiceoverWaveformPeaks = emptyList(),
                            voiceoverVoiceName = null,
                            statusBanner = "Nhận diện ${result.segments.size} câu thoại từ âm thanh"
                        )
                    }
                }

                is AudioSrtResult.MissingSpeechModel -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert(
                                title = strings.missingSpeechModelTitle,
                                message = result.message
                            )
                        )
                    }
                }

                is AudioSrtResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert("Lỗi tách Audio SRT", result.message)
                        )
                    }
                }
            }
        }
    }

    fun updateSegment(index: Int, originalText: String, translatedText: String) {
        _uiState.update { state ->
            val updated = state.segments.map { seg ->
                if (seg.index == index) {
                    seg.copy(originalText = originalText, translatedText = translatedText)
                } else {
                    seg
                }
            }
            val anyTranslated = updated.any { it.translatedText.isNotBlank() }
            state.copy(
                segments = updated,
                workflowStep = if (anyTranslated && state.workflowStep.stepNumber < WorkflowStep.TRANSLATED.stepNumber) {
                    WorkflowStep.TRANSLATED
                } else {
                    state.workflowStep
                }
            )
        }
    }

    fun updateSegmentTiming(index: Int, startMs: Long, endMs: Long) {
        val maxDur = _uiState.value.videoMetadata?.durationMs ?: Long.MAX_VALUE
        val safeStart = startMs.coerceIn(0L, maxDur)
        val safeEnd = endMs.coerceAtLeast(safeStart + 250L).coerceAtMost(maxDur)
        _uiState.update { state ->
            val updated = state.segments.map { seg ->
                if (seg.index == index) {
                    seg.copy(startMs = safeStart, endMs = safeEnd)
                } else {
                    seg
                }
            }
            state.copy(segments = updated)
        }
    }

    fun deleteSegment(index: Int) {
        _uiState.update { state ->
            val updated = state.segments
                .filterNot { it.index == index }
                .mapIndexed { idx, seg -> seg.copy(index = idx + 1) }
            state.copy(
                segments = updated,
                selectedSegmentIndex = updated.firstOrNull()?.index
            )
        }
    }

    fun translateWithGemini(forceRetranslateAll: Boolean = false) {
        val state = _uiState.value
        val strings = stringsForLanguage(state.appLanguage)
        if (state.segments.isEmpty()) {
            _uiState.update {
                it.copy(
                    validationAlert = ValidationAlert(
                        title = "Chưa có phụ đề",
                        message = "Vui lòng Tách OCR, Audio SRT hoặc Nhập file .SRT trước khi dịch."
                    )
                )
            }
            return
        }

        val hasPartial = state.segments.any { it.translatedText.isNotBlank() } &&
            state.segments.any { it.translatedText.isBlank() }
        val onlyUntranslated = !forceRetranslateAll && hasPartial

        val providerLabel = if (!state.apiConfig.translationProvider.requiresApiKey ||
            state.apiConfig.geminiApiKey.isBlank()
        ) {
            TranslationProvider.GOOGLE_TRANSLATE_FREE.displayName
        } else {
            state.apiConfig.translationProvider.displayName
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = "${strings.translatingBusyPrefix} ($providerLabel)...",
                    busyProgress = 0f,
                    validationAlert = null
                )
            }

            when (
                val result = GeminiTranslator.translateSrt(
                    apiConfig = state.apiConfig,
                    segments = state.segments,
                    targetLanguage = state.targetLanguage,
                    sourceLanguage = state.sourceLanguage,
                    glossaryRules = state.glossaryRules,
                    onlyUntranslated = onlyUntranslated,
                    onBatchProgress = { p, label ->
                        _uiState.update { it.copy(busyProgress = p, busyLabel = label) }
                    },
                    onPartialTranslated = { partialSegments ->
                        _uiState.update { current ->
                            current.copy(
                                segments = partialSegments,
                                activeTrack = ActiveTrack.SUBTITLE
                            )
                        }
                    }
                )
            ) {
                is TranslationResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            segments = result.translatedSegments,
                            workflowStep = WorkflowStep.TRANSLATED,
                            activeTrack = ActiveTrack.SUBTITLE,
                            statusBanner = "Đã dịch ${result.translatedSegments.size} dòng sang ${state.targetLanguage.displayName}!"
                        )
                    }
                }

                is TranslationResult.Error -> {
                    _uiState.update { current ->
                        val preserved = if (result.partialSegments.isNotEmpty()) {
                            result.partialSegments
                        } else {
                            current.segments
                        }
                        current.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            segments = preserved,
                            validationAlert = ValidationAlert(
                                title = "Sự cố dịch thuật ($providerLabel)",
                                message = result.message
                            )
                        )
                    }
                }
            }
        }
    }

    fun generateVoiceover() {
        val state = _uiState.value
        val strings = stringsForLanguage(state.appLanguage)
        if (state.segments.isEmpty()) {
            _uiState.update {
                it.copy(
                    validationAlert = ValidationAlert(
                        title = strings.voiceoverLockedTitle,
                        message = strings.voiceoverLockedMsg
                    )
                )
            }
            return
        }

        val totalDurationMs = state.videoMetadata?.durationMs
            ?: ((state.segments.maxOfOrNull { it.endMs } ?: 5_000L) + 1_000L)
        val voice = VoiceCatalog.findById(state.selectedVoiceId)
        val context = getApplication<Application>().applicationContext

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = "Đang tạo giọng đọc truyền cảm ${voice.name}...",
                    busyProgress = 0f,
                    activeSheet = StudioSheet.NONE,
                    validationAlert = null
                )
            }

            when (
                val result = VoiceoverGenerator.generateTimelineVoiceover(
                    context = context,
                    segments = state.segments,
                    totalVideoDurationMs = totalDurationMs,
                    voice = voice,
                    targetLanguage = state.targetLanguage,
                    apiConfig = state.apiConfig,
                    onProgress = { progress, label ->
                        _uiState.update { it.copy(busyProgress = progress, busyLabel = label) }
                    }
                )
            ) {
                is VoiceoverResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            segments = result.updatedSegments,
                            voiceoverWavPath = result.masterWavPath,
                            voiceoverWaveformPeaks = result.waveformPeaks,
                            voiceoverVoiceName = result.voiceName,
                            workflowStep = WorkflowStep.VOICEOVER_READY,
                            activeTrack = ActiveTrack.VOICEOVER,
                            previewWithVoiceover = true,
                            statusBanner = "Đã ghép giọng đọc ${result.voiceName} chuẩn nhịp vào Timeline!"
                        )
                    }
                }

                is VoiceoverResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert("Lỗi tạo giọng đọc", result.message)
                        )
                    }
                }
            }
        }
    }

    fun togglePreviewVoiceover() {
        _uiState.update { it.copy(previewWithVoiceover = !it.previewWithVoiceover) }
    }

    fun buildSrtForExport(useTranslatedIfAvailable: Boolean): String {
        val state = _uiState.value
        val hasTranslated = state.segments.any { it.translatedText.isNotBlank() }
        return SrtUtils.toSrtString(
            segments = state.segments,
            useTranslated = useTranslatedIfAvailable && hasTranslated
        )
    }

    fun exportSrtToUri(uri: Uri, useTranslatedIfAvailable: Boolean = true) {
        val context = getApplication<Application>().applicationContext
        val content = buildSrtForExport(useTranslatedIfAvailable = useTranslatedIfAvailable)
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                    true
                }.getOrDefault(false)
            }
            _uiState.update {
                it.copy(
                    statusBanner = if (ok) "Đã xuất file .SRT chuẩn UTF-8 thành công!" else "Không thể ghi file .SRT"
                )
            }
        }
    }

    fun startVideoExport(config: ExportConfig) {
        val state = _uiState.value
        val metadata = state.videoMetadata ?: return
        val context = getApplication<Application>().applicationContext

        _uiState.update {
            it.copy(
                exportConfig = config,
                activeSheet = StudioSheet.NONE,
                exportState = ExportState.Running(2, "Đang khởi tạo bộ mã hóa phần cứng Media3...")
            )
        }

        viewModelScope.launch {
            when (
                val res = VideoExporter.exportMp4(
                    context = context,
                    videoMetadata = metadata,
                    segments = state.segments,
                    voiceoverWavPath = state.voiceoverWavPath,
                    exportConfig = config,
                    onProgress = { pct, stage ->
                        _uiState.update {
                            it.copy(exportState = ExportState.Running(pct, stage))
                        }
                    }
                )
            ) {
                is VideoExportResult.Success -> {
                    _uiState.update {
                        it.copy(
                            exportState = ExportState.Completed(
                                outputPath = res.cacheFilePath,
                                mediaStoreUri = res.mediaStoreUri,
                                fileSizeBytes = res.fileSizeBytes
                            ),
                            statusBanner = "Xuất video MP4 thành công!"
                        )
                    }
                }

                is VideoExportResult.Failure -> {
                    _uiState.update {
                        it.copy(exportState = ExportState.Failed(res.message))
                    }
                }
            }
        }
    }

    fun cancelVideoExport() {
        VideoExporter.cancelExport()
        _uiState.update { it.copy(exportState = ExportState.Idle) }
    }

    fun dismissExportResult() {
        _uiState.update { it.copy(exportState = ExportState.Idle) }
    }

    fun copyExportedMp4ToUri(destUri: Uri) {
        val completed = _uiState.value.exportState as? ExportState.Completed ?: return
        val context = getApplication<Application>().applicationContext
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    File(completed.outputPath).inputStream().use { input ->
                        context.contentResolver.openOutputStream(destUri)?.use { output ->
                            input.copyTo(output, bufferSize = 64 * 1024)
                        }
                    }
                    true
                }.getOrDefault(false)
            }
            _uiState.update {
                it.copy(statusBanner = if (ok) "Đã lưu bản sao MP4" else "Không thể lưu bản sao MP4")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        _uiState.value.filmstrip.forEach { frame ->
            if (!frame.bitmap.isRecycled) frame.bitmap.recycle()
        }
    }
}
