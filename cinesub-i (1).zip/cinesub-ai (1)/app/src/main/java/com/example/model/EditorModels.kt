package com.example.model

import android.graphics.Bitmap

enum class AppLanguage(val code: String, val shortBadge: String, val displayName: String) {
    VIETNAMESE("vi", "VI", "Tiếng Việt (Mặc định)"),
    ENGLISH("en", "EN", "English"),
    CHINESE("zh", "中文", "中文 (简体)")
}

enum class WorkflowStep(val stepNumber: Int) {
    EMPTY(0),
    VIDEO_IMPORTED(1),
    SUBTITLES_EXTRACTED(2),
    TRANSLATED(3),
    VOICEOVER_READY(4)
}

enum class ExtractionMethod {
    OCR,
    AUDIO
}

enum class SourceLanguage(val displayName: String, val code: String, val bcp47: String) {
    CHINESE("Chinese (Default)", "zh", "zh-CN"),
    ENGLISH("English", "en", "en-US"),
    JAPANESE("Japanese", "ja", "ja-JP"),
    KOREAN("Korean", "ko", "ko-KR")
}

enum class TargetLanguage(val displayName: String, val code: String) {
    VIETNAMESE("Tiếng Việt", "vi"),
    ENGLISH("English", "en"),
    SPANISH("Español", "es"),
    FRENCH("Français", "fr"),
    JAPANESE("日本語", "ja"),
    KOREAN("한국어", "ko"),
    THAI("ไทย", "th"),
    INDONESIAN("Bahasa Indonesia", "id")
}

enum class TranslationProvider(
    val displayName: String,
    val defaultEndpoint: String,
    val defaultModel: String,
    val requiresApiKey: Boolean = true
) {
    GOOGLE_TRANSLATE_FREE(
        displayName = "Google Dịch (Miễn phí)",
        defaultEndpoint = "https://translate.googleapis.com/translate_a/single",
        defaultModel = "gtx",
        requiresApiKey = false
    ),
    GEMINI(
        displayName = "Google Gemini",
        defaultEndpoint = "https://generativelanguage.googleapis.com/v1beta",
        defaultModel = "gemini-2.5-flash"
    ),
    OPENAI(
        displayName = "OpenAI",
        defaultEndpoint = "https://api.openai.com/v1/chat/completions",
        defaultModel = "gpt-4o-mini"
    ),
    DEEPSEEK(
        displayName = "DeepSeek",
        defaultEndpoint = "https://api.deepseek.com/v1/chat/completions",
        defaultModel = "deepseek-chat"
    ),
    GROQ(
        displayName = "Groq",
        defaultEndpoint = "https://api.groq.com/openai/v1/chat/completions",
        defaultModel = "llama-3.3-70b-versatile"
    ),
    CUSTOM_OPENAI(
        displayName = "Custom OpenAI-Compatible",
        defaultEndpoint = "https://openrouter.ai/api/v1/chat/completions",
        defaultModel = "google/gemini-2.5-flash"
    )
}

data class GlossaryRule(
    val id: String,
    val sourceTerm: String,
    val targetTerm: String,
    val enabled: Boolean = true
)

data class NormalizedRect(
    val left: Float = 0.08f,
    val top: Float = 0.74f,
    val right: Float = 0.92f,
    val bottom: Float = 0.91f
) {
    val width: Float get() = (right - left).coerceAtLeast(0.08f)
    val height: Float get() = (bottom - top).coerceAtLeast(0.06f)

    fun clamped(): NormalizedRect {
        val l = left.coerceIn(0f, 0.90f)
        val t = top.coerceIn(0f, 0.92f)
        val r = right.coerceIn(l + 0.08f, 1f)
        val b = bottom.coerceIn(t + 0.06f, 1f)
        return NormalizedRect(l, t, r, b)
    }
}

data class VideoMetadata(
    val uriString: String,
    val displayName: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Float,
    val hasAudioTrack: Boolean,
    val fileSizeBytes: Long
) {
    val resolutionLabel: String get() = "${width}×${height}"
    val fpsLabel: String get() = String.format(java.util.Locale.US, "%.1f fps", fps)
}

data class SrtSegment(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val originalText: String,
    val translatedText: String = "",
    val voiceoverAudioPath: String? = null,
    val voiceoverDurationMs: Long = 0L
) {
    val displayText: String
        get() = translatedText.ifBlank { originalText }
}

data class VoiceOption(
    val id: String,
    val name: String,
    val language: String,
    val languageCode: String,
    val gender: String,
    val style: String,
    val apiVoiceCode: String,
    val pitch: Float = 1.0f,
    val speechRate: Float = 1.0f,
    val isFreeBuiltin: Boolean = true
)

enum class TtsPayloadPreset(val label: String) {
    OPENAI_COMPATIBLE("OpenAI /v1/audio/speech"),
    CUSTOM_JSON("Custom JSON {voice, text}"),
    ELEVENLABS_STYLE("ElevenLabs REST")
}

enum class TtsEngineMode {
    EXPRESSIVE_STORY_TTS,
    FREE_BUILTIN_TTS,
    CONFIGURABLE_API
}

data class ApiConfig(
    val translationProvider: TranslationProvider = TranslationProvider.GOOGLE_TRANSLATE_FREE,
    val translationEndpointUrl: String = TranslationProvider.GOOGLE_TRANSLATE_FREE.defaultEndpoint,
    val geminiApiKey: String = "",
    val geminiModel: String = TranslationProvider.GOOGLE_TRANSLATE_FREE.defaultModel,
    val translationBatchSize: Int = 5,
    val translationDelayMs: Long = 650L,
    val ttsEndpointUrl: String = "",
    val ttsApiKey: String = "",
    val ttsPayloadPreset: TtsPayloadPreset = TtsPayloadPreset.OPENAI_COMPATIBLE,
    val ttsEngineMode: TtsEngineMode = TtsEngineMode.EXPRESSIVE_STORY_TTS,
    val autoAlignVoiceTiming: Boolean = true
)

enum class ExportResolution(val label: String, val targetHeight: Int?) {
    P720("720p HD", 720),
    P1080("1080p Full HD", 1080),
    ORIGINAL("Original", null)
}

enum class ExportFps(val label: String, val fps: Int) {
    FPS_24("24 fps", 24),
    FPS_30("30 fps", 30),
    FPS_60("60 fps", 60)
}

data class ExportConfig(
    val resolution: ExportResolution = ExportResolution.P1080,
    val fps: ExportFps = ExportFps.FPS_30,
    val burnSubtitles: Boolean = true,
    val keepOriginalAudio: Boolean = false
)

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progressPercent: Int, val stageLabel: String) : ExportState
    data class Completed(
        val outputPath: String,
        val mediaStoreUri: String?,
        val fileSizeBytes: Long
    ) : ExportState
    data class Failed(val message: String) : ExportState
}

enum class ActiveTrack {
    VIDEO,
    SUBTITLE,
    VOICEOVER
}

enum class StudioSheet {
    NONE,
    SRT_EDITOR,
    GLOSSARY,
    VOICEOVER,
    API_SETTINGS,
    EXPORT_OPTIONS
}

data class FilmstripFrame(
    val timeMs: Long,
    val bitmap: Bitmap
)
