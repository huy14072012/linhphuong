package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import com.example.model.NormalizedRect
import com.example.model.SourceLanguage
import com.example.model.SrtSegment
import com.example.util.TextSanitizer
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

sealed interface OcrExtractionResult {
    data class Success(
        val segments: List<SrtSegment>,
        val sampledFrames: Int,
        val chineseCharactersFound: Int
    ) : OcrExtractionResult

    data class ValidationBlocked(
        val title: String,
        val message: String,
        val isWrongLanguageConfig: Boolean
    ) : OcrExtractionResult

    data class Error(val message: String) : OcrExtractionResult
}

object OcrSubtitleExtractor {

    private data class RawSample(val timeMs: Long, val text: String)

    suspend fun extractSubtitles(
        context: Context,
        uri: Uri,
        durationMs: Long,
        cropBox: NormalizedRect,
        sourceLanguage: SourceLanguage,
        onProgress: (Float) -> Unit
    ): OcrExtractionResult = withContext(Dispatchers.IO) {
        val safeCrop = cropBox.clamped()
        val recognizer = createRecognizer(sourceLanguage)
        val chineseCheckRecognizer = if (sourceLanguage != SourceLanguage.CHINESE) {
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        } else {
            null
        }

        val retriever = MediaMetadataRetriever()
        val rawSamples = mutableListOf<RawSample>()
        var chineseDetectedOnNonChineseMode = 0

        try {
            retriever.setDataSource(context, uri)
            val safeDuration = durationMs.coerceAtLeast(1000L)
            // Finer adaptive sampling so short 0.5s subtitles and exact transitions are captured accurately
            val stepMs = when {
                safeDuration <= 20_000L -> 250L
                safeDuration <= 60_000L -> 350L
                safeDuration <= 180_000L -> 500L
                else -> (safeDuration / 280L).coerceIn(500L, 900L)
            }

            val timestamps = mutableListOf<Long>()
            var t = 0L
            while (t < safeDuration) {
                timestamps.add(t)
                t += stepMs
            }
            if (timestamps.isEmpty()) timestamps.add(0L)

            timestamps.forEachIndexed { idx, timeMs ->
                onProgress((idx + 1).toFloat() / timestamps.size.toFloat())
                var frameBitmap: Bitmap? = null
                var croppedBitmap: Bitmap? = null
                var enhancedBitmap: Bitmap? = null
                try {
                    frameBitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                        retriever.getScaledFrameAtTime(
                            timeMs * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST,
                            1280,
                            1280
                        )
                    } else {
                        retriever.getFrameAtTime(
                            timeMs * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST
                        )
                    }

                    if (frameBitmap != null) {
                        val cropX = (safeCrop.left * frameBitmap.width).toInt()
                            .coerceIn(0, (frameBitmap.width - 2).coerceAtLeast(0))
                        val cropY = (safeCrop.top * frameBitmap.height).toInt()
                            .coerceIn(0, (frameBitmap.height - 2).coerceAtLeast(0))
                        val cropW = (safeCrop.width * frameBitmap.width).toInt()
                            .coerceIn(1, frameBitmap.width - cropX)
                        val cropH = (safeCrop.height * frameBitmap.height).toInt()
                            .coerceIn(1, frameBitmap.height - cropY)

                        croppedBitmap = Bitmap.createBitmap(frameBitmap, cropX, cropY, cropW, cropH)
                        // Upscale and lightly boost contrast if crop is small or over bright flash scenes
                        enhancedBitmap = prepareSubtitleCropForOcr(croppedBitmap)

                        val primaryResult = recognizer.process(InputImage.fromBitmap(enhancedBitmap, 0)).await()
                        var recognized = extractFilteredSubtitleText(
                            visionText = primaryResult,
                            cropWidth = enhancedBitmap.width,
                            cropHeight = enhancedBitmap.height,
                            sourceLanguage = sourceLanguage
                        )

                        // Fallback pass on un-enhanced crop if high-contrast pass returned empty
                        if (recognized.isBlank() && enhancedBitmap !== croppedBitmap) {
                            val fallbackResult = recognizer.process(InputImage.fromBitmap(croppedBitmap, 0)).await()
                            recognized = extractFilteredSubtitleText(
                                visionText = fallbackResult,
                                cropWidth = croppedBitmap.width,
                                cropHeight = croppedBitmap.height,
                                sourceLanguage = sourceLanguage
                            )
                        }

                        if (recognized.isNotBlank()) {
                            rawSamples.add(RawSample(timeMs, recognized))
                        }

                        if (chineseCheckRecognizer != null && idx % 3 == 0) {
                            val zhCheck = chineseCheckRecognizer
                                .process(InputImage.fromBitmap(croppedBitmap, 0))
                                .await()
                                .text
                            chineseDetectedOnNonChineseMode += TextSanitizer.countChineseCharacters(zhCheck)
                        }
                    }
                } finally {
                    if (enhancedBitmap != null && enhancedBitmap !== croppedBitmap && !enhancedBitmap.isRecycled) {
                        enhancedBitmap.recycle()
                    }
                    if (croppedBitmap != null && croppedBitmap !== frameBitmap && !croppedBitmap.isRecycled) {
                        croppedBitmap.recycle()
                    }
                    if (frameBitmap != null && !frameBitmap.isRecycled) {
                        frameBitmap.recycle()
                    }
                }
            }

            val allText = rawSamples.joinToString(" ") { it.text }
            val chineseCount = TextSanitizer.countChineseCharacters(allText)

            if (sourceLanguage == SourceLanguage.CHINESE && chineseCount == 0) {
                return@withContext OcrExtractionResult.ValidationBlocked(
                    title = "Không phát hiện phụ đề Tiếng Trung",
                    message = if (allText.isBlank()) {
                        "Không nhận diện được chữ nào trong khung OCR. Hãy kéo và chỉnh khung hồng đào ôm sát vùng phụ đề phía dưới video rồi thử lại."
                    } else {
                        "Văn bản trong khung không chứa ký tự Tiếng Trung (nhận được: \"${allText.take(40)}\"). Hãy đặt lại khung OCR vào đúng vùng phụ đề hoặc đổi ngôn ngữ nguồn."
                    },
                    isWrongLanguageConfig = false
                )
            }

            if (sourceLanguage != SourceLanguage.CHINESE &&
                (chineseDetectedOnNonChineseMode > 0 || chineseCount > 0)
            ) {
                return@withContext OcrExtractionResult.ValidationBlocked(
                    title = "Sai ngôn ngữ OCR đang chọn",
                    message = "Phát hiện phụ đề Tiếng Trung trong khung nhưng ngôn ngữ OCR đang đặt là ${sourceLanguage.displayName}. Hãy chuyển về Tiếng Trung (Mặc định) hoặc chỉnh lại khung.",
                    isWrongLanguageConfig = true
                )
            }

            if (rawSamples.isEmpty()) {
                return@withContext OcrExtractionResult.ValidationBlocked(
                    title = "Không tìm thấy phụ đề trong khung",
                    message = "Không đọc được dòng phụ đề nào trong vùng đã khoanh. Hãy kéo khung OCR ôm sát vùng chữ phụ đề và thử lại.",
                    isWrongLanguageConfig = false
                )
            }

            val stabilized = healSingleFrameGlitches(rawSamples, stepMs)
            val merged = mergeSamplesIntoSegments(stabilized, stepMs, safeDuration)
            OcrExtractionResult.Success(
                segments = merged,
                sampledFrames = timestamps.size,
                chineseCharactersFound = chineseCount
            )
        } catch (t: Throwable) {
            OcrExtractionResult.Error(t.message ?: "Lỗi tách OCR cục bộ.")
        } finally {
            runCatching { recognizer.close() }
            runCatching { chineseCheckRecognizer?.close() }
            runCatching { retriever.release() }
        }
    }

    /**
     * Upscales small subtitle crops (ensuring readable stroke height for ML Kit) and applies
     * gentle contrast stretching to stabilize white/yellow outlined text over bright flashes.
     */
    private fun prepareSubtitleCropForOcr(src: Bitmap): Bitmap {
        val scale = when {
            src.height < 64 -> 2.0f
            src.height < 110 -> 1.5f
            else -> 1.0f
        }
        val targetW = (src.width * scale).toInt().coerceIn(src.width, 1440)
        val targetH = (src.height * scale).toInt().coerceIn(src.height, 480)

        val out = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val contrast = 1.24f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val cm = ColorMatrix(
            floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(cm)
        }
        canvas.drawBitmap(src, null, Rect(0, 0, targetW, targetH), paint)
        return out
    }

    /**
     * Filters ML Kit text blocks spatially to reject:
     * - Corner logos / tiny edge watermarks
     * - Vertical sidebars / channel stamps
     * - Single-symbol motion flash artifacts
     */
    private fun extractFilteredSubtitleText(
        visionText: Text,
        cropWidth: Int,
        cropHeight: Int,
        sourceLanguage: SourceLanguage
    ): String {
        val blocks = visionText.textBlocks
        if (blocks.isEmpty()) return ""

        val candidates = blocks.mapNotNull { block ->
            val box = block.boundingBox ?: return@mapNotNull null
            val rawLineText = block.lines
                .sortedBy { it.boundingBox?.top ?: 0 }
                .joinToString(" ") { it.text.trim() }
            val cleaned = TextSanitizer.cleanOcrTextForTranslation(rawLineText)
            if (cleaned.isBlank()) return@mapNotNull null

            val w = box.width().coerceAtLeast(1)
            val h = box.height().coerceAtLeast(1)
            val aspectRatio = w.toFloat() / h.toFloat()

            // Reject tall vertical watermark/episode columns when multi-line horizontal text is expected
            val looksVerticalWatermark = h > w * 2.2f && cleaned.length <= 8
            if (looksVerticalWatermark) return@mapNotNull null

            // Reject isolated pure punctuation/noise
            if (!cleaned.any { it.isLetterOrDigit() || TextSanitizer.isChineseCodePoint(it.code) }) {
                return@mapNotNull null
            }

            Triple(box, cleaned, aspectRatio)
        }

        if (candidates.isEmpty()) return ""

        // If there's a dominant wide horizontal block, drop tiny far-corner watermark chips
        val maxBoxWidth = candidates.maxOf { it.first.width() }
        val filtered = if (candidates.size > 1 && maxBoxWidth >= cropWidth * 0.25f) {
            candidates.filter { (box, text, _) ->
                val isTinyCornerTag = box.width() < cropWidth * 0.14f &&
                    (box.right < cropWidth * 0.18f || box.left > cropWidth * 0.82f) &&
                    box.top < cropHeight * 0.35f &&
                    text.length <= 4
                !isTinyCornerTag
            }
        } else {
            candidates
        }

        val ordered = filtered
            .sortedWith(compareBy<Triple<Rect, String, Float>> { it.first.top / 16 }.thenBy { it.first.left })
            .map { it.second }

        val joined = if (sourceLanguage == SourceLanguage.CHINESE || sourceLanguage == SourceLanguage.JAPANESE) {
            ordered.joinToString("")
        } else {
            ordered.joinToString(" ")
        }

        val finalCleaned = TextSanitizer.cleanOcrTextForTranslation(joined)
        // Drop single-character stray flash artifacts on non-meaningful single symbols
        if (finalCleaned.length == 1 && !TextSanitizer.isChineseCodePoint(finalCleaned[0].code)) {
            return ""
        }
        return finalCleaned
    }

    /**
     * Bridges 1-frame flash/blur glitches: if sample[i-1] and sample[i+1] are practically identical
     * and sample[i] differs slightly due to a 1-frame explosion/blur glitch, replace sample[i] so
     * the subtitle does not split into 3 jittery cues.
     */
    private fun healSingleFrameGlitches(
        samples: List<RawSample>,
        stepMs: Long
    ): List<RawSample> {
        if (samples.size < 3) return samples
        val mutable = samples.toMutableList()
        for (i in 1 until mutable.lastIndex) {
            val prev = mutable[i - 1]
            val curr = mutable[i]
            val next = mutable[i + 1]
            val neighborsClose = (next.timeMs - prev.timeMs) <= stepMs * 3L
            if (neighborsClose && orderedSimilarity(prev.text, next.text) >= 0.80f) {
                if (orderedSimilarity(prev.text, curr.text) < 0.72f) {
                    mutable[i] = curr.copy(text = if (prev.text.length >= next.text.length) prev.text else next.text)
                }
            }
        }
        return mutable
    }

    private fun createRecognizer(language: SourceLanguage): TextRecognizer {
        return when (language) {
            SourceLanguage.CHINESE -> TextRecognition.getClient(
                ChineseTextRecognizerOptions.Builder().build()
            )
            SourceLanguage.ENGLISH -> TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS
            )
            SourceLanguage.JAPANESE -> TextRecognition.getClient(
                JapaneseTextRecognizerOptions.Builder().build()
            )
            SourceLanguage.KOREAN -> TextRecognition.getClient(
                KoreanTextRecognizerOptions.Builder().build()
            )
        }
    }

    private fun mergeSamplesIntoSegments(
        samples: List<RawSample>,
        stepMs: Long,
        totalDurationMs: Long
    ): List<SrtSegment> {
        if (samples.isEmpty()) return emptyList()

        data class RunGroup(
            var startMs: Long,
            var lastSeenMs: Long,
            val variants: MutableList<String>
        )

        val groups = mutableListOf<RunGroup>()
        var current = RunGroup(
            startMs = samples.first().timeMs,
            lastSeenMs = samples.first().timeMs,
            variants = mutableListOf(samples.first().text)
        )

        for (i in 1 until samples.size) {
            val sample = samples[i]
            val representative = selectConsensusText(current.variants)
            val closeInTime = (sample.timeMs - current.lastSeenMs) <= (stepMs * 2L + 120L)
            val sameSubtitle = isSameSubtitle(representative, sample.text)
            if (closeInTime && sameSubtitle) {
                current.lastSeenMs = sample.timeMs
                current.variants.add(sample.text)
            } else {
                groups.add(current)
                current = RunGroup(
                    startMs = sample.timeMs,
                    lastSeenMs = sample.timeMs,
                    variants = mutableListOf(sample.text)
                )
            }
        }
        groups.add(current)

        val segments = mutableListOf<SrtSegment>()
        for (idx in groups.indices) {
            val g = groups[idx]
            val bestText = selectConsensusText(g.variants)
            // Drop isolated 1-sample tiny 1-char flash noise unless it lasted multiple frames
            if (g.variants.size == 1 && bestText.length <= 1) continue

            val nextStart = groups.getOrNull(idx + 1)?.startMs ?: totalDurationMs
            val rawEnd = (g.lastSeenMs + stepMs).coerceAtMost(nextStart).coerceAtMost(totalDurationMs)
            val safeEnd = max(rawEnd, g.startMs + 350L).coerceAtMost(totalDurationMs)
            if (safeEnd <= g.startMs) continue

            segments.add(
                SrtSegment(
                    index = segments.size + 1,
                    startMs = g.startMs,
                    endMs = safeEnd,
                    originalText = bestText
                )
            )
        }
        return segments
    }

    /**
     * Chooses the cleanest consensus string from repeated frame reads of the same subtitle:
     * prefers the most frequent exact reading, breaking ties by fuller length without noise.
     */
    private fun selectConsensusText(variants: List<String>): String {
        if (variants.size == 1) return variants.first()
        val counts = variants.groupingBy { it }.eachCount()
        return counts.entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenByDescending { it.key.length })
            .first()
            .key
    }

    private fun isSameSubtitle(a: String, b: String): Boolean {
        val normA = a.replace(Regex("""[\s,.?!:;'"]+"""), "")
        val normB = b.replace(Regex("""[\s,.?!:;'"]+"""), "")
        if (normA.isEmpty() || normB.isEmpty()) return false
        if (normA == normB) return true

        // Substring check handles fade-in / partial occlusion where one frame missed 1-2 chars
        val shorter = min(normA.length, normB.length)
        val longer = max(normA.length, normB.length)
        if (shorter >= 3 && (normA.contains(normB) || normB.contains(normA)) && shorter >= longer * 0.65f) {
            return true
        }

        return orderedSimilarity(normA, normB) >= 0.72f
    }

    /**
     * Order-aware similarity using Levenshtein edit distance so swapped/different lines aren't falsely merged.
     */
    fun orderedSimilarity(a: String, b: String): Float {
        if (a == b) return 1f
        val maxLen = max(a.length, b.length)
        if (maxLen == 0) return 1f
        if (abs(a.length - b.length) > maxLen * 0.5f && min(a.length, b.length) >= 4) {
            return 0f
        }
        val dist = levenshteinDistance(a, b)
        return (1f - dist.toFloat() / maxLen.toFloat()).coerceIn(0f, 1f)
    }

    private fun levenshteinDistance(a: String, b: String): Int {
        val n = a.length
        val m = b.length
        if (n == 0) return m
        if (m == 0) return n
        var prev = IntArray(m + 1) { it }
        var curr = IntArray(m + 1)
        for (i in 1..n) {
            curr[0] = i
            val ca = a[i - 1]
            for (j in 1..m) {
                val cost = if (ca == b[j - 1]) 0 else 1
                curr[j] = min(min(curr[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            val tmp = prev
            prev = curr
            curr = tmp
        }
        return prev[m]
    }
}
