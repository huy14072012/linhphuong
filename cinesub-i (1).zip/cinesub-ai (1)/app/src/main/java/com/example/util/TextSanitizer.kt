package com.example.util

import com.example.model.GlossaryRule
import com.example.model.SrtSegment

sealed interface SanitationResult {
    data class Valid(val sanitizedSegments: List<SrtSegment>) : SanitationResult
    data class Blocked(val reason: String) : SanitationResult
}

object TextSanitizer {

    fun isChineseCodePoint(cp: Int): Boolean {
        return (cp in 0x4E00..0x9FFF) ||
            (cp in 0x3400..0x4DBF) ||
            (cp in 0xF900..0xFAFF) ||
            (cp in 0x20000..0x2A6DF) ||
            (cp in 0x2A700..0x2B73F) ||
            (cp in 0x2B740..0x2B81F) ||
            (cp in 0x2B820..0x2CEAF)
    }

    fun isCjkPunctuationOrFullwidth(cp: Int): Boolean {
        return (cp in 0x3000..0x303F) || (cp in 0xFF00..0xFFEF)
    }

    private fun isCjkChar(cp: Int): Boolean {
        return isChineseCodePoint(cp) ||
            (cp in 0x3040..0x30FF) || // Hiragana + Katakana
            (cp in 0xAC00..0xD7AF)    // Hangul
    }

    fun containsChineseCharacters(text: String): Boolean {
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            if (isChineseCodePoint(cp)) return true
            i += Character.charCount(cp)
        }
        return false
    }

    fun countChineseCharacters(text: String): Int {
        var count = 0
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            if (isChineseCodePoint(cp)) count++
            i += Character.charCount(cp)
        }
        return count
    }

    /**
     * Curated starter glossary for Chinese drama / anime / cultivation / system stories
     * so terms don't translate awkwardly word-for-word. Users can edit, toggle, or add more.
     */
    fun defaultStarterGlossary(): List<GlossaryRule> = listOf(
        GlossaryRule("g_1", "师兄", "Sư huynh"),
        GlossaryRule("g_2", "师姐", "Sư tỷ"),
        GlossaryRule("g_3", "师弟", "Sư đệ"),
        GlossaryRule("g_4", "师妹", "Sư muội"),
        GlossaryRule("g_5", "师父", "Sư phụ"),
        GlossaryRule("g_6", "宗门", "Tông môn"),
        GlossaryRule("g_7", "修为", "Tu vi"),
        GlossaryRule("g_8", "灵气", "Linh khí"),
        GlossaryRule("g_9", "金丹", "Kim Đan"),
        GlossaryRule("g_10", "元婴", "Nguyên Anh"),
        GlossaryRule("g_11", "系统", "Hệ thống"),
        GlossaryRule("g_12", "大招", "Tuyệt chiêu")
    )

    /**
     * Replaces source glossary terms with invariant tokens (QTERM0Q, QTERM1Q...) BEFORE sending to
     * Google Translate so proper nouns, skills, and cultivation terms aren't translated literally.
     */
    fun applyGlossaryBeforeTranslation(
        text: String,
        rules: List<GlossaryRule>
    ): Pair<String, Map<String, String>> {
        val activeRules = rules
            .filter { it.enabled && it.sourceTerm.isNotBlank() && it.targetTerm.isNotBlank() }
            .sortedByDescending { it.sourceTerm.length }

        if (activeRules.isEmpty() || text.isBlank()) {
            return text to emptyMap()
        }

        var working = text
        val tokenMap = linkedMapOf<String, String>()
        activeRules.forEachIndexed { idx, rule ->
            val src = rule.sourceTerm.trim()
            if (src.isNotEmpty() && working.contains(src, ignoreCase = !containsChineseCharacters(src))) {
                val token = "QTERM${idx}Q"
                working = if (containsChineseCharacters(src)) {
                    working.replace(src, " $token ")
                } else {
                    working.replace(Regex("""(?i)\b${Regex.escape(src)}\b"""), token)
                }
                tokenMap[token] = rule.targetTerm.trim()
            }
        }
        return working.replace(Regex("""\s+"""), " ").trim() to tokenMap
    }

    /**
     * Restores invariant glossary tokens back into exact user-defined target terms AFTER translation,
     * and applies any post-translation literal replacements (e.g. from imported SRTs or literal slips).
     */
    fun restoreGlossaryAfterTranslation(
        translatedText: String,
        tokenMap: Map<String, String>,
        rules: List<GlossaryRule>
    ): String {
        var out = translatedText
        tokenMap.forEach { (token, target) ->
            val idDigits = token.removePrefix("QTERM").removeSuffix("Q")
            val flexibleRegex = Regex("""(?i)\bQ?\s*TERM\s*$idDigits\s*Q?\b""")
            out = out.replace(flexibleRegex, target)
        }

        val activeRules = rules
            .filter { it.enabled && it.sourceTerm.isNotBlank() && it.targetTerm.isNotBlank() }
            .sortedByDescending { it.sourceTerm.length }
        for (rule in activeRules) {
            val src = rule.sourceTerm.trim()
            if (!containsChineseCharacters(src)) {
                out = out.replace(Regex("""(?i)\b${Regex.escape(src)}\b"""), rule.targetTerm.trim())
            } else if (out.contains(src)) {
                out = out.replace(src, rule.targetTerm.trim())
            }
        }

        return cleanTranslatedSubtitleText(out)
    }

    /**
     * Pre-processes raw OCR subtitle text before sending to Google Translate:
     * - Strips zero-width characters & common OCR border/watermark noise (|, ~, bullets, repeated dashes)
     * - Normalizes fullwidth CJK punctuation so Google Translate respects clause boundaries
     * - Joins fragmented line breaks & removes spurious spaces between CJK characters
     */
    fun cleanOcrTextForTranslation(raw: String): String {
        if (raw.isBlank()) return ""

        val cleanedLines = raw
            .replace("\uFEFF", "")
            .replace("\u200B", "")
            .replace("\u200C", "")
            .replace("\u200D", "")
            .lines()
            .map { line ->
                line.trim()
                    .replace(Regex("""[|¦┃│]+"""), " ")
                    .replace(Regex("""[•●◆▪▫□■★☆]+"""), " ")
                    .replace(Regex("""[-_=~]{2,}"""), " ")
                    .replace(Regex("""^\s*[-*~·]+\s*"""), "")
                    .replace(Regex("""\s*[-*~·]+\s*$"""), "")
                    .replace("，", ", ")
                    .replace("。", ". ")
                    .replace("？", "? ")
                    .replace("！", "! ")
                    .replace("：", ": ")
                    .replace("；", "; ")
                    .replace("（", " (")
                    .replace("）", ") ")
                    .replace("“", "\"")
                    .replace("”", "\"")
                    .replace("「", "\"")
                    .replace("」", "\"")
                    .replace("『", "\"")
                    .replace("』", "\"")
                    .replace("、", ", ")
                    .replace(Regex("""\s+"""), " ")
                    .trim()
            }
            .filter { it.isNotBlank() }

        if (cleanedLines.isEmpty()) return ""

        // Join broken lines smartly: CJK lines don't want artificial spaces inserted at wrap points
        val joined = buildString {
            cleanedLines.forEachIndexed { idx, line ->
                if (idx > 0 && isNotEmpty()) {
                    val prevCp = Character.codePointBefore(this, length)
                    val nextCp = line.codePointAt(0)
                    if (!isCjkChar(prevCp) && !isCjkChar(nextCp)) {
                        append(' ')
                    }
                }
                append(line)
            }
        }

        // Remove spurious spaces OCR frequently inserts between adjacent CJK characters or before punctuation
        val compactCjk = removeSpacesBetweenCjk(joined)
        return compactCjk
            .replace(Regex("""\s+([,.;:!?])"""), "$1")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun removeSpacesBetweenCjk(text: String): String {
        val sb = StringBuilder(text.length)
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch == ' ' && i > 0 && i + 1 < text.length) {
                val prevCp = Character.codePointBefore(text, i)
                val nextCp = text.codePointAt(i + 1)
                if (isCjkChar(prevCp) && isCjkChar(nextCp)) {
                    i++
                    continue
                }
            }
            sb.append(ch)
            i++
        }
        return sb.toString()
    }

    /**
     * Cleans translated subtitle text for readability & voiceover naturalness.
     */
    fun cleanTranslatedSubtitleText(raw: String): String {
        return raw
            .replace(Regex("""[⟦⟧【】]"""), "")
            .replace(Regex("""\s+([,.;:!?])"""), "$1")
            .replace(Regex("""([,.;:!?])([^\s\d"'”’)\]}])"""), "$1 $2")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    fun sanitizeForVoiceover(translatedText: String): String {
        val sb = StringBuilder(translatedText.length)
        var i = 0
        while (i < translatedText.length) {
            val cp = translatedText.codePointAt(i)
            if (!isChineseCodePoint(cp) && !isCjkPunctuationOrFullwidth(cp)) {
                sb.appendCodePoint(cp)
            }
            i += Character.charCount(cp)
        }
        return sb.toString()
            .replace(Regex("""\s+([,.;:!?])"""), "$1")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    fun validateSanitizedVoiceoverScript(segments: List<SrtSegment>): SanitationResult {
        if (segments.isEmpty()) {
            return SanitationResult.Blocked("Chưa có phụ đề nào để lồng tiếng.")
        }

        val sanitized = mutableListOf<SrtSegment>()
        for (segment in segments) {
            val rawCandidate = segment.translatedText.ifBlank { segment.originalText }.trim()
            if (rawCandidate.isEmpty()) {
                return SanitationResult.Blocked(
                    "Dòng #${segment.index} đang trống nội dung. Vui lòng nhập hoặc dịch phụ đề trước."
                )
            }
            if (containsChineseCharacters(rawCandidate) && segment.translatedText.isBlank()) {
                return SanitationResult.Blocked(
                    "Dòng #${segment.index} vẫn còn chữ Trung gốc chưa dịch. Hãy bấm 'Google Dịch' trước khi lồng tiếng."
                )
            }
            val cleaned = sanitizeForVoiceover(rawCandidate)
            if (cleaned.isEmpty() || containsChineseCharacters(cleaned)) {
                return SanitationResult.Blocked(
                    "Dòng #${segment.index} chỉ chứa ký tự nguồn sau khi lọc. Vui lòng dịch sang ngôn ngữ đích trước."
                )
            }
            sanitized.add(segment.copy(translatedText = cleaned))
        }

        return SanitationResult.Valid(sanitized)
    }
}
