package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.ApiConfig
import com.example.model.AppLanguage
import com.example.model.GlossaryRule
import com.example.model.TargetLanguage
import com.example.model.TranslationProvider
import com.example.model.TtsEngineMode
import com.example.model.TtsPayloadPreset
import com.example.util.TextSanitizer
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "matchacut_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val APP_LANGUAGE = stringPreferencesKey("app_language")
        val TRANSLATION_PROVIDER = stringPreferencesKey("translation_provider")
        val TRANSLATION_ENDPOINT = stringPreferencesKey("translation_endpoint")
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val GEMINI_MODEL = stringPreferencesKey("gemini_model")
        val TRANSLATION_BATCH_SIZE = intPreferencesKey("translation_batch_size")
        val TRANSLATION_DELAY_MS = longPreferencesKey("translation_delay_ms")
        val TTS_ENDPOINT_URL = stringPreferencesKey("tts_endpoint_url")
        val TTS_API_KEY = stringPreferencesKey("tts_api_key")
        val TTS_PAYLOAD_PRESET = stringPreferencesKey("tts_payload_preset")
        val TTS_ENGINE_MODE = stringPreferencesKey("tts_engine_mode")
        val AUTO_ALIGN_VOICE_TIMING = booleanPreferencesKey("auto_align_voice_timing")
        val TARGET_LANGUAGE = stringPreferencesKey("target_language")
        val SELECTED_VOICE_ID = stringPreferencesKey("selected_voice_id")
        val GLOSSARY_JSON = stringPreferencesKey("glossary_rules_json")
    }

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val glossaryAdapter = moshi.adapter<List<GlossaryRule>>(
        Types.newParameterizedType(List::class.java, GlossaryRule::class.java)
    )

    val appLanguageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        val code = prefs[Keys.APP_LANGUAGE]
        AppLanguage.entries.find { it.code == code } ?: AppLanguage.VIETNAMESE
    }

    val apiConfigFlow: Flow<ApiConfig> = context.dataStore.data.map { prefs ->
        val provider = prefs[Keys.TRANSLATION_PROVIDER]?.let { name ->
            TranslationProvider.entries.find { it.name == name }
        } ?: TranslationProvider.GOOGLE_TRANSLATE_FREE

        ApiConfig(
            translationProvider = provider,
            translationEndpointUrl = prefs[Keys.TRANSLATION_ENDPOINT]
                ?.takeIf { it.isNotBlank() } ?: provider.defaultEndpoint,
            geminiApiKey = prefs[Keys.GEMINI_API_KEY].orEmpty(),
            geminiModel = prefs[Keys.GEMINI_MODEL]
                ?.takeIf { it.isNotBlank() } ?: provider.defaultModel,
            translationBatchSize = (prefs[Keys.TRANSLATION_BATCH_SIZE] ?: 5).coerceIn(1, 10),
            translationDelayMs = (prefs[Keys.TRANSLATION_DELAY_MS] ?: 650L).coerceIn(250L, 5000L),
            ttsEndpointUrl = prefs[Keys.TTS_ENDPOINT_URL].orEmpty(),
            ttsApiKey = prefs[Keys.TTS_API_KEY].orEmpty(),
            ttsPayloadPreset = prefs[Keys.TTS_PAYLOAD_PRESET]?.let { name ->
                TtsPayloadPreset.entries.find { it.name == name }
            } ?: TtsPayloadPreset.OPENAI_COMPATIBLE,
            ttsEngineMode = prefs[Keys.TTS_ENGINE_MODE]?.let { name ->
                TtsEngineMode.entries.find { it.name == name }
            } ?: TtsEngineMode.EXPRESSIVE_STORY_TTS,
            autoAlignVoiceTiming = prefs[Keys.AUTO_ALIGN_VOICE_TIMING] ?: true
        )
    }

    val targetLanguageFlow: Flow<TargetLanguage> = context.dataStore.data.map { prefs ->
        val code = prefs[Keys.TARGET_LANGUAGE]
        TargetLanguage.entries.find { it.code == code } ?: TargetLanguage.VIETNAMESE
    }

    val selectedVoiceIdFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.SELECTED_VOICE_ID].orEmpty().ifBlank { "ngoc_huyen" }
    }

    val glossaryRulesFlow: Flow<List<GlossaryRule>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.GLOSSARY_JSON]
        if (raw == null) {
            TextSanitizer.defaultStarterGlossary()
        } else {
            runCatching { glossaryAdapter.fromJson(raw) }.getOrNull().orEmpty()
        }
    }

    suspend fun saveAppLanguage(language: AppLanguage) {
        context.dataStore.edit { prefs ->
            prefs[Keys.APP_LANGUAGE] = language.code
        }
    }

    suspend fun saveApiConfig(config: ApiConfig) {
        context.dataStore.edit { prefs ->
            prefs[Keys.TRANSLATION_PROVIDER] = config.translationProvider.name
            prefs[Keys.TRANSLATION_ENDPOINT] = config.translationEndpointUrl.trim()
                .ifBlank { config.translationProvider.defaultEndpoint }
            prefs[Keys.GEMINI_API_KEY] = config.geminiApiKey.trim()
            prefs[Keys.GEMINI_MODEL] = config.geminiModel.trim()
                .ifBlank { config.translationProvider.defaultModel }
            prefs[Keys.TRANSLATION_BATCH_SIZE] = config.translationBatchSize.coerceIn(1, 10)
            prefs[Keys.TRANSLATION_DELAY_MS] = config.translationDelayMs.coerceIn(250L, 5000L)
            prefs[Keys.TTS_ENDPOINT_URL] = config.ttsEndpointUrl.trim()
            prefs[Keys.TTS_API_KEY] = config.ttsApiKey.trim()
            prefs[Keys.TTS_PAYLOAD_PRESET] = config.ttsPayloadPreset.name
            prefs[Keys.TTS_ENGINE_MODE] = config.ttsEngineMode.name
            prefs[Keys.AUTO_ALIGN_VOICE_TIMING] = config.autoAlignVoiceTiming
        }
    }

    suspend fun saveTargetLanguage(language: TargetLanguage) {
        context.dataStore.edit { prefs ->
            prefs[Keys.TARGET_LANGUAGE] = language.code
        }
    }

    suspend fun saveSelectedVoiceId(voiceId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_VOICE_ID] = voiceId
        }
    }

    suspend fun saveGlossaryRules(rules: List<GlossaryRule>) {
        val json = runCatching { glossaryAdapter.toJson(rules) }.getOrDefault("[]")
        context.dataStore.edit { prefs ->
            prefs[Keys.GLOSSARY_JSON] = json
        }
    }
}
