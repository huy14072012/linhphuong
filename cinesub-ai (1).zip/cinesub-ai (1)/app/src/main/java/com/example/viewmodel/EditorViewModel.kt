package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SettingsRepository
import com.example.media.AudioSrtExtractor
import com.example.media.AudioSrtResult
import com.example.media.OcrExtractionResult
import com.example.media.OcrSubtitleExtractor
import com.example.media.VideoExportResult
import com.example.media.VideoExporter
import com.example.media.VideoInspector
import com.example.model.ActiveTrack
import com.example.model.ApiConfig
import com.example.model.AppLanguage
import com.example.model.ExportConfig
import com.example.model.ExportState
import com.example.model.ExtractionMethod
import com.example.model.FilmstripFrame
import com.example.model.NormalizedRect
import com.example.model.SourceLanguage
import com.example.model.SrtSegment
import com.example.model.StudioSheet
import com.example.model.TargetLanguage
import com.example.model.VideoMetadata
import com.example.model.WorkflowStep
import com.example.network.GeminiTranslator
import com.example.network.TranslationResult
import com.example.network.VoiceCatalog
import com.example.network.VoiceoverGenerator
import com.example.network.VoiceoverResult
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.example.util.stringsForLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class ValidationAlert(
    val title: String,
    val message: String,
    val showLanguageFixButton: Boolean = false
)

data class EditorUiState(
    val appLanguage: AppLanguage = AppLanguage.VIETNAMESE,
    val workflowStep: WorkflowStep = WorkflowStep.EMPTY,
    val videoMetadata: VideoMetadata? = null,
    val filmstrip: List<FilmstripFrame> = emptyList(),
    val isPlaying: Boolean = false,
    val playbackPositionMs: Long = 0L,
    val cropBox: NormalizedRect = NormalizedRect(),
    val showOcrBox: Boolean = true,
    val sourceLanguage: SourceLanguage = SourceLanguage.CHINESE,
    val targetLanguage: TargetLanguage = TargetLanguage.VIETNAMESE,
    val extractionMethod: ExtractionMethod = ExtractionMethod.OCR,
    val segments: List<SrtSegment> = emptyList(),
    val selectedSegmentIndex: Int? = null,
    val activeTrack: ActiveTrack = ActiveTrack.VIDEO,
    val audioWaveformPeaks: List<Float> = emptyList(),
    val voiceoverWavPath: String? = null,
    val voiceoverWaveformPeaks: List<Float> = emptyList(),
    val voiceoverVoiceName: String? = null,
    val selectedVoiceId: String = "ngoc_huyen",
    val previewWithVoiceover: Boolean = true,
    val apiConfig: ApiConfig = ApiConfig(),
    val exportConfig: ExportConfig = ExportConfig(),
    val exportState: ExportState = ExportState.Idle,
    val activeSheet: StudioSheet = StudioSheet.NONE,
    val isBusy: Boolean = false,
    val busyLabel: String = "",
    val busyProgress: Float? = null,
    val validationAlert: ValidationAlert? = null,
    val statusBanner: String? = null
) {
    val isVoiceoverUnlocked: Boolean
        get() = workflowStep.stepNumber >= WorkflowStep.TRANSLATED.stepNumber &&
            segments.isNotEmpty() &&
            segments.any { it.translatedText.isNotBlank() }

    val activeSubtitleAtPlayhead: SrtSegment?
        get() = segments.firstOrNull { playbackPositionMs in it.startMs..it.endMs }
}

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepo = SettingsRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepo.appLanguageFlow.collect { lang ->
                _uiState.update { it.copy(appLanguage = lang) }
            }
        }
        viewModelScope.launch {
            settingsRepo.apiConfigFlow.collect { cfg ->
                _uiState.update { it.copy(apiConfig = cfg) }
            }
        }
        viewModelScope.launch {
            settingsRepo.targetLanguageFlow.collect { lang ->
                _uiState.update { it.copy(targetLanguage = lang) }
            }
        }
        viewModelScope.launch {
            settingsRepo.selectedVoiceIdFlow.collect { voiceId ->
                _uiState.update { it.copy(selectedVoiceId = voiceId) }
            }
        }
    }

    fun setAppLanguage(language: AppLanguage) {
        _uiState.update { it.copy(appLanguage = language) }
        viewModelScope.launch { settingsRepo.saveAppLanguage(language) }
    }

    fun importVideo(uri: Uri) {
        val context = getApplication<Application>().applicationContext
        val strings = stringsForLanguage(_uiState.value.appLanguage)
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = strings.inspectingVideoBusy,
                    busyProgress = null,
                    validationAlert = null,
                    statusBanner = null
                )
            }
            try {
                val metadata = VideoInspector.inspect(context, uri)
                val frames = VideoInspector.extractFilmstrip(context, uri, metadata.durationMs, count = 12)
                _uiState.value.filmstrip.forEach { old ->
                    if (!old.bitmap.isRecycled) old.bitmap.recycle()
                }
                _uiState.update {
                    it.copy(
                        workflowStep = WorkflowStep.VIDEO_IMPORTED,
                        videoMetadata = metadata,
                        filmstrip = frames,
                        playbackPositionMs = 0L,
                        isPlaying = false,
                        segments = emptyList(),
                        selectedSegmentIndex = null,
                        audioWaveformPeaks = emptyList(),
                        voiceoverWavPath = null,
                        voiceoverWaveformPeaks = emptyList(),
                        voiceoverVoiceName = null,
                        activeTrack = ActiveTrack.VIDEO,
                        showOcrBox = true,
                        exportState = ExportState.Idle,
                        isBusy = false,
                        busyLabel = "",
                        statusBanner = "${metadata.displayName} (${metadata.resolutionLabel} · ${metadata.fpsLabel})"
                    )
                }
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(
                        isBusy = false,
                        busyLabel = "",
                        validationAlert = ValidationAlert(
                            title = "Video Import Failed",
                            message = t.message ?: "Could not read video metadata from selected file."
                        )
                    )
                }
            }
        }
    }

    fun updateCropBox(newBox: NormalizedRect) {
        _uiState.update { it.copy(cropBox = newBox.clamped()) }
    }

    fun resetCropBox() {
        _uiState.update { it.copy(cropBox = NormalizedRect()) }
    }

    fun toggleOcrBoxVisibility() {
        _uiState.update { it.copy(showOcrBox = !it.showOcrBox) }
    }

    fun setSourceLanguage(language: SourceLanguage) {
        _uiState.update { it.copy(sourceLanguage = language, validationAlert = null) }
    }

    fun setTargetLanguage(language: TargetLanguage) {
        _uiState.update { it.copy(targetLanguage = language) }
        viewModelScope.launch { settingsRepo.saveTargetLanguage(language) }
    }

    fun setSelectedVoice(voiceId: String) {
        _uiState.update { it.copy(selectedVoiceId = voiceId) }
        viewModelScope.launch { settingsRepo.saveSelectedVoiceId(voiceId) }
    }

    fun setActiveTrack(track: ActiveTrack) {
        if (track == ActiveTrack.VOICEOVER && !_uiState.value.isVoiceoverUnlocked) {
            val strings = stringsForLanguage(_uiState.value.appLanguage)
            _uiState.update { it.copy(statusBanner = strings.voiceTrackLocked) }
            return
        }
        _uiState.update { it.copy(activeTrack = track) }
    }

    fun updatePlaybackPosition(positionMs: Long) {
        _uiState.update { it.copy(playbackPositionMs = positionMs) }
    }

    fun setPlaying(playing: Boolean) {
        _uiState.update { it.copy(isPlaying = playing) }
    }

    fun selectSegment(index: Int?) {
        _uiState.update { it.copy(selectedSegmentIndex = index) }
    }

    fun dismissValidationAlert() {
        _uiState.update { it.copy(validationAlert = null) }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun openSheet(sheet: StudioSheet) {
        if (sheet == StudioSheet.VOICEOVER && !_uiState.value.isVoiceoverUnlocked) {
            val strings = stringsForLanguage(_uiState.value.appLanguage)
            _uiState.update {
                it.copy(
                    validationAlert = ValidationAlert(
                        title = strings.voiceoverLockedTitle,
                        message = strings.voiceoverLockedMsg
                    )
                )
            }
            return
        }
        _uiState.update { it.copy(activeSheet = sheet) }
    }

    fun closeSheet() {
        _uiState.update { it.copy(activeSheet = StudioSheet.NONE) }
    }

    fun saveApiConfig(config: ApiConfig) {
        _uiState.update { it.copy(apiConfig = config, statusBanner = "Đã lưu cài đặt API & Giọng đọc") }
        viewModelScope.launch { settingsRepo.saveApiConfig(config) }
    }

    // Step 2A: ML Kit OCR — kept 100% unchanged per user instruction
    fun runOcrExtraction() {
        val state = _uiState.value
        val metadata = state.videoMetadata ?: return
        val context = getApplication<Application>().applicationContext

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = "Running local ML Kit OCR (${state.sourceLanguage.displayName})...",
                    busyProgress = 0f,
                    extractionMethod = ExtractionMethod.OCR,
                    validationAlert = null,
                    statusBanner = null
                )
            }

            when (
                val result = OcrSubtitleExtractor.extractSubtitles(
                    context = context,
                    uri = Uri.parse(metadata.uriString),
                    durationMs = metadata.durationMs,
                    cropBox = state.cropBox,
                    sourceLanguage = state.sourceLanguage,
                    onProgress = { p ->
                        _uiState.update { it.copy(busyProgress = p) }
                    }
                )
            ) {
                is OcrExtractionResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            workflowStep = WorkflowStep.SUBTITLES_EXTRACTED,
                            segments = result.segments,
                            activeTrack = ActiveTrack.SUBTITLE,
                            voiceoverWavPath = null,
                            voiceoverWaveformPeaks = emptyList(),
                            voiceoverVoiceName = null,
                            statusBanner = "Extracted ${result.segments.size} subtitles (${result.chineseCharactersFound} Chinese chars verified)"
                        )
                    }
                }

                is OcrExtractionResult.ValidationBlocked -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            workflowStep = WorkflowStep.VIDEO_IMPORTED,
                            segments = emptyList(),
                            voiceoverWavPath = null,
                            voiceoverWaveformPeaks = emptyList(),
                            showOcrBox = true,
                            validationAlert = ValidationAlert(
                                title = result.title,
                                message = result.message,
                                showLanguageFixButton = result.isWrongLanguageConfig
                            )
                        )
                    }
                }

                is OcrExtractionResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert("OCR Extraction Error", result.message)
                        )
                    }
                }
            }
        }
    }

    // Step 2B: Real Audio-to-SRT speech recognition with missing-model warning (no fake Audio Segment X)
    fun runAudioToSrt() {
        val state = _uiState.value
        val metadata = state.videoMetadata ?: return
        val context = getApplication<Application>().applicationContext
        val strings = stringsForLanguage(state.appLanguage)

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = strings.decodingAudioBusy,
                    busyProgress = 0f,
                    extractionMethod = ExtractionMethod.AUDIO,
                    validationAlert = null,
                    statusBanner = null
                )
            }

            when (
                val result = AudioSrtExtractor.extractAudioSrt(
                    context = context,
                    uri = Uri.parse(metadata.uriString),
                    durationMs = metadata.durationMs,
                    sourceLanguage = state.sourceLanguage,
                    apiConfig = state.apiConfig,
                    onProgress = { p, label ->
                        _uiState.update { it.copy(busyProgress = p, busyLabel = label) }
                    }
                )
            ) {
                is AudioSrtResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            workflowStep = WorkflowStep.SUBTITLES_EXTRACTED,
                            segments = result.segments,
                            audioWaveformPeaks = result.waveformPeaks,
                            activeTrack = ActiveTrack.SUBTITLE,
                            voiceoverWavPath = null,
                            voiceoverWaveformPeaks = emptyList(),
                            voiceoverVoiceName = null,
                            statusBanner = "Nhận diện ${result.segments.size} câu thoại từ âm thanh"
                        )
                    }
                }

                is AudioSrtResult.MissingSpeechModel -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            workflowStep = WorkflowStep.VIDEO_IMPORTED,
                            segments = emptyList(),
                            validationAlert = ValidationAlert(
                                title = strings.missingSpeechModelTitle,
                                message = result.message
                            )
                        )
                    }
                }

                is AudioSrtResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert("Lỗi tách Audio SRT", result.message)
                        )
                    }
                }
            }
        }
    }

    fun updateSegment(index: Int, originalText: String, translatedText: String) {
        _uiState.update { state ->
            val updated = state.segments.map { seg ->
                if (seg.index == index) {
                    seg.copy(originalText = originalText, translatedText = translatedText)
                } else {
                    seg
                }
            }
            state.copy(segments = updated)
        }
    }

    fun translateWithGemini() {
        val state = _uiState.value
        val strings = stringsForLanguage(state.appLanguage)
        if (state.segments.isEmpty()) {
            _uiState.update {
                it.copy(
                    validationAlert = ValidationAlert(
                        title = "Chưa có phụ đề",
                        message = "Vui lòng chạy Bước 2 (Tách OCR hoặc Audio SRT) trước khi dịch."
                    )
                )
            }
            return
        }
        if (state.apiConfig.geminiApiKey.isBlank()) {
            _uiState.update {
                it.copy(
                    activeSheet = StudioSheet.API_SETTINGS,
                    statusBanner = strings.enterApiKeyHint
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = "${strings.translatingBusyPrefix} (${state.apiConfig.translationProvider.displayName})...",
                    busyProgress = 0f,
                    validationAlert = null
                )
            }

            when (
                val result = GeminiTranslator.translateSrt(
                    apiConfig = state.apiConfig,
                    segments = state.segments,
                    targetLanguage = state.targetLanguage,
                    onBatchProgress = { p, label ->
                        _uiState.update { it.copy(busyProgress = p, busyLabel = label) }
                    }
                )
            ) {
                is TranslationResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            segments = result.translatedSegments,
                            workflowStep = WorkflowStep.TRANSLATED,
                            activeTrack = ActiveTrack.SUBTITLE,
                            statusBanner = "Đã dịch ${result.translatedSegments.size} dòng sang ${state.targetLanguage.displayName}. Bước Lồng tiếng đã mở khóa!"
                        )
                    }
                }

                is TranslationResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert(
                                title = if (result.isTokenOrQuotaError) {
                                    "Hết Token / Giới hạn API (${state.apiConfig.translationProvider.displayName})"
                                } else {
                                    "Lỗi dịch thuật (${state.apiConfig.translationProvider.displayName})"
                                },
                                message = result.message
                            )
                        )
                    }
                }
            }
        }
    }

    fun generateVoiceover() {
        val state = _uiState.value
        val metadata = state.videoMetadata ?: return
        val strings = stringsForLanguage(state.appLanguage)
        if (!state.isVoiceoverUnlocked) {
            _uiState.update {
                it.copy(
                    validationAlert = ValidationAlert(
                        title = strings.voiceoverLockedTitle,
                        message = strings.voiceoverLockedMsg
                    )
                )
            }
            return
        }

        val voice = VoiceCatalog.findById(state.selectedVoiceId)
        val context = getApplication<Application>().applicationContext

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBusy = true,
                    busyLabel = "Đang chuẩn bị giọng đọc ${voice.name}...",
                    busyProgress = 0f,
                    activeSheet = StudioSheet.NONE,
                    validationAlert = null
                )
            }

            when (
                val result = VoiceoverGenerator.generateTimelineVoiceover(
                    context = context,
                    segments = state.segments,
                    totalVideoDurationMs = metadata.durationMs,
                    voice = voice,
                    targetLanguage = state.targetLanguage,
                    apiConfig = state.apiConfig,
                    onProgress = { progress, label ->
                        _uiState.update { it.copy(busyProgress = progress, busyLabel = label) }
                    }
                )
            ) {
                is VoiceoverResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            segments = result.updatedSegments,
                            voiceoverWavPath = result.masterWavPath,
                            voiceoverWaveformPeaks = result.waveformPeaks,
                            voiceoverVoiceName = result.voiceName,
                            workflowStep = WorkflowStep.VOICEOVER_READY,
                            activeTrack = ActiveTrack.VOICEOVER,
                            previewWithVoiceover = true,
                            statusBanner = "Đã ghép giọng đọc ${result.voiceName} vào Timeline!"
                        )
                    }
                }

                is VoiceoverResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isBusy = false,
                            busyLabel = "",
                            busyProgress = null,
                            validationAlert = ValidationAlert("Lỗi tạo giọng đọc", result.message)
                        )
                    }
                }
            }
        }
    }

    fun togglePreviewVoiceover() {
        _uiState.update { it.copy(previewWithVoiceover = !it.previewWithVoiceover) }
    }

    fun buildSrtForExport(useTranslatedIfAvailable: Boolean): String {
        val state = _uiState.value
        val hasTranslated = state.segments.any { it.translatedText.isNotBlank() }
        return SrtUtils.toSrtString(
            segments = state.segments,
            useTranslated = useTranslatedIfAvailable && hasTranslated
        )
    }

    fun exportSrtToUri(uri: Uri) {
        val context = getApplication<Application>().applicationContext
        val content = buildSrtForExport(useTranslatedIfAvailable = true)
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                    true
                }.getOrDefault(false)
            }
            _uiState.update {
                it.copy(
                    statusBanner = if (ok) "Đã lưu file .SRT vào bộ nhớ" else "Không thể ghi file .SRT"
                )
            }
        }
    }

    fun startVideoExport(config: ExportConfig) {
        val state = _uiState.value
        val metadata = state.videoMetadata ?: return
        val context = getApplication<Application>().applicationContext

        _uiState.update {
            it.copy(
                exportConfig = config,
                activeSheet = StudioSheet.NONE,
                exportState = ExportState.Running(2, "Đang khởi tạo bộ mã hóa phần cứng Media3...")
            )
        }

        viewModelScope.launch {
            when (
                val res = VideoExporter.exportMp4(
                    context = context,
                    videoMetadata = metadata,
                    segments = state.segments,
                    voiceoverWavPath = state.voiceoverWavPath,
                    exportConfig = config,
                    onProgress = { pct, stage ->
                        _uiState.update {
                            it.copy(exportState = ExportState.Running(pct, stage))
                        }
                    }
                )
            ) {
                is VideoExportResult.Success -> {
                    _uiState.update {
                        it.copy(
                            exportState = ExportState.Completed(
                                outputPath = res.cacheFilePath,
                                mediaStoreUri = res.mediaStoreUri,
                                fileSizeBytes = res.fileSizeBytes
                            ),
                            statusBanner = "Xuất video MP4 thành công!"
                        )
                    }
                }

                is VideoExportResult.Failure -> {
                    _uiState.update {
                        it.copy(exportState = ExportState.Failed(res.message))
                    }
                }
            }
        }
    }

    fun cancelVideoExport() {
        VideoExporter.cancelExport()
        _uiState.update { it.copy(exportState = ExportState.Idle) }
    }

    fun dismissExportResult() {
        _uiState.update { it.copy(exportState = ExportState.Idle) }
    }

    fun copyExportedMp4ToUri(destUri: Uri) {
        val completed = _uiState.value.exportState as? ExportState.Completed ?: return
        val context = getApplication<Application>().applicationContext
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    File(completed.outputPath).inputStream().use { input ->
                        context.contentResolver.openOutputStream(destUri)?.use { output ->
                            input.copyTo(output, bufferSize = 64 * 1024)
                        }
                    }
                    true
                }.getOrDefault(false)
            }
            _uiState.update {
                it.copy(statusBanner = if (ok) "Đã lưu bản sao MP4" else "Không thể lưu bản sao MP4")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        _uiState.value.filmstrip.forEach { frame ->
            if (!frame.bitmap.isRecycled) frame.bitmap.recycle()
        }
    }
}
