package com.example.network

import com.example.model.ApiConfig
import com.example.model.SrtSegment
import com.example.model.TargetLanguage
import com.example.model.TranslationProvider
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

sealed interface TranslationResult {
    data class Success(val translatedSegments: List<SrtSegment>) : TranslationResult
    data class Error(
        val message: String,
        val isTokenOrQuotaError: Boolean = false
    ) : TranslationResult
}

object GeminiTranslator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun translateSrt(
        apiConfig: ApiConfig,
        segments: List<SrtSegment>,
        targetLanguage: TargetLanguage,
        onBatchProgress: (Float, String) -> Unit = { _, _ -> }
    ): TranslationResult = withContext(Dispatchers.IO) {
        val trimmedKey = apiConfig.geminiApiKey.trim()
        val provider = apiConfig.translationProvider
        if (trimmedKey.isEmpty()) {
            return@withContext TranslationResult.Error(
                "Missing API Key for ${provider.displayName}. Open Settings to enter your API key."
            )
        }
        if (segments.isEmpty()) {
            return@withContext TranslationResult.Error("No subtitle segments to translate.")
        }

        val batchSize = apiConfig.translationBatchSize.coerceIn(1, 10)
        val delayMs = apiConfig.translationDelayMs.coerceIn(300L, 5000L)
        val batches = segments.chunked(batchSize)
        val allTranslated = mutableListOf<SrtSegment>()

        for ((batchIdx, batch) in batches.withIndex()) {
            val fromIdx = batch.first().index
            val toIdx = batch.last().index
            onBatchProgress(
                batchIdx.toFloat() / batches.size.toFloat(),
                "Lô ${batchIdx + 1}/${batches.size} (dòng #$fromIdx–#$toIdx) · ${provider.displayName}"
            )

            var batchAttemptResult = executeSingleBatch(
                apiConfig = apiConfig,
                batch = batch,
                targetLanguage = targetLanguage
            )

            // If transient rate limit (429), pause once and retry gently before surfacing quota/rate error
            if (batchAttemptResult is TranslationResult.Error && batchAttemptResult.isTokenOrQuotaError) {
                onBatchProgress(
                    batchIdx.toFloat() / batches.size.toFloat(),
                    "Chạm giới hạn tốc độ API · Đang tạm nghỉ 2.5s rồi thử lại lô ${batchIdx + 1}..."
                )
                delay(2500L)
                batchAttemptResult = executeSingleBatch(
                    apiConfig = apiConfig,
                    batch = batch,
                    targetLanguage = targetLanguage
                )
            }

            when (batchAttemptResult) {
                is TranslationResult.Error -> return@withContext batchAttemptResult
                is TranslationResult.Success -> allTranslated.addAll(batchAttemptResult.translatedSegments)
            }

            if (batchIdx < batches.lastIndex) {
                onBatchProgress(
                    (batchIdx + 1).toFloat() / batches.size.toFloat(),
                    "Đã dịch ${allTranslated.size}/${segments.size} dòng · Giãn cách ${delayMs}ms tránh hết token/rate limit..."
                )
                delay(delayMs)
            }
        }

        onBatchProgress(1f, "Dịch hoàn tất ${allTranslated.size} dòng")
        TranslationResult.Success(allTranslated)
    }

    private fun executeSingleBatch(
        apiConfig: ApiConfig,
        batch: List<SrtSegment>,
        targetLanguage: TargetLanguage
    ): TranslationResult {
        val inputSrt = SrtUtils.toSrtString(batch, useTranslated = false)
        val systemInstruction = """
            You are an expert audiovisual subtitle translator.
            Translate the following SRT subtitle block(s) into ${targetLanguage.displayName}.
            STRICT RULES:
            1. Preserve every subtitle index number and every timestamp line (HH:MM:SS,mmm --> HH:MM:SS,mmm) EXACTLY as given.
            2. Do NOT merge, split, add, or drop any subtitle block.
            3. Output ONLY valid SRT format. No markdown code fences, no explanations, no intro/outro text.
            4. Translate 100% of the dialogue naturally and concisely for spoken voiceover in ${targetLanguage.displayName}. Leave ZERO Chinese characters or untranslated source words in the output.
        """.trimIndent()

        return try {
            val rawText = if (apiConfig.translationProvider == TranslationProvider.GEMINI) {
                callGeminiEndpoint(apiConfig, systemInstruction, inputSrt)
            } else {
                callOpenAiCompatibleEndpoint(apiConfig, systemInstruction, inputSrt)
            }

            val parsed = SrtUtils.parseTranslatedSrtPreservingTiming(rawText, batch)
            val emptyCount = parsed.count { it.translatedText.isBlank() }
            if (emptyCount == parsed.size) {
                return TranslationResult.Error(
                    "Could not parse valid translated SRT blocks from ${apiConfig.translationProvider.displayName} response."
                )
            }

            val cleaned = parsed.map { seg ->
                val stripped = TextSanitizer.sanitizeForVoiceover(seg.translatedText)
                seg.copy(translatedText = stripped.ifBlank { seg.translatedText.trim() })
            }

            val leftoverChinese = cleaned.any { TextSanitizer.containsChineseCharacters(it.translatedText) }
            if (leftoverChinese) {
                return TranslationResult.Error(
                    "Translation output still contained source Chinese characters. Please retry."
                )
            }

            TranslationResult.Success(cleaned)
        } catch (apiEx: ApiQuotaOrTokenException) {
            TranslationResult.Error(apiEx.message ?: "API quota/token exhausted.", isTokenOrQuotaError = true)
        } catch (t: Throwable) {
            TranslationResult.Error(
                t.message ?: "Network error calling ${apiConfig.translationProvider.displayName}."
            )
        }
    }

    private fun callGeminiEndpoint(
        apiConfig: ApiConfig,
        systemInstruction: String,
        inputSrt: String
    ): String {
        val baseUrl = apiConfig.translationEndpointUrl.trim()
            .ifBlank { TranslationProvider.GEMINI.defaultEndpoint }
            .trimEnd('/')
        val model = apiConfig.geminiModel.trim().ifBlank { TranslationProvider.GEMINI.defaultModel }
        val url = if (baseUrl.contains(":generateContent")) {
            "$baseUrl?key=${apiConfig.geminiApiKey.trim()}"
        } else {
            "$baseUrl/models/$model:generateContent?key=${apiConfig.geminiApiKey.trim()}"
        }

        val requestJson = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            )
            put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", inputSrt)))
                )
            )
            put("generationConfig", JSONObject().put("temperature", 0.2))
        }

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val formatted = formatApiErrorMessage(response.code, rawBody, "Google Gemini")
                if (isQuotaOrRateLimit(response.code, rawBody)) {
                    throw ApiQuotaOrTokenException(formatted)
                }
                throw IllegalStateException(formatted)
            }

            val root = JSONObject(rawBody)
            val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
            val finishReason = candidate?.optString("finishReason").orEmpty()
            if (finishReason == "MAX_TOKENS") {
                throw ApiQuotaOrTokenException(
                    "Đạt giới hạn token đầu ra (MAX_TOKENS) của Gemini. Hãy giảm 'Số dòng mỗi lô' xuống 1–2 dòng."
                )
            }

            val text = candidate
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")
                .orEmpty()

            if (text.isBlank()) {
                throw IllegalStateException("Gemini returned an empty translation response.")
            }
            return text
        }
    }

    private fun callOpenAiCompatibleEndpoint(
        apiConfig: ApiConfig,
        systemInstruction: String,
        inputSrt: String
    ): String {
        val provider = apiConfig.translationProvider
        val endpoint = apiConfig.translationEndpointUrl.trim().ifBlank { provider.defaultEndpoint }
        val model = apiConfig.geminiModel.trim().ifBlank { provider.defaultModel }

        val requestJson = JSONObject().apply {
            put("model", model)
            put("temperature", 0.2)
            put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", systemInstruction))
                    .put(JSONObject().put("role", "user").put("content", inputSrt))
            )
        }

        val request = Request.Builder()
            .url(endpoint)
            .header("Authorization", "Bearer ${apiConfig.geminiApiKey.trim()}")
            .header("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val formatted = formatApiErrorMessage(response.code, rawBody, provider.displayName)
                if (isQuotaOrRateLimit(response.code, rawBody)) {
                    throw ApiQuotaOrTokenException(formatted)
                }
                throw IllegalStateException(formatted)
            }

            val root = JSONObject(rawBody)
            val choice = root.optJSONArray("choices")?.optJSONObject(0)
            val finishReason = choice?.optString("finish_reason").orEmpty()
            if (finishReason == "length") {
                throw ApiQuotaOrTokenException(
                    "Đạt giới hạn token đầu ra (finish_reason: length) của ${provider.displayName}. Hãy giảm 'Số dòng mỗi lô'."
                )
            }

            val text = choice
                ?.optJSONObject("message")
                ?.optString("content")
                .orEmpty()

            if (text.isBlank()) {
                throw IllegalStateException("${provider.displayName} returned an empty translation response.")
            }
            return text
        }
    }

    private class ApiQuotaOrTokenException(message: String) : Exception(message)

    fun isQuotaOrRateLimit(httpCode: Int, rawBody: String): Boolean {
        if (httpCode == 429 || httpCode == 402) return true
        val lower = rawBody.lowercase(Locale.US)
        return lower.contains("insufficient_quota") ||
            lower.contains("resource_exhausted") ||
            lower.contains("rate_limit") ||
            lower.contains("quota") ||
            lower.contains("token") && lower.contains("limit") ||
            lower.contains("insufficient balance") ||
            lower.contains("credit")
    }

    fun formatApiErrorMessage(httpCode: Int, rawBody: String, providerName: String): String {
        val parsedMsg = runCatching {
            val json = JSONObject(rawBody)
            json.optJSONObject("error")?.optString("message")
                ?.takeIf { it.isNotBlank() }
                ?: json.optString("message").takeIf { it.isNotBlank() }
        }.getOrNull().orEmpty()

        val lower = (rawBody + " " + parsedMsg).lowercase(Locale.US)
        return when {
            httpCode == 402 || lower.contains("insufficient_quota") || lower.contains("insufficient balance") || lower.contains("credit") ->
                "Hết token / hết số dư tài khoản $providerName (HTTP $httpCode).\nChi tiết: ${parsedMsg.ifBlank { "Quota / credit exhausted." }}"
            httpCode == 429 || lower.contains("resource_exhausted") || lower.contains("rate_limit") || lower.contains("quota") ->
                "Hết token miễn phí hoặc chạm giới hạn tốc độ $providerName (HTTP 429).\nHãy tăng 'Giãn cách giữa các lô (ms)' hoặc đổi API Key/Nhà cung cấp.\nChi tiết: ${parsedMsg.ifBlank { "Rate limit / quota exceeded." }}"
            httpCode == 401 || httpCode == 403 ->
                "API Key $providerName không hợp lệ hoặc bị từ chối quyền (HTTP $httpCode).\nChi tiết: ${parsedMsg.ifBlank { "Unauthorized" }}"
            lower.contains("context_length") || lower.contains("max_tokens") ->
                "Vượt quá giới hạn token ngữ cảnh của $providerName.\nChi tiết: $parsedMsg"
            else ->
                "$providerName lỗi (HTTP $httpCode): ${parsedMsg.ifBlank { rawBody.take(200) }}"
        }
    }
}
