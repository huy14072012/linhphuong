package com.example.network

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import com.example.model.ApiConfig
import com.example.model.SrtSegment
import com.example.model.TargetLanguage
import com.example.model.TtsEngineMode
import com.example.model.TtsPayloadPreset
import com.example.model.VoiceOption
import com.example.util.SanitationResult
import com.example.util.TextSanitizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.abs

object VoiceCatalog {
    val voices: List<VoiceOption> = listOf(
        VoiceOption(
            id = "ngoc_huyen",
            name = "Ngọc Huyền",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nữ",
            style = "Ấm áp, truyền cảm · Miễn phí",
            apiVoiceCode = "ngoc_huyen",
            pitch = 1.08f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "nam_minh",
            name = "Nam Minh",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nam",
            style = "Rõ ràng, tin tức · Miễn phí",
            apiVoiceCode = "nam_minh",
            pitch = 0.88f,
            speechRate = 1.03f
        ),
        VoiceOption(
            id = "hoai_tay",
            name = "Hoài Tây",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nam",
            style = "Trầm ấm, kể chuyện · Miễn phí",
            apiVoiceCode = "hoai_tay",
            pitch = 0.80f,
            speechRate = 0.94f
        ),
        VoiceOption(
            id = "linh_dan",
            name = "Linh Đan",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nữ",
            style = "Tươi sáng, vlog · Miễn phí",
            apiVoiceCode = "linh_dan",
            pitch = 1.15f,
            speechRate = 1.06f
        ),
        VoiceOption(
            id = "adam",
            name = "Adam",
            language = "English (US)",
            languageCode = "en",
            gender = "Male",
            style = "Deep Studio Narrator",
            apiVoiceCode = "adam",
            pitch = 0.85f,
            speechRate = 0.96f
        ),
        VoiceOption(
            id = "rachel",
            name = "Rachel",
            language = "English (US)",
            languageCode = "en",
            gender = "Female",
            style = "Conversational Clear",
            apiVoiceCode = "rachel",
            pitch = 1.06f,
            speechRate = 1.02f
        ),
        VoiceOption(
            id = "bella",
            name = "Bella",
            language = "English (UK)",
            languageCode = "en",
            gender = "Female",
            style = "Soft Storytelling",
            apiVoiceCode = "bella",
            pitch = 1.10f,
            speechRate = 0.96f
        ),
        VoiceOption(
            id = "antoni",
            name = "Antoni",
            language = "English (US)",
            languageCode = "en",
            gender = "Male",
            style = "Expressive Creator",
            apiVoiceCode = "antoni",
            pitch = 0.94f,
            speechRate = 1.04f
        ),
        VoiceOption(
            id = "josh",
            name = "Josh",
            language = "English (US)",
            languageCode = "en",
            gender = "Male",
            style = "Energetic Host",
            apiVoiceCode = "josh",
            pitch = 0.92f,
            speechRate = 1.08f
        ),
        VoiceOption(
            id = "aria",
            name = "Aria",
            language = "English (AU)",
            languageCode = "en",
            gender = "Female",
            style = "Crisp Tutorial",
            apiVoiceCode = "aria",
            pitch = 1.04f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "sora",
            name = "Sora",
            language = "日本語",
            languageCode = "ja",
            gender = "Female",
            style = "Gentle Lifestyle",
            apiVoiceCode = "sora",
            pitch = 1.08f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "kenji",
            name = "Kenji",
            language = "日本語",
            languageCode = "ja",
            gender = "Male",
            style = "Studio Commercial",
            apiVoiceCode = "kenji",
            pitch = 0.88f,
            speechRate = 1.02f
        ),
        VoiceOption(
            id = "elena",
            name = "Elena",
            language = "Español",
            languageCode = "es",
            gender = "Female",
            style = "Warm Editorial",
            apiVoiceCode = "elena",
            pitch = 1.05f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "lucas",
            name = "Lucas",
            language = "Français",
            languageCode = "fr",
            gender = "Male",
            style = "Smooth Cinema",
            apiVoiceCode = "lucas",
            pitch = 0.90f,
            speechRate = 0.98f
        )
    )

    fun findById(id: String): VoiceOption = voices.find { it.id == id } ?: voices.first()
}

sealed interface VoiceoverResult {
    data class Success(
        val masterWavPath: String,
        val updatedSegments: List<SrtSegment>,
        val waveformPeaks: List<Float>,
        val voiceName: String
    ) : VoiceoverResult

    data class Error(val message: String) : VoiceoverResult
}

object VoiceoverGenerator {

    private const val MASTER_SAMPLE_RATE = 24_000
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun generateTimelineVoiceover(
        context: Context,
        segments: List<SrtSegment>,
        totalVideoDurationMs: Long,
        voice: VoiceOption,
        targetLanguage: TargetLanguage,
        apiConfig: ApiConfig,
        onProgress: (Float, String) -> Unit
    ): VoiceoverResult = withContext(Dispatchers.IO) {
        // 1. Strict Language Sanitation Rule: ZERO Chinese characters allowed
        val sanitizedSegments = when (val check = TextSanitizer.validateSanitizedVoiceoverScript(segments)) {
            is SanitationResult.Blocked -> return@withContext VoiceoverResult.Error(check.reason)
            is SanitationResult.Valid -> check.sanitizedSegments
        }

        if (apiConfig.ttsEngineMode == TtsEngineMode.CONFIGURABLE_API &&
            apiConfig.ttsEndpointUrl.trim().isBlank()
        ) {
            return@withContext VoiceoverResult.Error(
                "TTS API Endpoint URL đang trống. Hãy chọn chế độ 'Miễn phí có sẵn trên máy' hoặc nhập Endpoint URL trong Cài đặt."
            )
        }

        val voDir = File(context.cacheDir, "voiceover").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        val segmentPcmMap = mutableMapOf<Int, ShortArray>()
        val updatedSegments = mutableListOf<SrtSegment>()
        var ttsEngine: TextToSpeech? = null

        try {
            if (apiConfig.ttsEngineMode == TtsEngineMode.FREE_BUILTIN_TTS) {
                ttsEngine = initAndConfigureBuiltinTts(context, voice, targetLanguage)
                if (ttsEngine == null) {
                    return@withContext VoiceoverResult.Error(
                        "Không thể khởi tạo bộ đọc giọng nói TextToSpeech trên thiết bị. Hãy kiểm tra cài đặt Google Speech Services trên máy."
                    )
                }
            }

            sanitizedSegments.forEachIndexed { idx, segment ->
                onProgress(
                    (idx.toFloat() / sanitizedSegments.size.toFloat()) * 0.85f,
                    "Đang tạo giọng ${voice.name} · ${idx + 1}/${sanitizedSegments.size}"
                )

                val clipFile = File(voDir, "seg_${segment.index}.wav")
                if (apiConfig.ttsEngineMode == TtsEngineMode.CONFIGURABLE_API) {
                    synthesizeViaRemoteApi(
                        endpointUrl = apiConfig.ttsEndpointUrl.trim(),
                        apiKey = apiConfig.ttsApiKey.trim(),
                        preset = apiConfig.ttsPayloadPreset,
                        voice = voice,
                        text = segment.translatedText,
                        outFile = clipFile
                    )
                } else {
                    val ok = synthesizeViaSystemTts(ttsEngine!!, segment.translatedText, clipFile)
                    if (!ok || !clipFile.exists() || clipFile.length() == 0L) {
                        throw IllegalStateException(
                            "Thiết bị không thể tạo âm thanh cho dòng #${segment.index}. Vui lòng kiểm tra gói giọng nói (${targetLanguage.displayName}) trong Cài đặt Text-to-Speech của Android."
                        )
                    }
                }

                val pcm = decodeAudioFileToMono24kPcm(clipFile)
                val durationMs = ((pcm.size * 1000L) / MASTER_SAMPLE_RATE).coerceAtLeast(100L)
                segmentPcmMap[segment.index] = pcm
                updatedSegments.add(
                    segment.copy(
                        voiceoverAudioPath = clipFile.absolutePath,
                        voiceoverDurationMs = durationMs
                    )
                )
            }

            onProgress(0.92f, "Đang ghép giọng đọc vào Timeline...")
            val safeDurationMs = maxOf(
                totalVideoDurationMs,
                updatedSegments.maxOfOrNull { maxOf(it.endMs, it.startMs + it.voiceoverDurationMs) } ?: 1000L
            )
            val totalSamples = ((safeDurationMs * MASTER_SAMPLE_RATE) / 1000L).toInt()
                .coerceAtLeast(MASTER_SAMPLE_RATE)
            val masterSamples = ShortArray(totalSamples)

            for (seg in updatedSegments) {
                val segPcm = segmentPcmMap[seg.index] ?: continue
                val startSample = ((seg.startMs * MASTER_SAMPLE_RATE) / 1000L).toInt()
                    .coerceIn(0, (totalSamples - 1).coerceAtLeast(0))
                for (i in segPcm.indices) {
                    val dst = startSample + i
                    if (dst >= totalSamples) break
                    val mixed = masterSamples[dst].toInt() + segPcm[i].toInt()
                    masterSamples[dst] = mixed.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }
            }

            val masterWav = File(voDir, "voiceover_master.wav")
            writeMonoWav(masterWav, masterSamples, MASTER_SAMPLE_RATE)

            val peaks = computeWaveformPeaks(masterSamples, 72)
            onProgress(1f, "Hoàn tất lồng tiếng")
            VoiceoverResult.Success(
                masterWavPath = masterWav.absolutePath,
                updatedSegments = updatedSegments,
                waveformPeaks = peaks,
                voiceName = voice.name
            )
        } catch (t: Throwable) {
            VoiceoverResult.Error(t.message ?: "Voiceover generation failed.")
        } finally {
            runCatching { ttsEngine?.shutdown() }
        }
    }

    private fun synthesizeViaRemoteApi(
        endpointUrl: String,
        apiKey: String,
        preset: TtsPayloadPreset,
        voice: VoiceOption,
        text: String,
        outFile: File
    ) {
        if (TextSanitizer.containsChineseCharacters(text)) {
            throw IllegalStateException("Blocked: source Chinese characters detected in TTS payload.")
        }

        val jsonBody = when (preset) {
            TtsPayloadPreset.OPENAI_COMPATIBLE -> JSONObject()
                .put("model", "tts-1")
                .put("voice", voice.apiVoiceCode)
                .put("input", text)
                .put("response_format", "wav")
            TtsPayloadPreset.CUSTOM_JSON -> JSONObject()
                .put("voice", voice.name)
                .put("voice_id", voice.apiVoiceCode)
                .put("text", text)
                .put("format", "wav")
            TtsPayloadPreset.ELEVENLABS_STYLE -> JSONObject()
                .put("text", text)
                .put("model_id", "eleven_multilingual_v2")
                .put("voice", voice.apiVoiceCode)
        }

        val reqBuilder = Request.Builder()
            .url(endpointUrl)
            .post(jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))

        if (apiKey.isNotBlank()) {
            if (preset == TtsPayloadPreset.ELEVENLABS_STYLE) {
                reqBuilder.header("xi-api-key", apiKey)
            } else {
                reqBuilder.header("Authorization", "Bearer $apiKey")
            }
        }

        httpClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                val errBody = resp.body?.string().orEmpty().take(200)
                throw IllegalStateException("TTS endpoint error (${resp.code}): $errBody")
            }

            val contentType = resp.header("Content-Type").orEmpty().lowercase(Locale.US)
            val bytes = resp.body?.bytes() ?: throw IllegalStateException("Empty TTS audio response")

            if (contentType.contains("application/json")) {
                val json = JSONObject(String(bytes, Charsets.UTF_8))
                val b64 = json.optString("audioContent")
                    .ifBlank { json.optString("audio") }
                    .ifBlank { json.optString("data") }
                if (b64.isBlank()) {
                    throw IllegalStateException("TTS JSON response missing audio base64 field.")
                }
                val decoded = Base64.decode(b64, Base64.DEFAULT)
                FileOutputStream(outFile).use { it.write(decoded) }
            } else {
                FileOutputStream(outFile).use { it.write(bytes) }
            }
        }
    }

    private suspend fun initAndConfigureBuiltinTts(
        context: Context,
        voice: VoiceOption,
        targetLanguage: TargetLanguage
    ): TextToSpeech? = suspendCancellableCoroutine { cont ->
        var ttsRef: TextToSpeech? = null
        ttsRef = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val desiredLocale = localeForCode(targetLanguage.code)
                val langSupport = ttsRef?.setLanguage(desiredLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (langSupport == TextToSpeech.LANG_MISSING_DATA ||
                    langSupport == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    // Fallback gracefully to the voice's language or device default locale
                    val voiceLocale = localeForCode(voice.languageCode)
                    val voiceLangSupport = ttsRef?.setLanguage(voiceLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                    if (voiceLangSupport == TextToSpeech.LANG_MISSING_DATA ||
                        voiceLangSupport == TextToSpeech.LANG_NOT_SUPPORTED
                    ) {
                        ttsRef?.setLanguage(Locale.getDefault())
                    }
                }

                // Map Ngọc Huyền, Nam Minh, Hoài Tây, etc. to best matching device Voice + pitch/rate
                runCatching {
                    val availableVoices = ttsRef?.voices.orEmpty()
                    val bestDeviceVoice = selectBestDeviceVoice(
                        availableVoices = availableVoices,
                        preferredLangCode = targetLanguage.code,
                        voiceOption = voice
                    )
                    if (bestDeviceVoice != null) {
                        ttsRef?.voice = bestDeviceVoice
                    }
                }

                ttsRef?.setPitch(voice.pitch)
                ttsRef?.setSpeechRate(voice.speechRate)

                if (cont.isActive) cont.resume(ttsRef)
            } else {
                if (cont.isActive) cont.resume(null)
            }
        }
        cont.invokeOnCancellation { runCatching { ttsRef?.shutdown() } }
    }

    private fun selectBestDeviceVoice(
        availableVoices: Set<Voice>,
        preferredLangCode: String,
        voiceOption: VoiceOption
    ): Voice? {
        if (availableVoices.isEmpty()) return null
        val langVoices = availableVoices.filter {
            it.locale.language.equals(preferredLangCode, ignoreCase = true) ||
                it.locale.language.equals(voiceOption.languageCode, ignoreCase = true)
        }
        val pool = langVoices.ifEmpty { availableVoices.toList() }
        val isMaleTarget = voiceOption.gender.contains("Nam", ignoreCase = true) ||
            voiceOption.gender.contains("Male", ignoreCase = true)

        // Match male/female Google TTS voice naming patterns (e.g., vi-vn-x-gft/vie vs vid/vic)
        val matched = pool.firstOrNull { v ->
            val nameLower = v.name.lowercase(Locale.US)
            if (isMaleTarget) {
                nameLower.contains("male") || nameLower.contains("-vid-") ||
                    nameLower.contains("-vic-") || nameLower.contains("b-local") ||
                    nameLower.contains("d-local")
            } else {
                nameLower.contains("female") || nameLower.contains("-gft-") ||
                    nameLower.contains("-vie-") || nameLower.contains("a-local") ||
                    nameLower.contains("c-local")
            }
        }
        return matched ?: pool.firstOrNull { !it.isNetworkConnectionRequired } ?: pool.firstOrNull()
    }

    private fun localeForCode(code: String): Locale = when (code.lowercase(Locale.US)) {
        "vi" -> Locale("vi", "VN")
        "en" -> Locale.US
        "es" -> Locale("es", "ES")
        "fr" -> Locale.FRENCH
        "ja" -> Locale.JAPANESE
        "ko" -> Locale.KOREAN
        "th" -> Locale("th", "TH")
        "id" -> Locale("in", "ID")
        else -> Locale.getDefault()
    }

    private suspend fun synthesizeViaSystemTts(
        tts: TextToSpeech,
        text: String,
        outFile: File
    ): Boolean = suspendCancellableCoroutine { cont ->
        val utteranceId = "utt_${System.nanoTime()}"
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId && cont.isActive) cont.resume(true)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                if (id == utteranceId && cont.isActive) cont.resume(false)
            }
            override fun onError(id: String?, errorCode: Int) {
                if (id == utteranceId && cont.isActive) cont.resume(false)
            }
        })
        val params = Bundle()
        val result = tts.synthesizeToFile(text, params, outFile, utteranceId)
        if (result != TextToSpeech.SUCCESS && cont.isActive) {
            cont.resume(false)
        }
    }

    private fun decodeAudioFileToMono24kPcm(file: File): ShortArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(file.absolutePath)
            var audioIdx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val trackFmt = extractor.getTrackFormat(i)
                if (trackFmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    audioIdx = i
                    fmt = trackFmt
                    break
                }
            }
            if (audioIdx < 0 || fmt == null) return ShortArray(0)

            extractor.selectTrack(audioIdx)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            var srcSampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var srcChannels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            codec = MediaCodec.createDecoderByType(mime).apply {
                configure(fmt, null, null, 0)
                start()
            }

            val pcmOut = ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000L)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(inBuf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 10_000L)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFmt = codec.outputFormat
                    if (newFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        srcSampleRate = newFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        srcChannels = newFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && info.size > 0) {
                        val chunk = ByteArray(info.size)
                        outBuf.position(info.offset)
                        outBuf.get(chunk)
                        pcmOut.write(chunk)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                }
            }

            val rawBytes = pcmOut.toByteArray()
            val shortCount = rawBytes.size / 2
            val rawShorts = ShortArray(shortCount)
            ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(rawShorts)

            val monoCount = shortCount / srcChannels.coerceAtLeast(1)
            val mono = ShortArray(monoCount) { i ->
                var sum = 0
                for (c in 0 until srcChannels) {
                    sum += rawShorts[i * srcChannels + c].toInt()
                }
                (sum / srcChannels.coerceAtLeast(1)).toShort()
            }

            if (srcSampleRate == MASTER_SAMPLE_RATE || mono.isEmpty()) return mono
            val outLen = ((mono.size.toLong() * MASTER_SAMPLE_RATE) / srcSampleRate.coerceAtLeast(8000)).toInt()
                .coerceAtLeast(1)
            return ShortArray(outLen) { i ->
                val srcPos = (i.toDouble() * srcSampleRate) / MASTER_SAMPLE_RATE
                val idx0 = srcPos.toInt().coerceIn(0, mono.lastIndex)
                val idx1 = (idx0 + 1).coerceIn(0, mono.lastIndex)
                val frac = srcPos - idx0
                ((mono[idx0] * (1.0 - frac)) + (mono[idx1] * frac)).toInt().toShort()
            }
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun writeMonoWav(file: File, samples: ShortArray, sampleRate: Int) {
        val dataSize = samples.size * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(36 + dataSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16)
            putShort(1)
            putShort(1)
            putInt(sampleRate)
            putInt(sampleRate * 2)
            putShort(2)
            putShort(16)
            put("data".toByteArray())
            putInt(dataSize)
        }
        FileOutputStream(file).use { fos ->
            fos.write(header.array())
            val buf = ByteBuffer.allocate(minOf(dataSize, 32768)).order(ByteOrder.LITTLE_ENDIAN)
            var idx = 0
            while (idx < samples.size) {
                buf.clear()
                while (buf.hasRemaining() && idx < samples.size) {
                    buf.putShort(samples[idx++])
                }
                fos.write(buf.array(), 0, buf.position())
            }
        }
    }

    private fun computeWaveformPeaks(samples: ShortArray, buckets: Int): List<Float> {
        if (samples.isEmpty()) return emptyList()
        val step = (samples.size / buckets).coerceAtLeast(1)
        val raw = List(buckets) { b ->
            val start = (b * step).coerceIn(0, samples.lastIndex)
            val end = ((b + 1) * step).coerceAtMost(samples.size)
            var peak = 0
            for (i in start until end) {
                val v = abs(samples[i].toInt())
                if (v > peak) peak = v
            }
            peak / 32768f
        }
        val maxVal = raw.maxOrNull()?.coerceAtLeast(0.05f) ?: 0.05f
        return raw.map { (it / maxVal).coerceIn(0.05f, 1f) }
    }
}
