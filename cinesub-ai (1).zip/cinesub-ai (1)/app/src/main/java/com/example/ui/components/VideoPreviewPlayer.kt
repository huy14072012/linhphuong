package com.example.ui.components

import androidx.annotation.OptIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.model.AppLanguage
import com.example.model.NormalizedRect
import com.example.model.SrtSegment
import com.example.model.VideoMetadata
import com.example.model.WorkflowStep
import com.example.ui.theme.MatchaGreenDark
import com.example.ui.theme.MatchaGreenDeep
import com.example.ui.theme.MatchaLightBg
import com.example.ui.theme.MatchaMutedText
import com.example.ui.theme.MatchaOnDark
import com.example.ui.theme.MatchaOutline
import com.example.ui.theme.MatchaSurface
import com.example.ui.theme.MatchaSurfaceContainer
import com.example.ui.theme.PeachPink
import com.example.ui.theme.PeachPinkSoft
import com.example.ui.theme.StudioPreviewBg
import com.example.util.LocalAppStrings
import com.example.util.SrtUtils
import kotlin.math.hypot

@Composable
fun StudioTopBar(
    appLanguage: AppLanguage,
    workflowStep: WorkflowStep,
    videoMetadata: VideoMetadata?,
    onSelectAppLanguage: (AppLanguage) -> Unit,
    onOpenSettings: () -> Unit,
    onExportClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    var showLangMenu by remember { mutableStateOf(false) }

    Surface(
        color = MatchaGreenDark,
        contentColor = MatchaOnDark,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(PeachPink),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.MovieCreation,
                        contentDescription = null,
                        tint = MatchaGreenDeep,
                        modifier = Modifier.size(19.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = strings.appName,
                            style = MaterialTheme.typography.titleMedium,
                            color = MatchaOnDark,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MatchaGreenDeep.copy(alpha = 0.65f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "B${workflowStep.stepNumber}/5 · ${strings.stepShortLabels[workflowStep].orEmpty()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = PeachPinkSoft,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (videoMetadata != null) {
                        Text(
                            text = "${SrtUtils.formatCompactTime(videoMetadata.durationMs)} · ${videoMetadata.resolutionLabel} · ${videoMetadata.fpsLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MatchaLightBg.copy(alpha = 0.85f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Text(
                            text = strings.studioSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaLightBg.copy(alpha = 0.82f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // App UI Language Switcher (Vietnamese default)
                Box {
                    Surface(
                        onClick = { showLangMenu = true },
                        color = MatchaGreenDeep.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("app_language_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Language,
                                contentDescription = strings.appLanguageSection,
                                tint = PeachPinkSoft,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = appLanguage.shortBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = MatchaOnDark,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    DropdownMenu(
                        expanded = showLangMenu,
                        onDismissRequest = { showLangMenu = false }
                    ) {
                        AppLanguage.entries.forEach { lang ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = lang.displayName,
                                        fontWeight = if (lang == appLanguage) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSelectAppLanguage(lang)
                                    showLangMenu = false
                                }
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = strings.apiSettings,
                        tint = MatchaOnDark
                    )
                }

                Button(
                    onClick = onExportClick,
                    enabled = videoMetadata != null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PeachPink,
                        contentColor = MatchaGreenDeep,
                        disabledContainerColor = MatchaGreenDeep.copy(alpha = 0.4f),
                        disabledContentColor = MatchaOnDark.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("export_mp4_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.FileUpload,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = strings.exportMp4,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun VideoPreviewStage(
    exoPlayer: ExoPlayer,
    videoMetadata: VideoMetadata?,
    isPlaying: Boolean,
    playbackPositionMs: Long,
    cropBox: NormalizedRect,
    showOcrBox: Boolean,
    activeSubtitle: SrtSegment?,
    hasVoiceover: Boolean,
    previewWithVoiceover: Boolean,
    onImportClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onCropBoxChange: (NormalizedRect) -> Unit,
    onResetCropBox: () -> Unit,
    onToggleOcrBox: () -> Unit,
    onToggleVoiceoverPreview: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        // Pure unobstructed Video Viewport (NO dark scrims, NO floating subtitle boxes or control bars on top of the video)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .clip(RoundedCornerShape(16.dp))
                .background(StudioPreviewBg)
                .border(1.5.dp, MatchaGreenDark.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (videoMetadata == null) {
                EmptyVideoImportStage(onImportClick = onImportClick)
            } else {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        }
                    },
                    update = { view ->
                        if (view.player !== exoPlayer) {
                            view.player = exoPlayer
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // Ultra-thin transparent outline only for direct drag/resize without obscuring any pixels
                if (showOcrBox) {
                    OcrBoundingBoxOutlineOverlay(
                        cropBox = cropBox,
                        onCropBoxChange = onCropBoxChange,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Live Subtitle Preview Strip MOVED BELOW Video Viewport so it NEVER covers video/subtitles
        if (videoMetadata != null) {
            Surface(
                color = StudioPreviewBg,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, MatchaGreenDark.copy(alpha = 0.45f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("below_video_subtitle_strip")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Subtitles,
                        contentDescription = null,
                        tint = PeachPink,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val subText = activeSubtitle?.displayText?.trim().orEmpty()
                    Text(
                        text = subText.ifEmpty { strings.subtitlePreviewEmpty },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (subText.isNotEmpty()) Color.White else MatchaLightBg.copy(alpha = 0.55f),
                        fontWeight = if (subText.isNotEmpty()) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }

        // Playback & Box Toggle Control Bar (BELOW video)
        Surface(
            color = MatchaSurfaceContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onPlayPauseClick,
                        enabled = videoMetadata != null,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = if (videoMetadata != null) MatchaGreenDeep else MatchaGreenDeep.copy(alpha = 0.35f)
                        )
                    }

                    Text(
                        text = if (videoMetadata != null) {
                            "${SrtUtils.formatCompactTime(playbackPositionMs)} / ${SrtUtils.formatCompactTime(videoMetadata.durationMs)}"
                        } else {
                            "00:00.0 / 00:00.0"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MatchaGreenDeep,
                        fontSize = 12.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (hasVoiceover) {
                        Surface(
                            color = if (previewWithVoiceover) PeachPink else MatchaLightBg,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onToggleVoiceoverPreview)
                                .testTag("toggle_voiceover_preview")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (previewWithVoiceover) Icons.Filled.RecordVoiceOver else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Toggle preview audio",
                                    tint = MatchaGreenDeep,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (previewWithVoiceover) strings.voAudioToggle else strings.origAudioToggle,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MatchaGreenDeep
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Surface(
                        color = if (showOcrBox && videoMetadata != null) PeachPinkSoft else MatchaLightBg,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = videoMetadata != null, onClick = onToggleOcrBox)
                            .testTag("toggle_ocr_box_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CropFree,
                                contentDescription = strings.boxOn,
                                tint = MatchaGreenDeep,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (showOcrBox) strings.boxOn else strings.boxOff,
                                style = MaterialTheme.typography.labelMedium,
                                color = MatchaGreenDeep
                            )
                        }
                    }

                    if (videoMetadata != null) {
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(
                            onClick = onImportClick,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("replace_video_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VideoFile,
                                contentDescription = strings.replaceVideo,
                                tint = MatchaGreenDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // OCR Box Adjustment Panel MOVED BELOW the video viewport so controls never overlap video/subtitles
        if (videoMetadata != null && showOcrBox) {
            Spacer(modifier = Modifier.height(6.dp))
            OcrBoxAdjustmentPanel(
                cropBox = cropBox,
                onCropBoxChange = onCropBoxChange,
                onReset = onResetCropBox
            )
        }
    }
}

@Composable
private fun OcrBoxAdjustmentPanel(
    cropBox: NormalizedRect,
    onCropBoxChange: (NormalizedRect) -> Unit,
    onReset: () -> Unit
) {
    val strings = LocalAppStrings.current
    Surface(
        color = MatchaSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MatchaOutline.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ocr_adjustment_panel_below_video")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.adjustBoxTitle,
                    style = MaterialTheme.typography.labelMedium,
                    color = MatchaGreenDeep,
                    fontWeight = FontWeight.SemiBold
                )
                TextButton(
                    onClick = onReset,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                    modifier = Modifier.height(26.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        tint = MatchaGreenDark,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = strings.resetBox,
                        style = MaterialTheme.typography.labelSmall,
                        color = MatchaGreenDark
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompactSliderControl(
                    label = "Y",
                    value = cropBox.top,
                    valueRange = 0f..0.88f,
                    onValueChange = { newTop ->
                        val h = cropBox.height
                        val clampedTop = newTop.coerceIn(0f, 1f - h)
                        onCropBoxChange(cropBox.copy(top = clampedTop, bottom = clampedTop + h))
                    },
                    modifier = Modifier.weight(1f)
                )
                CompactSliderControl(
                    label = "H",
                    value = cropBox.height,
                    valueRange = 0.08f..0.55f,
                    onValueChange = { newH ->
                        val newBottom = (cropBox.top + newH).coerceAtMost(1f)
                        val newTop = (newBottom - newH).coerceAtLeast(0f)
                        onCropBoxChange(cropBox.copy(top = newTop, bottom = newBottom))
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompactSliderControl(
                    label = "X",
                    value = cropBox.left,
                    valueRange = 0f..0.85f,
                    onValueChange = { newLeft ->
                        val w = cropBox.width
                        val clampedLeft = newLeft.coerceIn(0f, 1f - w)
                        onCropBoxChange(cropBox.copy(left = clampedLeft, right = clampedLeft + w))
                    },
                    modifier = Modifier.weight(1f)
                )
                CompactSliderControl(
                    label = "W",
                    value = cropBox.width,
                    valueRange = 0.15f..1f,
                    onValueChange = { newW ->
                        val newRight = (cropBox.left + newW).coerceAtMost(1f)
                        val newLeft = (newRight - newW).coerceAtLeast(0f)
                        onCropBoxChange(cropBox.copy(left = newLeft, right = newRight))
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun CompactSliderControl(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MatchaMutedText,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(16.dp)
        )
        Slider(
            value = value.coerceIn(valueRange.start, valueRange.endInclusive),
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = PeachPink,
                activeTrackColor = MatchaGreenDark,
                inactiveTrackColor = MatchaSurfaceContainer
            ),
            modifier = Modifier
                .weight(1f)
                .height(26.dp)
        )
    }
}

@Composable
private fun EmptyVideoImportStage(onImportClick: () -> Unit) {
    val strings = LocalAppStrings.current
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(MatchaGreenDark.copy(alpha = 0.35f))
                .border(1.5.dp, PeachPink, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.VideoFile,
                contentDescription = null,
                tint = PeachPink,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = strings.emptyTitle,
            style = MaterialTheme.typography.titleMedium,
            color = MatchaLightBg,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = strings.emptySubtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MatchaLightBg.copy(alpha = 0.72f),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))
        Button(
            onClick = onImportClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = PeachPink,
                contentColor = MatchaGreenDeep
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("import_video_button")
        ) {
            Icon(
                imageVector = Icons.Filled.VideoFile,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = strings.importVideo,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

private enum class DragHandleMode {
    NONE,
    MOVE,
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT
}

/**
 * Clean, transparent dashed border outline ONLY — zero dark overlay and zero floating labels
 * inside the video viewport so the video & subtitles are never covered.
 */
@Composable
fun OcrBoundingBoxOutlineOverlay(
    cropBox: NormalizedRect,
    onCropBoxChange: (NormalizedRect) -> Unit,
    modifier: Modifier = Modifier
) {
    val latestBox by rememberUpdatedState(cropBox)
    val latestOnChange by rememberUpdatedState(onCropBoxChange)
    var dragMode by remember { mutableStateOf(DragHandleMode.NONE) }
    val touchThresholdPx = with(LocalDensity.current) { 26.dp.toPx() }

    BoxWithConstraints(modifier = modifier) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val b = latestBox
                            val l = b.left * widthPx
                            val t = b.top * heightPx
                            val r = b.right * widthPx
                            val bt = b.bottom * heightPx
                            dragMode = when {
                                hypot(offset.x - l, offset.y - t) <= touchThresholdPx -> DragHandleMode.TOP_LEFT
                                hypot(offset.x - r, offset.y - t) <= touchThresholdPx -> DragHandleMode.TOP_RIGHT
                                hypot(offset.x - l, offset.y - bt) <= touchThresholdPx -> DragHandleMode.BOTTOM_LEFT
                                hypot(offset.x - r, offset.y - bt) <= touchThresholdPx -> DragHandleMode.BOTTOM_RIGHT
                                offset.x in (l - 12f)..(r + 12f) && offset.y in (t - 12f)..(bt + 12f) -> DragHandleMode.MOVE
                                else -> DragHandleMode.NONE
                            }
                        },
                        onDragEnd = { dragMode = DragHandleMode.NONE },
                        onDragCancel = { dragMode = DragHandleMode.NONE },
                        onDrag = { change, dragAmount ->
                            if (dragMode == DragHandleMode.NONE) return@detectDragGestures
                            change.consume()
                            val dx = dragAmount.x / widthPx
                            val dy = dragAmount.y / heightPx
                            val b = latestBox
                            val updated = when (dragMode) {
                                DragHandleMode.MOVE -> {
                                    val w = b.width
                                    val h = b.height
                                    val newL = (b.left + dx).coerceIn(0f, 1f - w)
                                    val newT = (b.top + dy).coerceIn(0f, 1f - h)
                                    NormalizedRect(newL, newT, newL + w, newT + h)
                                }
                                DragHandleMode.TOP_LEFT -> NormalizedRect(
                                    left = (b.left + dx).coerceIn(0f, b.right - 0.12f),
                                    top = (b.top + dy).coerceIn(0f, b.bottom - 0.08f),
                                    right = b.right,
                                    bottom = b.bottom
                                )
                                DragHandleMode.TOP_RIGHT -> NormalizedRect(
                                    left = b.left,
                                    top = (b.top + dy).coerceIn(0f, b.bottom - 0.08f),
                                    right = (b.right + dx).coerceIn(b.left + 0.12f, 1f),
                                    bottom = b.bottom
                                )
                                DragHandleMode.BOTTOM_LEFT -> NormalizedRect(
                                    left = (b.left + dx).coerceIn(0f, b.right - 0.12f),
                                    top = b.top,
                                    right = b.right,
                                    bottom = (b.bottom + dy).coerceIn(b.top + 0.08f, 1f)
                                )
                                DragHandleMode.BOTTOM_RIGHT -> NormalizedRect(
                                    left = b.left,
                                    top = b.top,
                                    right = (b.right + dx).coerceIn(b.left + 0.12f, 1f),
                                    bottom = (b.bottom + dy).coerceIn(b.top + 0.08f, 1f)
                                )
                                DragHandleMode.NONE -> b
                            }
                            latestOnChange(updated.clamped())
                        }
                    )
                }
        ) {
            val l = cropBox.left * size.width
            val t = cropBox.top * size.height
            val r = cropBox.right * size.width
            val b = cropBox.bottom * size.height

            drawRect(
                color = PeachPink,
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
                )
            )

            val handleRadius = 5.5.dp.toPx()
            listOf(
                Offset(l, t),
                Offset(r, t),
                Offset(l, b),
                Offset(r, b)
            ).forEach { corner ->
                drawCircle(color = PeachPink, radius = handleRadius, center = corner)
            }
        }
    }
}
