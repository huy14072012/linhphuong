package com.example.media

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import com.example.model.ApiConfig
import com.example.model.SourceLanguage
import com.example.model.SrtSegment
import com.example.model.TranslationProvider
import com.example.util.SrtUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.sqrt

sealed interface AudioSrtResult {
    data class Success(
        val segments: List<SrtSegment>,
        val waveformPeaks: List<Float>
    ) : AudioSrtResult

    data class MissingSpeechModel(val message: String) : AudioSrtResult
    data class Error(val message: String) : AudioSrtResult
}

/**
 * Decodes local video audio track via MediaExtractor + MediaCodec into 16kHz mono 16-bit PCM,
 * segments speech intervals via RMS VAD, and recognizes actual spoken dialogue using:
 * 1) Android 13+ on-device SpeechRecognizer with EXTRA_AUDIO_SOURCE pipe, or
 * 2) Configured AI Speech/Audio API (Gemini multimodal audio or OpenAI Whisper) if API key is provided.
 * Never emits fake "Audio Segment X" placeholder labels.
 */
object AudioSrtExtractor {

    private const val TARGET_SAMPLE_RATE = 16_000

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private data class DecodedAudio(
        val pcm16kMono: ShortArray,
        val waveformPeaks: List<Float>,
        val intervals: List<Pair<Long, Long>>
    )

    suspend fun extractAudioSrt(
        context: Context,
        uri: Uri,
        durationMs: Long,
        sourceLanguage: SourceLanguage,
        apiConfig: ApiConfig,
        onProgress: (Float, String) -> Unit
    ): AudioSrtResult {
        val decoded = withContext(Dispatchers.IO) {
            decodeAndSegmentAudio(context, uri, durationMs) { p ->
                onProgress(p * 0.4f, "Decoding local audio track...")
            }
        }

        if (decoded.isFailure) {
            return AudioSrtResult.Error(
                decoded.exceptionOrNull()?.message ?: "Could not decode audio track from video."
            )
        }

        val audio = decoded.getOrThrow()
        if (audio.intervals.isEmpty()) {
            return AudioSrtResult.Error(
                "No clear speech activity detected in this video's audio track."
            )
        }

        // Path 1: On-device SpeechRecognizer (Android 13+ API 33+ supports EXTRA_AUDIO_SOURCE streaming)
        var onDeviceErrorReason: String? = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        ) {
            val recognizedSegments = mutableListOf<SrtSegment>()
            var hitMissingModel = false

            for ((idx, interval) in audio.intervals.withIndex()) {
                val (startMs, endMs) = interval
                onProgress(
                    0.4f + ((idx.toFloat() / audio.intervals.size.toFloat()) * 0.55f),
                    "Recognizing speech on-device (${idx + 1}/${audio.intervals.size})..."
                )
                val chunkPcmBytes = slicePcm16LeBytes(audio.pcm16kMono, startMs, endMs)
                if (chunkPcmBytes.isEmpty()) continue

                when (val res = recognizeOnDeviceChunk(context, chunkPcmBytes, sourceLanguage.bcp47)) {
                    is ChunkRecognition.Text -> {
                        if (res.text.isNotBlank()) {
                            recognizedSegments.add(
                                SrtSegment(
                                    index = recognizedSegments.size + 1,
                                    startMs = startMs,
                                    endMs = endMs,
                                    originalText = res.text.trim()
                                )
                            )
                        }
                    }
                    is ChunkRecognition.ModelUnavailable -> {
                        hitMissingModel = true
                        onDeviceErrorReason = res.reason
                        break
                    }
                    is ChunkRecognition.NoMatch -> Unit
                }
            }

            if (!hitMissingModel && recognizedSegments.isNotEmpty()) {
                onProgress(1f, "Speech SRT ready")
                return AudioSrtResult.Success(
                    segments = recognizedSegments,
                    waveformPeaks = audio.waveformPeaks
                )
            }
            if (!hitMissingModel && recognizedSegments.isEmpty()) {
                onDeviceErrorReason =
                    "On-device speech recognizer could not transcribe any clear words for ${sourceLanguage.displayName}."
            }
        } else {
            onDeviceErrorReason = if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                "On-device audio-file SpeechRecognizer requires Android 13+ (this device is API ${Build.VERSION.SDK_INT})."
            } else {
                "On-device speech recognition pack for ${sourceLanguage.displayName} is not installed on this device."
            }
        }

        // Path 2: If user configured an AI API key (Gemini or OpenAI), transcribe the real speech WAV chunks
        if (apiConfig.geminiApiKey.isNotBlank() &&
            (apiConfig.translationProvider == TranslationProvider.GEMINI ||
                apiConfig.translationProvider == TranslationProvider.OPENAI)
        ) {
            val aiSegments = mutableListOf<SrtSegment>()
            for ((idx, interval) in audio.intervals.withIndex()) {
                val (startMs, endMs) = interval
                onProgress(
                    0.45f + ((idx.toFloat() / audio.intervals.size.toFloat()) * 0.50f),
                    "Transcribing audio segment ${idx + 1}/${audio.intervals.size} via ${apiConfig.translationProvider.displayName}..."
                )
                val chunkPcm = slicePcm16LeBytes(audio.pcm16kMono, startMs, endMs)
                if (chunkPcm.isEmpty()) continue
                val wavBytes = wrapPcmAs16kWav(chunkPcm)

                val transcriptResult = if (apiConfig.translationProvider == TranslationProvider.GEMINI) {
                    transcribeWavWithGemini(apiConfig, wavBytes, sourceLanguage)
                } else {
                    transcribeWavWithOpenAiWhisper(apiConfig, wavBytes, sourceLanguage)
                }

                if (transcriptResult.isFailure) {
                    return AudioSrtResult.Error(
                        transcriptResult.exceptionOrNull()?.message
                            ?: "AI audio transcription failed."
                    )
                }

                val text = transcriptResult.getOrNull().orEmpty().trim()
                if (text.isNotBlank()) {
                    aiSegments.add(
                        SrtSegment(
                            index = aiSegments.size + 1,
                            startMs = startMs,
                            endMs = endMs,
                            originalText = text
                        )
                    )
                }
                if (idx < audio.intervals.lastIndex) {
                    delay(apiConfig.translationDelayMs.coerceAtLeast(400L))
                }
            }

            if (aiSegments.isNotEmpty()) {
                onProgress(1f, "Audio transcription complete")
                return AudioSrtResult.Success(
                    segments = aiSegments,
                    waveformPeaks = audio.waveformPeaks
                )
            }
        }

        // Path 3: Clear error/warning when speech model is missing instead of generating fake "Audio Segment X"
        return AudioSrtResult.MissingSpeechModel(
            buildString {
                append(onDeviceErrorReason ?: "Missing on-device speech recognition model.")
                append("\n\n")
                append("To avoid generating fake 'Audio 1, Audio 2...' placeholders, MatchaCut blocked empty segments. ")
                append("You can:\n")
                append("• Download the offline speech pack for ${sourceLanguage.displayName} in Android Settings → Voice typing,\n")
                append("• Enter a Gemini or OpenAI API key in Settings to transcribe audio accurately, or\n")
                append("• Use Step 2A (Image OCR) if subtitles are visible on screen.")
            }
        )
    }

    private sealed interface ChunkRecognition {
        data class Text(val text: String) : ChunkRecognition
        data class ModelUnavailable(val reason: String) : ChunkRecognition
        data object NoMatch : ChunkRecognition
    }

    private suspend fun recognizeOnDeviceChunk(
        context: Context,
        pcmBytes: ByteArray,
        bcp47Language: String
    ): ChunkRecognition = withContext(Dispatchers.Main) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return@withContext ChunkRecognition.ModelUnavailable("Requires Android 13+")
        }

        val pipe = ParcelFileDescriptor.createPipe()
        val readFd = pipe[0]
        val writeFd = pipe[1]

        val recognizer = runCatching {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        }.getOrElse {
            runCatching { readFd.close() }
            runCatching { writeFd.close() }
            return@withContext ChunkRecognition.ModelUnavailable(
                "On-device SpeechRecognizer service is not installed on this device."
            )
        }

        val writerJob = kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                ParcelFileDescriptor.AutoCloseOutputStream(writeFd).use { out ->
                    var offset = 0
                    val frameSize = 1024
                    while (offset < pcmBytes.size) {
                        val len = minOf(frameSize, pcmBytes.size - offset)
                        out.write(pcmBytes, offset, len)
                        out.flush()
                        offset += len
                        delay(20L)
                    }
                }
            }
        }

        val outcome = withTimeoutOrNull(12_000L) {
            suspendCancellableCoroutine<ChunkRecognition> { cont ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val best = matches?.firstOrNull().orEmpty().trim()
                        if (cont.isActive) {
                            cont.resume(
                                if (best.isNotEmpty()) ChunkRecognition.Text(best)
                                else ChunkRecognition.NoMatch
                            )
                        }
                    }

                    override fun onError(error: Int) {
                        val result = when (error) {
                            SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
                            SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE,
                            14 /* ERROR_CANNOT_CHECK_SUPPORT */,
                            15 /* ERROR_CANNOT_LISTEN_TO_DOWNLOAD_EVENTS */ ->
                                ChunkRecognition.ModelUnavailable(
                                    "Offline speech recognition model for $bcp47Language is missing or unsupported on this device (error $error)."
                                )
                            SpeechRecognizer.ERROR_NO_MATCH,
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> ChunkRecognition.NoMatch
                            else -> ChunkRecognition.ModelUnavailable(
                                "On-device speech recognizer failed (code $error)."
                            )
                        }
                        if (cont.isActive) cont.resume(result)
                    }
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, bcp47Language)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                    putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, readFd)
                    putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                    putExtra(
                        RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                    putExtra(
                        RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE,
                        TARGET_SAMPLE_RATE
                    )
                }
                recognizer.startListening(intent)
            }
        } ?: ChunkRecognition.NoMatch

        writerJob.cancel()
        runCatching { recognizer.destroy() }
        runCatching { readFd.close() }
        outcome
    }

    private fun transcribeWavWithGemini(
        apiConfig: ApiConfig,
        wavBytes: ByteArray,
        sourceLanguage: SourceLanguage
    ): Result<String> {
        val baseUrl = apiConfig.translationEndpointUrl.trim()
            .ifBlank { TranslationProvider.GEMINI.defaultEndpoint }
            .trimEnd('/')
        val model = apiConfig.geminiModel.trim().ifBlank { TranslationProvider.GEMINI.defaultModel }
        val url = "$baseUrl/models/$model:generateContent?key=${apiConfig.geminiApiKey.trim()}"
        val b64 = Base64.encodeToString(wavBytes, Base64.NO_WRAP)

        val prompt = "Transcribe the exact spoken words in this audio clip (${sourceLanguage.displayName}). Return ONLY the transcribed text with punctuation, no timestamps, no explanations. If no speech is audible, return empty."

        val bodyJson = JSONObject().apply {
            put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inlineData",
                                    JSONObject()
                                        .put("mimeType", "audio/wav")
                                        .put("data", b64)
                                )
                            )
                    )
                )
            )
            put("generationConfig", JSONObject().put("temperature", 0.1))
        }

        return runCatching {
            val req = Request.Builder()
                .url(url)
                .post(bodyJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException(
                        com.example.network.GeminiTranslator.formatApiErrorMessage(
                            resp.code,
                            raw,
                            "Gemini Audio"
                        )
                    )
                }
                val root = JSONObject(raw)
                root.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    .orEmpty()
                    .trim()
            }
        }
    }

    private fun transcribeWavWithOpenAiWhisper(
        apiConfig: ApiConfig,
        wavBytes: ByteArray,
        sourceLanguage: SourceLanguage
    ): Result<String> {
        val whisperUrl = "https://api.openai.com/v1/audio/transcriptions"
        return runCatching {
            val multipart = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("model", "whisper-1")
                .addFormDataPart("language", sourceLanguage.code)
                .addFormDataPart(
                    "file",
                    "speech.wav",
                    wavBytes.toRequestBody("audio/wav".toMediaType())
                )
                .build()
            val req = Request.Builder()
                .url(whisperUrl)
                .header("Authorization", "Bearer ${apiConfig.geminiApiKey.trim()}")
                .post(multipart)
                .build()
            httpClient.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw IllegalStateException(
                        com.example.network.GeminiTranslator.formatApiErrorMessage(
                            resp.code,
                            raw,
                            "OpenAI Whisper"
                        )
                    )
                }
                JSONObject(raw).optString("text").trim()
            }
        }
    }

    private fun decodeAndSegmentAudio(
        context: Context,
        uri: Uri,
        durationMs: Long,
        onProgress: (Float) -> Unit
    ): Result<DecodedAudio> {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }

            if (audioTrackIndex < 0 || audioFormat == null) {
                return Result.failure(IllegalStateException("Video has no audio track for Audio-to-SRT."))
            }

            extractor.selectTrack(audioTrackIndex)
            val mime = audioFormat.getString(MediaFormat.KEY_MIME)!!
            var srcSampleRate = audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE).coerceAtLeast(8000)
            var srcChannels = audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)

            codec = MediaCodec.createDecoderByType(mime).apply {
                configure(audioFormat, null, null, 0)
                start()
            }

            val pcmRawOut = ByteArrayOutputStream()
            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val timeoutUs = 10_000L
            val safeDurationUs = (durationMs.coerceAtLeast(1000L)) * 1000L

            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(timeoutUs)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)!!
                        val sampleSize = extractor.readSampleData(inBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val pts = extractor.sampleTime
                            codec.queueInputBuffer(inIdx, 0, sampleSize, pts, 0)
                            onProgress((pts.toFloat() / safeDurationUs.toFloat()).coerceIn(0f, 0.9f))
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFmt = codec.outputFormat
                    if (newFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        srcSampleRate = newFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        srcChannels = newFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && bufferInfo.size > 0) {
                        val chunk = ByteArray(bufferInfo.size)
                        outBuf.position(bufferInfo.offset)
                        outBuf.get(chunk)
                        pcmRawOut.write(chunk)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                }
            }

            val rawBytes = pcmRawOut.toByteArray()
            val shortCount = rawBytes.size / 2
            if (shortCount == 0) {
                return Result.failure(IllegalStateException("Decoded audio stream is empty."))
            }

            val rawShorts = ShortArray(shortCount)
            ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(rawShorts)

            // Downmix to mono
            val monoCount = shortCount / srcChannels.coerceAtLeast(1)
            val mono = ShortArray(monoCount) { i ->
                var sum = 0
                for (c in 0 until srcChannels) {
                    sum += rawShorts[i * srcChannels + c].toInt()
                }
                (sum / srcChannels.coerceAtLeast(1)).toShort()
            }

            // Resample to 16kHz mono
            val pcm16k = if (srcSampleRate == TARGET_SAMPLE_RATE || mono.isEmpty()) {
                mono
            } else {
                val outLen = ((mono.size.toLong() * TARGET_SAMPLE_RATE) / srcSampleRate.coerceAtLeast(8000))
                    .toInt()
                    .coerceAtLeast(1)
                ShortArray(outLen) { i ->
                    val srcPos = (i.toDouble() * srcSampleRate) / TARGET_SAMPLE_RATE
                    val idx0 = srcPos.toInt().coerceIn(0, mono.lastIndex)
                    val idx1 = (idx0 + 1).coerceIn(0, mono.lastIndex)
                    val frac = srcPos - idx0
                    ((mono[idx0] * (1.0 - frac)) + (mono[idx1] * frac)).toInt().toShort()
                }
            }

            // Compute 100ms RMS windows
            val windowMs = 100L
            val samplesPerWindow = ((TARGET_SAMPLE_RATE * windowMs) / 1000L).toInt()
            val windowRmsList = mutableListOf<Float>()
            var idx = 0
            while (idx < pcm16k.size) {
                val end = minOf(idx + samplesPerWindow, pcm16k.size)
                var sumSq = 0.0
                for (k in idx until end) {
                    val v = pcm16k[k].toDouble() / 32768.0
                    sumSq += v * v
                }
                windowRmsList.add(sqrt(sumSq / (end - idx).coerceAtLeast(1)).toFloat())
                idx = end
            }

            val maxPeak = windowRmsList.maxOrNull()?.coerceAtLeast(0.01f) ?: 0.01f
            val normalizedWindows = windowRmsList.map { (it / maxPeak).coerceIn(0f, 1f) }
            val waveformPeaks = downsampleWaveform(normalizedWindows, 72)
            val intervals = buildSpeechIntervals(normalizedWindows, windowMs, durationMs)
            onProgress(1f)

            return Result.success(
                DecodedAudio(
                    pcm16kMono = pcm16k,
                    waveformPeaks = waveformPeaks,
                    intervals = intervals
                )
            )
        } catch (t: Throwable) {
            return Result.failure(t)
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun buildSpeechIntervals(
        normalizedWindows: List<Float>,
        windowMs: Long,
        totalDurationMs: Long
    ): List<Pair<Long, Long>> {
        if (normalizedWindows.isEmpty()) return emptyList()
        val sorted = normalizedWindows.sorted()
        val noiseFloor = sorted[(sorted.size * 0.25).toInt().coerceIn(0, sorted.lastIndex)]
        val threshold = (noiseFloor + 0.12f).coerceIn(0.10f, 0.35f)

        val rawIntervals = mutableListOf<Pair<Long, Long>>()
        var activeStart: Long? = null
        var silentWindows = 0

        normalizedWindows.forEachIndexed { idx, energy ->
            val timeMs = idx * windowMs
            if (energy >= threshold) {
                if (activeStart == null) activeStart = timeMs
                silentWindows = 0
            } else if (activeStart != null) {
                silentWindows++
                if (silentWindows >= 4) {
                    val endMs = (timeMs - (silentWindows - 1) * windowMs).coerceAtLeast(activeStart!! + 450L)
                    rawIntervals.add(activeStart!! to endMs.coerceAtMost(totalDurationMs))
                    activeStart = null
                    silentWindows = 0
                }
            }
        }
        if (activeStart != null) {
            val endMs = (normalizedWindows.size * windowMs).coerceAtMost(totalDurationMs)
            rawIntervals.add(activeStart!! to endMs.coerceAtLeast(activeStart!! + 450L).coerceAtMost(totalDurationMs))
        }

        val refined = mutableListOf<Pair<Long, Long>>()
        for ((s, e) in rawIntervals) {
            if (e - s < 350L) continue
            var cursor = s
            while (e - cursor > 5500L) {
                refined.add(cursor to (cursor + 5000L))
                cursor += 5000L
            }
            if (e - cursor >= 350L) {
                refined.add(cursor to e)
            }
        }
        return refined
    }

    private fun slicePcm16LeBytes(pcm16k: ShortArray, startMs: Long, endMs: Long): ByteArray {
        if (pcm16k.isEmpty()) return ByteArray(0)
        val startIdx = ((startMs * TARGET_SAMPLE_RATE) / 1000L).toInt().coerceIn(0, pcm16k.size)
        val endIdx = ((endMs * TARGET_SAMPLE_RATE) / 1000L).toInt().coerceIn(startIdx, pcm16k.size)
        val count = endIdx - startIdx
        if (count <= 0) return ByteArray(0)
        val out = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in startIdx until endIdx) {
            out.putShort(pcm16k[i])
        }
        return out.array()
    }

    private fun wrapPcmAs16kWav(pcmBytes: ByteArray): ByteArray {
        val out = ByteBuffer.allocate(44 + pcmBytes.size).order(ByteOrder.LITTLE_ENDIAN)
        out.put("RIFF".toByteArray())
        out.putInt(36 + pcmBytes.size)
        out.put("WAVE".toByteArray())
        out.put("fmt ".toByteArray())
        out.putInt(16)
        out.putShort(1)
        out.putShort(1)
        out.putInt(TARGET_SAMPLE_RATE)
        out.putInt(TARGET_SAMPLE_RATE * 2)
        out.putShort(2)
        out.putShort(16)
        out.put("data".toByteArray())
        out.putInt(pcmBytes.size)
        out.put(pcmBytes)
        return out.array()
    }

    private fun downsampleWaveform(source: List<Float>, targetCount: Int): List<Float> {
        if (source.isEmpty()) return emptyList()
        if (source.size <= targetCount) return source
        val step = source.size.toFloat() / targetCount
        return List(targetCount) { i ->
            val start = (i * step).toInt().coerceIn(0, source.lastIndex)
            val end = ((i + 1) * step).toInt().coerceIn(start + 1, source.size)
            var peak = 0f
            for (k in start until end) {
                if (source[k] > peak) peak = source[k]
            }
            peak
        }
    }
}
