package com.example

import com.example.model.ApiConfig
import com.example.model.AppLanguage
import com.example.model.SrtSegment
import com.example.model.TtsEngineMode
import com.example.model.WorkflowStep
import com.example.network.GeminiTranslator
import com.example.network.VoiceCatalog
import com.example.util.SanitationResult
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.example.util.stringsForLanguage
import com.example.viewmodel.EditorUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkflowAndSanitizerTest {

    @Test
    fun voiceCatalogContainsNgocHuyenNamMinhHoaiTayAndMoreThan10Voices() {
        val names = VoiceCatalog.voices.map { it.name }
        assertTrue("Expected > 10 voices, got ${names.size}", names.size > 10)
        assertTrue("Expected Ngọc Huyền in voice list", names.contains("Ngọc Huyền"))
        assertTrue("Expected Nam Minh in voice list", names.contains("Nam Minh"))
        assertTrue("Expected Hoài Tây in voice list", names.contains("Hoài Tây"))
        assertTrue("Expected Adam in voice list", names.contains("Adam"))
        assertEquals(names.size, names.distinct().size)
    }

    @Test
    fun defaultConfigUsesVietnameseUiAndFreeBuiltinTts() {
        val state = EditorUiState()
        assertEquals(AppLanguage.VIETNAMESE, state.appLanguage)
        assertEquals(TtsEngineMode.FREE_BUILTIN_TTS, ApiConfig().ttsEngineMode)
        assertEquals("Nhập Video", stringsForLanguage(AppLanguage.VIETNAMESE).importVideo)
        assertEquals("Import Video", stringsForLanguage(AppLanguage.ENGLISH).importVideo)
    }

    @Test
    fun quotaAndTokenExhaustionErrorsAreDetectedExplicitly() {
        assertTrue(GeminiTranslator.isQuotaOrRateLimit(429, """{"error":{"status":"RESOURCE_EXHAUSTED"}}"""))
        assertTrue(GeminiTranslator.isQuotaOrRateLimit(402, """{"error":{"message":"Insufficient balance"}}"""))
        val msg = GeminiTranslator.formatApiErrorMessage(429, """{"error":{"message":"Quota exceeded"}}""", "OpenAI")
        assertTrue(msg.contains("Hết token") || msg.contains("429"))
    }

    @Test
    fun srtParsingPreservesOriginalTimestampsAndIndices() {
        val originals = listOf(
            SrtSegment(index = 1, startMs = 1000L, endMs = 3250L, originalText = "你好世界"),
            SrtSegment(index = 2, startMs = 4000L, endMs = 6500L, originalText = "欢迎来到这里")
        )
        val aiRaw = """
            ```srt
            1
            00:00:99,999 --> 00:01:99,999
            Xin chào thế giới

            2
            00:00:04,000 --> 00:00:06,500
            Chào mừng đến đây
            ```
        """.trimIndent()

        val translated = SrtUtils.parseTranslatedSrtPreservingTiming(aiRaw, originals)
        assertEquals(2, translated.size)
        assertEquals(1000L, translated[0].startMs)
        assertEquals(3250L, translated[0].endMs)
        assertEquals("Xin chào thế giới", translated[0].translatedText)
        assertEquals(4000L, translated[1].startMs)
        assertEquals(6500L, translated[1].endMs)
        assertEquals("Chào mừng đến đây", translated[1].translatedText)
    }

    @Test
    fun textSanitizerStripsChineseCharactersAndBlocksSourceOnlyText() {
        assertTrue(TextSanitizer.containsChineseCharacters("你好世界"))
        assertFalse(TextSanitizer.containsChineseCharacters("Xin chào thế giới"))

        val cleaned = TextSanitizer.sanitizeForVoiceover("Xin chào 你好 bạn")
        assertFalse(TextSanitizer.containsChineseCharacters(cleaned))
        assertEquals("Xin chào bạn", cleaned)

        val blocked = TextSanitizer.validateSanitizedVoiceoverScript(
            listOf(SrtSegment(1, 0L, 1000L, "你好", translatedText = "你好"))
        )
        assertTrue(blocked is SanitationResult.Blocked)
    }

    @Test
    fun voiceoverRemainsStrictlyLockedUntilTranslationCompletes() {
        val segExtracted = listOf(SrtSegment(1, 0L, 1500L, "你好", translatedText = ""))
        val step2State = EditorUiState(
            workflowStep = WorkflowStep.SUBTITLES_EXTRACTED,
            segments = segExtracted
        )
        assertFalse(step2State.isVoiceoverUnlocked)

        val segTranslated = listOf(SrtSegment(1, 0L, 1500L, "你好", translatedText = "Xin chào"))
        val step3State = EditorUiState(
            workflowStep = WorkflowStep.TRANSLATED,
            segments = segTranslated
        )
        assertTrue(step3State.isVoiceoverUnlocked)
    }
}
