package com.example.network

import com.example.model.SrtSegment
import com.example.model.TargetLanguage
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed interface TranslationResult {
    data class Success(val translatedSegments: List<SrtSegment>) : TranslationResult
    data class Error(val message: String) : TranslationResult
}

object GeminiTranslator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun translateSrt(
        apiKey: String,
        model: String,
        segments: List<SrtSegment>,
        targetLanguage: TargetLanguage
    ): TranslationResult = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isEmpty()) {
            return@withContext TranslationResult.Error(
                "Gemini API Key is required. Open API Settings to enter your key."
            )
        }
        if (segments.isEmpty()) {
            return@withContext TranslationResult.Error("No subtitle segments to translate.")
        }

        val inputSrt = SrtUtils.toSrtString(segments, useTranslated = false)
        val systemInstruction = """
            You are an expert audiovisual subtitle translator.
            Translate the following SRT subtitle file into ${targetLanguage.displayName}.
            STRICT RULES:
            1. Preserve every subtitle index number and every timestamp line (HH:MM:SS,mmm --> HH:MM:SS,mmm) EXACTLY as given.
            2. Do NOT merge, split, add, or drop any subtitle block.
            3. Output ONLY valid SRT format. No markdown code fences, no explanations, no intro/outro text.
            4. Translate 100% of the dialogue naturally and concisely for spoken voiceover in ${targetLanguage.displayName}. Leave ZERO Chinese characters or untranslated source words in the output.
        """.trimIndent()

        val requestJson = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemInstruction))
                )
            )
            put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", inputSrt))
                        )
                )
            )
            put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.2)
            )
        }

        val safeModel = model.trim().ifBlank { "gemini-2.5-flash" }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent?key=$trimmedKey"

        try {
            val body = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val apiError = runCatching {
                        JSONObject(rawBody).optJSONObject("error")?.optString("message")
                    }.getOrNull()
                    return@withContext TranslationResult.Error(
                        apiError?.takeIf { it.isNotBlank() }
                            ?: "Gemini API error (${response.code}): Check your API key and model name."
                    )
                }

                val root = JSONObject(rawBody)
                val candidates = root.optJSONArray("candidates")
                val text = candidates
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    .orEmpty()

                if (text.isBlank()) {
                    return@withContext TranslationResult.Error("Gemini returned an empty translation response.")
                }

                val parsed = SrtUtils.parseTranslatedSrtPreservingTiming(text, segments)
                val emptyCount = parsed.count { it.translatedText.isBlank() }
                if (emptyCount == parsed.size) {
                    return@withContext TranslationResult.Error(
                        "Could not parse valid translated SRT blocks from Gemini response."
                    )
                }

                // Ensure any stray untranslated Chinese characters are cleaned or flagged
                val cleaned = parsed.map { seg ->
                    val stripped = TextSanitizer.sanitizeForVoiceover(seg.translatedText)
                    seg.copy(translatedText = stripped.ifBlank { seg.translatedText.trim() })
                }

                val leftoverChinese = cleaned.any { TextSanitizer.containsChineseCharacters(it.translatedText) }
                if (leftoverChinese) {
                    return@withContext TranslationResult.Error(
                        "Gemini output still contained source Chinese characters. Please retry translation."
                    )
                }

                TranslationResult.Success(cleaned)
            }
        } catch (t: Throwable) {
            TranslationResult.Error("Network error calling Gemini API: ${t.message ?: "Unknown error"}")
        }
    }
}
