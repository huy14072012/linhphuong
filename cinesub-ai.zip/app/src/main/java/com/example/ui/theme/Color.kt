package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Matcha Green & Peach Pink Editorial Studio Palette
val MatchaLightBg = Color(0xFFEDF4EA)
val MatchaSurface = Color(0xFFF7FBF5)
val MatchaSurfaceContainer = Color(0xFFE1ECDC)
val MatchaSurfaceHigh = Color(0xFFD3E2CC)

val MatchaGreenDark = Color(0xFF4F7A4A)
val MatchaGreenDeep = Color(0xFF2B4828)
val MatchaOnDark = Color(0xFFF5FAF3)
val MatchaMutedText = Color(0xFF4F624C)
val MatchaOutline = Color(0xFFB5C7B0)

val PeachPink = Color(0xFFF4978E)
val PeachPinkPressed = Color(0xFFE57B71)
val PeachPinkSoft = Color(0xFFFDE8E5)
val PeachPinkDeep = Color(0xFF7D2E27)

val StudioPreviewBg = Color(0xFF162015)
val StudioBezel = Color(0xFF243322)
val TimelineBg = Color(0xFF202D1E)
val TimelineRuler = Color(0xFF344731)

val StatusSuccess = Color(0xFF2E7D32)
val StatusWarning = Color(0xFFD97706)
val StatusError = Color(0xFFBA1A1A)
