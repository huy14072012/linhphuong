package com.example.ui.components

import androidx.annotation.OptIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.R
import com.example.model.NormalizedRect
import com.example.model.SourceLanguage
import com.example.model.SrtSegment
import com.example.model.VideoMetadata
import com.example.model.WorkflowStep
import com.example.ui.theme.MatchaGreenDark
import com.example.ui.theme.MatchaGreenDeep
import com.example.ui.theme.MatchaLightBg
import com.example.ui.theme.MatchaOnDark
import com.example.ui.theme.MatchaSurfaceContainer
import com.example.ui.theme.PeachPink
import com.example.ui.theme.PeachPinkSoft
import com.example.ui.theme.StudioPreviewBg
import com.example.util.SrtUtils
import kotlin.math.hypot

@Composable
fun StudioTopBar(
    workflowStep: WorkflowStep,
    videoMetadata: VideoMetadata?,
    onOpenSettings: () -> Unit,
    onExportClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MatchaGreenDark,
        contentColor = MatchaOnDark,
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(PeachPink),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.MovieCreation,
                        contentDescription = null,
                        tint = MatchaGreenDeep,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleMedium,
                            color = MatchaOnDark,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MatchaGreenDeep.copy(alpha = 0.65f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Step ${workflowStep.stepNumber}/5 · ${workflowStep.shortLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = PeachPinkSoft,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (videoMetadata != null) {
                        Text(
                            text = "${SrtUtils.formatCompactTime(videoMetadata.durationMs)} · ${videoMetadata.resolutionLabel} · ${videoMetadata.fpsLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MatchaLightBg.copy(alpha = 0.85f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Text(
                            text = stringResource(R.string.studio_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaLightBg.copy(alpha = 0.8f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = stringResource(R.string.action_api_settings),
                        tint = MatchaOnDark
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Button(
                    onClick = onExportClick,
                    enabled = videoMetadata != null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PeachPink,
                        contentColor = MatchaGreenDeep,
                        disabledContainerColor = MatchaGreenDeep.copy(alpha = 0.4f),
                        disabledContentColor = MatchaOnDark.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("export_mp4_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.FileUpload,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stringResource(R.string.action_export_video),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun VideoPreviewStage(
    exoPlayer: ExoPlayer,
    videoMetadata: VideoMetadata?,
    isPlaying: Boolean,
    playbackPositionMs: Long,
    cropBox: NormalizedRect,
    showOcrBox: Boolean,
    sourceLanguage: SourceLanguage,
    activeSubtitle: SrtSegment?,
    hasVoiceover: Boolean,
    previewWithVoiceover: Boolean,
    onImportClick: () -> Unit,
    onPlayPauseClick: () -> Unit,
    onCropBoxChange: (NormalizedRect) -> Unit,
    onToggleOcrBox: () -> Unit,
    onToggleVoiceoverPreview: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .aspectRatio(16f / 10f)
                .clip(RoundedCornerShape(18.dp))
                .background(StudioPreviewBg)
                .border(1.5.dp, MatchaGreenDark.copy(alpha = 0.5f), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (videoMetadata == null) {
                EmptyVideoImportStage(onImportClick = onImportClick)
            } else {
                AndroidView(
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        }
                    },
                    update = { view ->
                        if (view.player !== exoPlayer) {
                            view.player = exoPlayer
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                if (showOcrBox) {
                    OcrBoundingBoxOverlay(
                        cropBox = cropBox,
                        sourceLanguage = sourceLanguage,
                        onCropBoxChange = onCropBoxChange,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Live subtitle preview pill
                if (activeSubtitle != null && activeSubtitle.displayText.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xCC162015))
                            .border(1.dp, PeachPink.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = activeSubtitle.displayText,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Compact playback & preview control bar
        Surface(
            color = MatchaSurfaceContainer,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onPlayPauseClick,
                        enabled = videoMetadata != null,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = if (videoMetadata != null) MatchaGreenDeep else MatchaGreenDeep.copy(alpha = 0.35f)
                        )
                    }

                    Text(
                        text = if (videoMetadata != null) {
                            "${SrtUtils.formatCompactTime(playbackPositionMs)} / ${SrtUtils.formatCompactTime(videoMetadata.durationMs)}"
                        } else {
                            "00:00.0 / 00:00.0"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MatchaGreenDeep,
                        fontSize = 12.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (hasVoiceover) {
                        Surface(
                            color = if (previewWithVoiceover) PeachPink else MatchaLightBg,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(onClick = onToggleVoiceoverPreview)
                                .testTag("toggle_voiceover_preview")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (previewWithVoiceover) Icons.Filled.RecordVoiceOver else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Toggle preview audio",
                                    tint = MatchaGreenDeep,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (previewWithVoiceover) "VO Audio" else "Orig Audio",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MatchaGreenDeep
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Surface(
                        color = if (showOcrBox && videoMetadata != null) PeachPinkSoft else MatchaLightBg,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(enabled = videoMetadata != null, onClick = onToggleOcrBox)
                            .testTag("toggle_ocr_box_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CropFree,
                                contentDescription = "Toggle OCR Bounding Box",
                                tint = MatchaGreenDeep,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (showOcrBox) "Box On" else "Box Off",
                                style = MaterialTheme.typography.labelMedium,
                                color = MatchaGreenDeep
                            )
                        }
                    }

                    if (videoMetadata != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = onImportClick,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("replace_video_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.VideoFile,
                                contentDescription = stringResource(R.string.action_replace_video),
                                tint = MatchaGreenDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyVideoImportStage(onImportClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(MatchaGreenDark.copy(alpha = 0.35f))
                .border(1.5.dp, PeachPink, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.VideoFile,
                contentDescription = null,
                tint = PeachPink,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = stringResource(R.string.empty_player_title),
            style = MaterialTheme.typography.titleMedium,
            color = MatchaLightBg,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.empty_player_subtitle),
            style = MaterialTheme.typography.bodySmall,
            color = MatchaLightBg.copy(alpha = 0.72f),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(14.dp))
        Button(
            onClick = onImportClick,
            colors = ButtonDefaults.buttonColors(
                containerColor = PeachPink,
                contentColor = MatchaGreenDeep
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("import_video_button")
        ) {
            Icon(
                imageVector = Icons.Filled.VideoFile,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.action_import_video),
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

private enum class DragHandleMode {
    NONE,
    MOVE,
    TOP_LEFT,
    TOP_RIGHT,
    BOTTOM_LEFT,
    BOTTOM_RIGHT
}

@Composable
fun OcrBoundingBoxOverlay(
    cropBox: NormalizedRect,
    sourceLanguage: SourceLanguage,
    onCropBoxChange: (NormalizedRect) -> Unit,
    modifier: Modifier = Modifier
) {
    val latestBox by rememberUpdatedState(cropBox)
    val latestOnChange by rememberUpdatedState(onCropBoxChange)
    var dragMode by remember { mutableStateOf(DragHandleMode.NONE) }
    val touchThresholdPx = with(LocalDensity.current) { 28.dp.toPx() }

    BoxWithConstraints(modifier = modifier) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val b = latestBox
                            val l = b.left * widthPx
                            val t = b.top * heightPx
                            val r = b.right * widthPx
                            val bt = b.bottom * heightPx
                            dragMode = when {
                                hypot(offset.x - l, offset.y - t) <= touchThresholdPx -> DragHandleMode.TOP_LEFT
                                hypot(offset.x - r, offset.y - t) <= touchThresholdPx -> DragHandleMode.TOP_RIGHT
                                hypot(offset.x - l, offset.y - bt) <= touchThresholdPx -> DragHandleMode.BOTTOM_LEFT
                                hypot(offset.x - r, offset.y - bt) <= touchThresholdPx -> DragHandleMode.BOTTOM_RIGHT
                                offset.x in (l - 12f)..(r + 12f) && offset.y in (t - 12f)..(bt + 12f) -> DragHandleMode.MOVE
                                else -> DragHandleMode.NONE
                            }
                        },
                        onDragEnd = { dragMode = DragHandleMode.NONE },
                        onDragCancel = { dragMode = DragHandleMode.NONE },
                        onDrag = { change, dragAmount ->
                            if (dragMode == DragHandleMode.NONE) return@detectDragGestures
                            change.consume()
                            val dx = dragAmount.x / widthPx
                            val dy = dragAmount.y / heightPx
                            val b = latestBox
                            val updated = when (dragMode) {
                                DragHandleMode.MOVE -> {
                                    val w = b.width
                                    val h = b.height
                                    val newL = (b.left + dx).coerceIn(0f, 1f - w)
                                    val newT = (b.top + dy).coerceIn(0f, 1f - h)
                                    NormalizedRect(newL, newT, newL + w, newT + h)
                                }
                                DragHandleMode.TOP_LEFT -> NormalizedRect(
                                    left = (b.left + dx).coerceIn(0f, b.right - 0.12f),
                                    top = (b.top + dy).coerceIn(0f, b.bottom - 0.08f),
                                    right = b.right,
                                    bottom = b.bottom
                                )
                                DragHandleMode.TOP_RIGHT -> NormalizedRect(
                                    left = b.left,
                                    top = (b.top + dy).coerceIn(0f, b.bottom - 0.08f),
                                    right = (b.right + dx).coerceIn(b.left + 0.12f, 1f),
                                    bottom = b.bottom
                                )
                                DragHandleMode.BOTTOM_LEFT -> NormalizedRect(
                                    left = (b.left + dx).coerceIn(0f, b.right - 0.12f),
                                    top = b.top,
                                    right = b.right,
                                    bottom = (b.bottom + dy).coerceIn(b.top + 0.08f, 1f)
                                )
                                DragHandleMode.BOTTOM_RIGHT -> NormalizedRect(
                                    left = b.left,
                                    top = b.top,
                                    right = (b.right + dx).coerceIn(b.left + 0.12f, 1f),
                                    bottom = (b.bottom + dy).coerceIn(b.top + 0.08f, 1f)
                                )
                                DragHandleMode.NONE -> b
                            }
                            latestOnChange(updated.clamped())
                        }
                    )
                }
        ) {
            val l = cropBox.left * size.width
            val t = cropBox.top * size.height
            val r = cropBox.right * size.width
            val b = cropBox.bottom * size.height

            // Dim outside OCR selection
            drawRect(color = Color.Black.copy(alpha = 0.42f))
            drawRect(
                color = Color.Transparent,
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                blendMode = BlendMode.Clear
            )

            // Peach pink bounding box frame
            drawRect(
                color = PeachPink,
                topLeft = Offset(l, t),
                size = Size(r - l, b - t),
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Corner resize handles
            val handleRadius = 7.dp.toPx()
            listOf(
                Offset(l, t),
                Offset(r, t),
                Offset(l, b),
                Offset(r, b)
            ).forEach { corner ->
                drawCircle(
                    color = PeachPink,
                    radius = handleRadius,
                    center = corner
                )
                drawCircle(
                    color = MatchaGreenDeep,
                    radius = handleRadius * 0.45f,
                    center = corner
                )
            }
        }

        // Tag showing OCR target area & configured language
        val topOffsetDp = with(LocalDensity.current) {
            (cropBox.top * heightPx).toDp().coerceAtLeast(4.dp)
        }
        val leftOffsetDp = with(LocalDensity.current) {
            (cropBox.left * widthPx).toDp().coerceAtLeast(4.dp)
        }
        Surface(
            color = PeachPink,
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.padding(start = leftOffsetDp, top = (topOffsetDp - 20.dp).coerceAtLeast(4.dp))
        ) {
            Text(
                text = "OCR Box · ${sourceLanguage.displayName}",
                style = MaterialTheme.typography.labelSmall,
                color = MatchaGreenDeep,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
