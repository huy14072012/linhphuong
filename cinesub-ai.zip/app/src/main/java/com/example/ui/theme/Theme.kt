package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val MatchaCutColorScheme = lightColorScheme(
    primary = PeachPink,
    onPrimary = MatchaGreenDeep,
    primaryContainer = PeachPinkSoft,
    onPrimaryContainer = PeachPinkDeep,
    secondary = MatchaGreenDark,
    onSecondary = MatchaOnDark,
    secondaryContainer = MatchaSurfaceContainer,
    onSecondaryContainer = MatchaGreenDeep,
    tertiary = MatchaGreenDeep,
    onTertiary = Color.White,
    background = MatchaLightBg,
    onBackground = MatchaGreenDeep,
    surface = MatchaSurface,
    onSurface = MatchaGreenDeep,
    surfaceVariant = MatchaSurfaceContainer,
    onSurfaceVariant = MatchaMutedText,
    outline = MatchaOutline,
    error = StatusError,
    onError = Color.White
)

private val MatchaCutShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun MatchaCutTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MatchaCutColorScheme,
        typography = MatchaCutTypography,
        shapes = MatchaCutShapes,
        content = content
    )
}
