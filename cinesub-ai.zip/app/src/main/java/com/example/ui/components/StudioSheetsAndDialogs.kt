package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.model.ApiConfig
import com.example.model.ExportConfig
import com.example.model.ExportFps
import com.example.model.ExportResolution
import com.example.model.ExportState
import com.example.model.SrtSegment
import com.example.model.TargetLanguage
import com.example.model.TtsEngineMode
import com.example.model.TtsPayloadPreset
import com.example.network.VoiceCatalog
import com.example.ui.theme.MatchaGreenDark
import com.example.ui.theme.MatchaGreenDeep
import com.example.ui.theme.MatchaLightBg
import com.example.ui.theme.MatchaMutedText
import com.example.ui.theme.MatchaOnDark
import com.example.ui.theme.MatchaOutline
import com.example.ui.theme.MatchaSurface
import com.example.ui.theme.MatchaSurfaceContainer
import com.example.ui.theme.PeachPink
import com.example.ui.theme.PeachPinkDeep
import com.example.ui.theme.PeachPinkSoft
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.example.viewmodel.ValidationAlert

@Composable
fun ApiSettingsDialog(
    currentConfig: ApiConfig,
    onSave: (ApiConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var geminiKey by remember(currentConfig) { mutableStateOf(currentConfig.geminiApiKey) }
    var geminiModel by remember(currentConfig) { mutableStateOf(currentConfig.geminiModel) }
    var ttsUrl by remember(currentConfig) { mutableStateOf(currentConfig.ttsEndpointUrl) }
    var ttsKey by remember(currentConfig) { mutableStateOf(currentConfig.ttsApiKey) }
    var ttsPreset by remember(currentConfig) { mutableStateOf(currentConfig.ttsPayloadPreset) }
    var ttsMode by remember(currentConfig) { mutableStateOf(currentConfig.ttsEngineMode) }
    var showGeminiKey by remember { mutableStateOf(false) }
    var showTtsKey by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MatchaSurface,
        title = {
            Text(
                text = "Gemini & Voiceover API Settings",
                style = MaterialTheme.typography.titleMedium,
                color = MatchaGreenDeep
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 430.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Step 3 Translation (Gemini API)",
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )

                OutlinedTextField(
                    value = geminiKey,
                    onValueChange = { geminiKey = it },
                    label = { Text("Gemini API Key") },
                    placeholder = { Text("AIzaSy...") },
                    singleLine = true,
                    visualTransformation = if (showGeminiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                            Icon(
                                imageVector = if (showGeminiKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = "Toggle key visibility"
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_api_key_input")
                )

                OutlinedTextField(
                    value = geminiModel,
                    onValueChange = { geminiModel = it },
                    label = { Text("Gemini Model ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Step 4 Voiceover / TTS Endpoint",
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TtsEngineMode.entries.forEach { mode ->
                        FilterChip(
                            selected = ttsMode == mode,
                            onClick = { ttsMode = mode },
                            label = {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PeachPink,
                                selectedLabelColor = MatchaGreenDeep
                            )
                        )
                    }
                }

                if (ttsMode == TtsEngineMode.CONFIGURABLE_API) {
                    OutlinedTextField(
                        value = ttsUrl,
                        onValueChange = { ttsUrl = it },
                        label = { Text("TTS / Voiceover API Endpoint URL") },
                        placeholder = { Text("https://api.example.com/v1/audio/speech") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tts_endpoint_input")
                    )

                    OutlinedTextField(
                        value = ttsKey,
                        onValueChange = { ttsKey = it },
                        label = { Text("TTS API Key (Bearer / xi-api-key)") },
                        singleLine = true,
                        visualTransformation = if (showTtsKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showTtsKey = !showTtsKey }) {
                                Icon(
                                    imageVector = if (showTtsKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = "Toggle TTS key visibility"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Payload Format",
                        style = MaterialTheme.typography.labelMedium,
                        color = MatchaMutedText
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TtsPayloadPreset.entries.forEach { preset ->
                            FilterChip(
                                selected = ttsPreset == preset,
                                onClick = { ttsPreset = preset },
                                label = { Text(preset.label, style = MaterialTheme.typography.labelMedium) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MatchaGreenDark,
                                    selectedLabelColor = MatchaOnDark
                                )
                            )
                        }
                    }
                } else {
                    Surface(
                        color = MatchaSurfaceContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Uses Android's built-in on-device TextToSpeech engine to synthesize WAV audio for each translated SRT segment.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaGreenDeep,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        ApiConfig(
                            geminiApiKey = geminiKey,
                            geminiModel = geminiModel,
                            ttsEndpointUrl = ttsUrl,
                            ttsApiKey = ttsKey,
                            ttsPayloadPreset = ttsPreset,
                            ttsEngineMode = ttsMode
                        )
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PeachPink,
                    contentColor = MatchaGreenDeep
                ),
                modifier = Modifier.testTag("save_api_settings_button")
            ) {
                Text("Save Settings")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MatchaGreenDark)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SrtEditorSheet(
    segments: List<SrtSegment>,
    targetLanguage: TargetLanguage,
    onUpdateSegment: (Int, String, String) -> Unit,
    onExportSrtClick: () -> Unit,
    onTranslateClick: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MatchaLightBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SRT Subtitle Inspector",
                        style = MaterialTheme.typography.titleMedium,
                        color = MatchaGreenDeep
                    )
                    Text(
                        text = "${segments.size} segments · Target: ${targetLanguage.displayName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MatchaMutedText
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onExportSrtClick,
                        border = BorderStroke(1.dp, MatchaGreenDark),
                        modifier = Modifier.testTag("save_srt_file_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = null,
                            tint = MatchaGreenDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Save .SRT", color = MatchaGreenDark)
                    }

                    Button(
                        onClick = {
                            onDismiss()
                            onTranslateClick()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PeachPink,
                            contentColor = MatchaGreenDeep
                        ),
                        modifier = Modifier.testTag("sheet_translate_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Gemini")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(segments, key = { it.index }) { seg ->
                    Surface(
                        color = MatchaSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MatchaOutline.copy(alpha = 0.6f))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "#${seg.index} · ${SrtUtils.formatSrtTimestamp(seg.startMs)} --> ${SrtUtils.formatSrtTimestamp(seg.endMs)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MatchaGreenDark
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = seg.originalText,
                                onValueChange = { onUpdateSegment(seg.index, it, seg.translatedText) },
                                label = { Text("Source Text") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (seg.translatedText.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = seg.translatedText,
                                    onValueChange = { onUpdateSegment(seg.index, seg.originalText, it) },
                                    label = { Text("Translated (${targetLanguage.displayName})") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceoverSheet(
    segments: List<SrtSegment>,
    selectedVoiceId: String,
    targetLanguage: TargetLanguage,
    apiConfig: ApiConfig,
    onSelectVoice: (String) -> Unit,
    onGenerateVoiceover: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val sanitizedLines = remember(segments) {
        segments.map { TextSanitizer.sanitizeForVoiceover(it.translatedText) }.filter { it.isNotBlank() }
    }
    val chineseCharsRemaining = remember(sanitizedLines) {
        sanitizedLines.sumOf { TextSanitizer.countChineseCharacters(it) }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MatchaLightBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Step 4 · AI Voiceover Studio",
                        style = MaterialTheme.typography.titleMedium,
                        color = MatchaGreenDeep
                    )
                    Text(
                        text = "${VoiceCatalog.voices.size} distinct voices · ${apiConfig.ttsEngineMode.label}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MatchaMutedText
                    )
                }

                TextButton(onClick = {
                    onDismiss()
                    onOpenSettings()
                }) {
                    Text("TTS Endpoint", color = MatchaGreenDark)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Strict Language Sanitation Status Card
            Surface(
                color = if (chineseCharsRemaining == 0) MatchaSurfaceContainer else PeachPinkSoft,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (chineseCharsRemaining == 0) MatchaGreenDark else StatusError),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = if (chineseCharsRemaining == 0) StatusSuccess else StatusError,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Language Sanitation Verified: $chineseCharsRemaining Chinese chars",
                            style = MaterialTheme.typography.labelLarge,
                            color = MatchaGreenDeep
                        )
                        Text(
                            text = "Strictly sending ${sanitizedLines.size} translated ${targetLanguage.displayName} segments.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaMutedText
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 310.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(VoiceCatalog.voices, key = { it.id }) { voice ->
                    val isSelected = voice.id == selectedVoiceId
                    Surface(
                        color = if (isSelected) PeachPinkSoft else MatchaSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) PeachPink else MatchaOutline.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectVoice(voice.id) }
                            .testTag("voice_card_${voice.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) PeachPink else MatchaSurfaceContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.GraphicEq,
                                        contentDescription = null,
                                        tint = MatchaGreenDeep,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = voice.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MatchaGreenDeep
                                    )
                                    Text(
                                        text = "${voice.language} · ${voice.gender} · ${voice.style}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MatchaMutedText
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = PeachPinkDeep
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onGenerateVoiceover,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PeachPink,
                    contentColor = MatchaGreenDeep
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("generate_voiceover_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.RecordVoiceOver,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                val chosen = VoiceCatalog.findById(selectedVoiceId)
                Text(
                    text = "Generate ${chosen.name} & Place on Timeline",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
fun ExportOptionsDialog(
    initialConfig: ExportConfig,
    hasSubtitles: Boolean,
    hasVoiceover: Boolean,
    onStartExport: (ExportConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedRes by remember(initialConfig) { mutableStateOf(initialConfig.resolution) }
    var selectedFps by remember(initialConfig) { mutableStateOf(initialConfig.fps) }
    var burnSubs by remember(initialConfig, hasSubtitles) { mutableStateOf(hasSubtitles) }
    var keepOrigAudio by remember(initialConfig, hasVoiceover) { mutableStateOf(!hasVoiceover) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MatchaSurface,
        title = {
            Text(
                text = "Step 5 · Export MP4 Video",
                style = MaterialTheme.typography.titleMedium,
                color = MatchaGreenDeep
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Target Resolution",
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ExportResolution.entries.forEach { res ->
                        FilterChip(
                            selected = selectedRes == res,
                            onClick = { selectedRes = res },
                            label = { Text(res.label, style = MaterialTheme.typography.labelMedium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PeachPink,
                                selectedLabelColor = MatchaGreenDeep
                            ),
                            modifier = Modifier.testTag("export_res_${res.name}")
                        )
                    }
                }

                Text(
                    text = "Target Frame Rate (FPS)",
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExportFps.entries.forEach { fps ->
                        FilterChip(
                            selected = selectedFps == fps,
                            onClick = { selectedFps = fps },
                            label = { Text(fps.label, style = MaterialTheme.typography.labelMedium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PeachPink,
                                selectedLabelColor = MatchaGreenDeep
                            ),
                            modifier = Modifier.testTag("export_fps_${fps.fps}")
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Burn-in Subtitles", style = MaterialTheme.typography.bodyMedium, color = MatchaGreenDeep)
                        Text(
                            text = if (hasSubtitles) "Renders synced SRT overlay onto frames" else "No subtitles extracted yet",
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaMutedText
                        )
                    }
                    Switch(
                        checked = burnSubs && hasSubtitles,
                        enabled = hasSubtitles,
                        onCheckedChange = { burnSubs = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MatchaGreenDeep, checkedTrackColor = PeachPink)
                    )
                }

                if (hasVoiceover) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Keep Original Audio", style = MaterialTheme.typography.bodyMedium, color = MatchaGreenDeep)
                            Text(
                                text = "Mix original video audio with AI voiceover",
                                style = MaterialTheme.typography.bodySmall,
                                color = MatchaMutedText
                            )
                        }
                        Switch(
                            checked = keepOrigAudio,
                            onCheckedChange = { keepOrigAudio = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = MatchaGreenDeep, checkedTrackColor = PeachPink)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onStartExport(
                        ExportConfig(
                            resolution = selectedRes,
                            fps = selectedFps,
                            burnSubtitles = burnSubs && hasSubtitles,
                            keepOriginalAudio = keepOrigAudio
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PeachPink,
                    contentColor = MatchaGreenDeep
                ),
                modifier = Modifier.testTag("confirm_export_mp4_button")
            ) {
                Text("Render & Export MP4")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MatchaGreenDark)
            }
        }
    )
}

@Composable
fun ExportStatusDialog(
    exportState: ExportState,
    onCancel: () -> Unit,
    onSaveCopyAs: () -> Unit,
    onShareMp4: (String) -> Unit,
    onDismiss: () -> Unit
) {
    when (exportState) {
        ExportState.Idle -> Unit
        is ExportState.Running -> {
            AlertDialog(
                onDismissRequest = {},
                containerColor = MatchaSurface,
                title = {
                    Text("Exporting MP4 (Hardware)", style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(exportState.stageLabel, style = MaterialTheme.typography.bodyMedium, color = MatchaMutedText)
                        LinearProgressIndicator(
                            progress = { (exportState.progressPercent / 100f).coerceIn(0f, 1f) },
                            color = PeachPink,
                            trackColor = MatchaSurfaceContainer,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "${exportState.progressPercent}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = MatchaGreenDark
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = onCancel) {
                        Text("Cancel Export", color = StatusError)
                    }
                }
            )
        }

        is ExportState.Completed -> {
            val sizeMb = String.format(java.util.Locale.US, "%.2f MB", exportState.fileSizeBytes / (1024f * 1024f))
            AlertDialog(
                onDismissRequest = onDismiss,
                containerColor = MatchaSurface,
                icon = {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(32.dp))
                },
                title = {
                    Text("MP4 Export Complete", style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("File size: $sizeMb", style = MaterialTheme.typography.bodyMedium, color = MatchaGreenDeep)
                        Text(
                            text = if (exportState.mediaStoreUri != null) {
                                "Saved to Movies/MatchaCut on your device."
                            } else {
                                "Rendered to local export cache. Tap Save Copy to pick a folder."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaMutedText
                        )
                    }
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onSaveCopyAs) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Save Copy")
                        }
                        Button(
                            onClick = { onShareMp4(exportState.outputPath) },
                            colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = onDismiss) {
                        Text("Done", color = MatchaGreenDark)
                    }
                }
            )
        }

        is ExportState.Failed -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                containerColor = MatchaSurface,
                icon = {
                    Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = StatusError, modifier = Modifier.size(32.dp))
                },
                title = {
                    Text("Export Failed", style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
                },
                text = {
                    Text(exportState.message, style = MaterialTheme.typography.bodyMedium, color = MatchaMutedText)
                },
                confirmButton = {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                    ) {
                        Text("OK")
                    }
                }
            )
        }
    }
}

@Composable
fun ValidationAlertDialog(
    alert: ValidationAlert,
    onFixToChinese: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MatchaSurface,
        icon = {
            Icon(Icons.Filled.WarningAmber, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(30.dp))
        },
        title = {
            Text(alert.title, style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
        },
        text = {
            Text(alert.message, style = MaterialTheme.typography.bodyMedium, color = MatchaMutedText)
        },
        confirmButton = {
            if (alert.showLanguageFixButton) {
                Button(
                    onClick = {
                        onFixToChinese()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                ) {
                    Text("Use Chinese (Default)")
                }
            } else {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                ) {
                    Text("Adjust & Retry")
                }
            }
        },
        dismissButton = if (alert.showLanguageFixButton) {
            {
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = MatchaGreenDark)
                }
            }
        } else null
    )
}
