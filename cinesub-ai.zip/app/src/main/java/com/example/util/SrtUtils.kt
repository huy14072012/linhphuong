package com.example.util

import com.example.model.SrtSegment
import java.util.Locale

object SrtUtils {

    private val timestampRegex = Regex(
        """(\d{1,2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{3})"""
    )

    fun formatSrtTimestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val hours = safe / 3_600_000L
        val minutes = (safe % 3_600_000L) / 60_000L
        val seconds = (safe % 60_000L) / 1_000L
        val millis = safe % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    fun formatCompactTime(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val totalSeconds = safe / 1_000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        val tenths = (safe % 1_000L) / 100L
        return String.format(Locale.US, "%02d:%02d.%d", minutes, seconds, tenths)
    }

    fun toSrtString(segments: List<SrtSegment>, useTranslated: Boolean): String {
        return buildString {
            segments.forEachIndexed { idx, seg ->
                val text = if (useTranslated) {
                    seg.translatedText.ifBlank { seg.originalText }
                } else {
                    seg.originalText
                }.trim()
                append(seg.index.takeIf { it > 0 } ?: (idx + 1))
                append('\n')
                append(formatSrtTimestamp(seg.startMs))
                append(" --> ")
                append(formatSrtTimestamp(seg.endMs))
                append('\n')
                append(text)
                append("\n\n")
            }
        }.trimEnd() + "\n"
    }

    /**
     * Parses a Gemini-returned SRT string while strictly preserving original indices and timestamps.
     */
    fun parseTranslatedSrtPreservingTiming(
        rawResponse: String,
        originalSegments: List<SrtSegment>
    ): List<SrtSegment> {
        val cleaned = rawResponse
            .replace(Regex("""^```(?:srt|plaintext|text)?\s*""", RegexOption.MULTILINE), "")
            .replace(Regex("""```\s*$""", RegexOption.MULTILINE), "")
            .trim()

        val blocks = cleaned.split(Regex("""\r?\n\s*\r?\n""")).filter { it.isNotBlank() }
        val parsedByIndex = mutableMapOf<Int, String>()
        val sequentialTexts = mutableListOf<String>()

        for (block in blocks) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) continue

            val tsLineIdx = lines.indexOfFirst { timestampRegex.containsMatchIn(it) }
            if (tsLineIdx >= 0) {
                val parsedIndex = if (tsLineIdx > 0) {
                    lines[tsLineIdx - 1].trim().toIntOrNull()
                } else {
                    null
                }
                val textLines = lines.drop(tsLineIdx + 1)
                val joined = textLines.joinToString("\n").trim()
                if (joined.isNotBlank()) {
                    sequentialTexts.add(joined)
                    if (parsedIndex != null) {
                        parsedByIndex[parsedIndex] = joined
                    }
                }
            }
        }

        return originalSegments.mapIndexed { pos, original ->
            val translated = parsedByIndex[original.index]
                ?: sequentialTexts.getOrNull(pos)
                ?: ""
            original.copy(translatedText = translated.trim())
        }
    }
}
