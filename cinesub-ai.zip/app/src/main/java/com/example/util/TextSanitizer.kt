package com.example.util

import com.example.model.SrtSegment

sealed interface SanitationResult {
    data class Valid(val sanitizedSegments: List<SrtSegment>) : SanitationResult
    data class Blocked(val reason: String) : SanitationResult
}

object TextSanitizer {

    fun isChineseCodePoint(cp: Int): Boolean {
        return (cp in 0x4E00..0x9FFF) ||
            (cp in 0x3400..0x4DBF) ||
            (cp in 0xF900..0xFAFF) ||
            (cp in 0x20000..0x2A6DF) ||
            (cp in 0x2A700..0x2B73F) ||
            (cp in 0x2B740..0x2B81F) ||
            (cp in 0x2B820..0x2CEAF)
    }

    fun isCjkPunctuationOrFullwidth(cp: Int): Boolean {
        return (cp in 0x3000..0x303F) || (cp in 0xFF00..0xFFEF)
    }

    fun containsChineseCharacters(text: String): Boolean {
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            if (isChineseCodePoint(cp)) return true
            i += Character.charCount(cp)
        }
        return false
    }

    fun countChineseCharacters(text: String): Int {
        var count = 0
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            if (isChineseCodePoint(cp)) count++
            i += Character.charCount(cp)
        }
        return count
    }

    fun sanitizeForVoiceover(translatedText: String): String {
        val sb = StringBuilder(translatedText.length)
        var i = 0
        while (i < translatedText.length) {
            val cp = translatedText.codePointAt(i)
            if (!isChineseCodePoint(cp) && !isCjkPunctuationOrFullwidth(cp)) {
                sb.appendCodePoint(cp)
            }
            i += Character.charCount(cp)
        }
        return sb.toString()
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    fun validateSanitizedVoiceoverScript(segments: List<SrtSegment>): SanitationResult {
        if (segments.isEmpty()) {
            return SanitationResult.Blocked("No translated subtitle segments found.")
        }

        val sanitized = mutableListOf<SrtSegment>()
        for (segment in segments) {
            val rawTranslated = segment.translatedText.trim()
            if (rawTranslated.isEmpty()) {
                return SanitationResult.Blocked(
                    "Segment #${segment.index} has no translated text. Re-run Gemini translation first."
                )
            }
            val cleaned = sanitizeForVoiceover(rawTranslated)
            if (cleaned.isEmpty() || containsChineseCharacters(cleaned)) {
                return SanitationResult.Blocked(
                    "Segment #${segment.index} still contains only source Chinese characters after sanitation. Re-run Gemini translation."
                )
            }
            sanitized.add(segment.copy(translatedText = cleaned))
        }

        return SanitationResult.Valid(sanitized)
    }
}
