package com.example.model

import android.graphics.Bitmap

enum class WorkflowStep(val stepNumber: Int, val shortLabel: String) {
    EMPTY(0, "Import"),
    VIDEO_IMPORTED(1, "Extract"),
    SUBTITLES_EXTRACTED(2, "Translate"),
    TRANSLATED(3, "Voiceover"),
    VOICEOVER_READY(4, "Export")
}

enum class ExtractionMethod(val label: String) {
    OCR("Image OCR"),
    AUDIO("Audio to SRT")
}

enum class SourceLanguage(val displayName: String, val code: String) {
    CHINESE("Chinese (Default)", "zh"),
    ENGLISH("English", "en"),
    JAPANESE("Japanese", "ja"),
    KOREAN("Korean", "ko")
}

enum class TargetLanguage(val displayName: String, val code: String) {
    VIETNAMESE("Vietnamese", "vi"),
    ENGLISH("English", "en"),
    SPANISH("Spanish", "es"),
    FRENCH("French", "fr"),
    JAPANESE("Japanese", "ja"),
    KOREAN("Korean", "ko"),
    THAI("Thai", "th"),
    INDONESIAN("Indonesian", "id")
}

data class NormalizedRect(
    val left: Float = 0.08f,
    val top: Float = 0.72f,
    val right: Float = 0.92f,
    val bottom: Float = 0.90f
) {
    val width: Float get() = (right - left).coerceAtLeast(0.08f)
    val height: Float get() = (bottom - top).coerceAtLeast(0.06f)

    fun clamped(): NormalizedRect {
        val l = left.coerceIn(0f, 0.90f)
        val t = top.coerceIn(0f, 0.92f)
        val r = right.coerceIn(l + 0.08f, 1f)
        val b = bottom.coerceIn(t + 0.06f, 1f)
        return NormalizedRect(l, t, r, b)
    }
}

data class VideoMetadata(
    val uriString: String,
    val displayName: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Float,
    val hasAudioTrack: Boolean,
    val fileSizeBytes: Long
) {
    val resolutionLabel: String get() = "${width}×${height}"
    val fpsLabel: String get() = String.format(java.util.Locale.US, "%.1f fps", fps)
}

data class SrtSegment(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val originalText: String,
    val translatedText: String = "",
    val voiceoverAudioPath: String? = null,
    val voiceoverDurationMs: Long = 0L
) {
    val displayText: String
        get() = translatedText.ifBlank { originalText }
}

data class VoiceOption(
    val id: String,
    val name: String,
    val language: String,
    val gender: String,
    val style: String,
    val apiVoiceCode: String
)

enum class TtsPayloadPreset(val label: String) {
    OPENAI_COMPATIBLE("OpenAI /v1/audio/speech"),
    CUSTOM_JSON("Custom JSON {voice, text}"),
    ELEVENLABS_STYLE("ElevenLabs REST")
}

enum class TtsEngineMode(val label: String) {
    CONFIGURABLE_API("Configurable TTS API"),
    SYSTEM_TTS_OFFLINE("On-Device System TTS")
}

data class ApiConfig(
    val geminiApiKey: String = "",
    val geminiModel: String = "gemini-2.5-flash",
    val ttsEndpointUrl: String = "",
    val ttsApiKey: String = "",
    val ttsPayloadPreset: TtsPayloadPreset = TtsPayloadPreset.OPENAI_COMPATIBLE,
    val ttsEngineMode: TtsEngineMode = TtsEngineMode.CONFIGURABLE_API
)

enum class ExportResolution(val label: String, val targetHeight: Int?) {
    P720("720p HD", 720),
    P1080("1080p Full HD", 1080),
    ORIGINAL("Original", null)
}

enum class ExportFps(val label: String, val fps: Int) {
    FPS_24("24 fps", 24),
    FPS_30("30 fps", 30),
    FPS_60("60 fps", 60)
}

data class ExportConfig(
    val resolution: ExportResolution = ExportResolution.P1080,
    val fps: ExportFps = ExportFps.FPS_30,
    val burnSubtitles: Boolean = true,
    val keepOriginalAudio: Boolean = false
)

sealed interface ExportState {
    data object Idle : ExportState
    data class Running(val progressPercent: Int, val stageLabel: String) : ExportState
    data class Completed(
        val outputPath: String,
        val mediaStoreUri: String?,
        val fileSizeBytes: Long
    ) : ExportState
    data class Failed(val message: String) : ExportState
}

enum class ActiveTrack {
    VIDEO,
    SUBTITLE,
    VOICEOVER
}

enum class StudioSheet {
    NONE,
    SRT_EDITOR,
    VOICEOVER,
    API_SETTINGS,
    EXPORT_OPTIONS
}

data class FilmstripFrame(
    val timeMs: Long,
    val bitmap: Bitmap
)
