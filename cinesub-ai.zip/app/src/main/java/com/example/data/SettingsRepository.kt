package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.ApiConfig
import com.example.model.TargetLanguage
import com.example.model.TtsEngineMode
import com.example.model.TtsPayloadPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "matchacut_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val GEMINI_API_KEY = stringPreferencesKey("gemini_api_key")
        val GEMINI_MODEL = stringPreferencesKey("gemini_model")
        val TTS_ENDPOINT_URL = stringPreferencesKey("tts_endpoint_url")
        val TTS_API_KEY = stringPreferencesKey("tts_api_key")
        val TTS_PAYLOAD_PRESET = stringPreferencesKey("tts_payload_preset")
        val TTS_ENGINE_MODE = stringPreferencesKey("tts_engine_mode")
        val TARGET_LANGUAGE = stringPreferencesKey("target_language")
        val SELECTED_VOICE_ID = stringPreferencesKey("selected_voice_id")
    }

    val apiConfigFlow: Flow<ApiConfig> = context.dataStore.data.map { prefs ->
        ApiConfig(
            geminiApiKey = prefs[Keys.GEMINI_API_KEY].orEmpty(),
            geminiModel = prefs[Keys.GEMINI_MODEL].orEmpty().ifBlank { "gemini-2.5-flash" },
            ttsEndpointUrl = prefs[Keys.TTS_ENDPOINT_URL].orEmpty(),
            ttsApiKey = prefs[Keys.TTS_API_KEY].orEmpty(),
            ttsPayloadPreset = prefs[Keys.TTS_PAYLOAD_PRESET]?.let { name ->
                TtsPayloadPreset.entries.find { it.name == name }
            } ?: TtsPayloadPreset.OPENAI_COMPATIBLE,
            ttsEngineMode = prefs[Keys.TTS_ENGINE_MODE]?.let { name ->
                TtsEngineMode.entries.find { it.name == name }
            } ?: TtsEngineMode.CONFIGURABLE_API
        )
    }

    val targetLanguageFlow: Flow<TargetLanguage> = context.dataStore.data.map { prefs ->
        val code = prefs[Keys.TARGET_LANGUAGE]
        TargetLanguage.entries.find { it.code == code } ?: TargetLanguage.VIETNAMESE
    }

    val selectedVoiceIdFlow: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.SELECTED_VOICE_ID].orEmpty().ifBlank { "ngoc_huyen" }
    }

    suspend fun saveApiConfig(config: ApiConfig) {
        context.dataStore.edit { prefs ->
            prefs[Keys.GEMINI_API_KEY] = config.geminiApiKey.trim()
            prefs[Keys.GEMINI_MODEL] = config.geminiModel.trim().ifBlank { "gemini-2.5-flash" }
            prefs[Keys.TTS_ENDPOINT_URL] = config.ttsEndpointUrl.trim()
            prefs[Keys.TTS_API_KEY] = config.ttsApiKey.trim()
            prefs[Keys.TTS_PAYLOAD_PRESET] = config.ttsPayloadPreset.name
            prefs[Keys.TTS_ENGINE_MODE] = config.ttsEngineMode.name
        }
    }

    suspend fun saveTargetLanguage(language: TargetLanguage) {
        context.dataStore.edit { prefs ->
            prefs[Keys.TARGET_LANGUAGE] = language.code
        }
    }

    suspend fun saveSelectedVoiceId(voiceId: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_VOICE_ID] = voiceId
        }
    }
}
