package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.model.FilmstripFrame
import com.example.model.VideoMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object VideoInspector {

    suspend fun inspect(context: Context, uri: Uri): VideoMetadata = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var displayName = "Imported Video.mp4"
        var fileSizeBytes = 0L

        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: displayName
                    if (sizeIdx >= 0) fileSizeBytes = cursor.getLong(sizeIdx)
                }
            }

        val retriever = MediaMetadataRetriever()
        var durationMs = 0L
        var rawWidth = 1080
        var rawHeight = 1920
        var rotation = 0
        var captureFps = 0f
        var hasAudio = false

        try {
            retriever.setDataSource(context, uri)
            durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            rawWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 1080
            rawHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 1920
            rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
            captureFps = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
                ?.toFloatOrNull() ?: 0f
            hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
        } finally {
            runCatching { retriever.release() }
        }

        val extractor = MediaExtractor()
        var trackFps = 0f
        try {
            extractor.setDataSource(context, uri, null)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/")) {
                    if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        trackFps = runCatching { format.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                            .getOrElse {
                                runCatching { format.getFloat(MediaFormat.KEY_FRAME_RATE) }.getOrDefault(0f)
                            }
                    }
                    if (trackFps <= 0f && durationMs > 0L) {
                        extractor.selectTrack(i)
                        var sampleCount = 0
                        val limitUs = minOf(durationMs * 1000L, 2_000_000L)
                        while (extractor.sampleTime in 0..limitUs) {
                            sampleCount++
                            if (!extractor.advance()) break
                        }
                        if (sampleCount > 1 && limitUs > 0L) {
                            trackFps = (sampleCount / (limitUs / 1_000_000f)).coerceIn(1f, 120f)
                        }
                    }
                } else if (mime.startsWith("audio/")) {
                    hasAudio = true
                }
            }
        } catch (_: Throwable) {
            // Fallback to metadata retriever values
        } finally {
            runCatching { extractor.release() }
        }

        val finalFps = when {
            trackFps > 0f -> trackFps
            captureFps > 0f -> captureFps
            else -> 30f
        }

        val (displayWidth, displayHeight) = if (rotation == 90 || rotation == 270) {
            rawHeight to rawWidth
        } else {
            rawWidth to rawHeight
        }

        VideoMetadata(
            uriString = uri.toString(),
            displayName = displayName,
            durationMs = durationMs.coerceAtLeast(100L),
            width = displayWidth,
            height = displayHeight,
            fps = finalFps,
            hasAudioTrack = hasAudio,
            fileSizeBytes = fileSizeBytes
        )
    }

    suspend fun extractFilmstrip(
        context: Context,
        uri: Uri,
        durationMs: Long,
        count: Int = 10
    ): List<FilmstripFrame> = withContext(Dispatchers.IO) {
        val frames = mutableListOf<FilmstripFrame>()
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val safeDuration = durationMs.coerceAtLeast(500L)
            val step = (safeDuration / count.coerceAtLeast(1)).coerceAtLeast(100L)
            for (i in 0 until count) {
                val timeMs = (i * step).coerceAtMost(safeDuration - 50L).coerceAtLeast(0L)
                val timeUs = timeMs * 1000L
                val bmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getScaledFrameAtTime(
                        timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                        160,
                        120
                    )
                } else {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { raw ->
                        val scaled = Bitmap.createScaledBitmap(raw, 120, 90, true)
                        if (scaled != raw) raw.recycle()
                        scaled
                    }
                }
                if (bmp != null) {
                    frames.add(FilmstripFrame(timeMs = timeMs, bitmap = bmp))
                }
            }
        } catch (_: Throwable) {
            // Best-effort thumbnails
        } finally {
            runCatching { retriever.release() }
        }
        frames
    }
}
