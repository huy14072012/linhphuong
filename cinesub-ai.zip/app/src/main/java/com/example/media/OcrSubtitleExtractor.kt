package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import com.example.model.NormalizedRect
import com.example.model.SourceLanguage
import com.example.model.SrtSegment
import com.example.util.TextSanitizer
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

sealed interface OcrExtractionResult {
    data class Success(
        val segments: List<SrtSegment>,
        val sampledFrames: Int,
        val chineseCharactersFound: Int
    ) : OcrExtractionResult

    data class ValidationBlocked(
        val title: String,
        val message: String,
        val isWrongLanguageConfig: Boolean
    ) : OcrExtractionResult

    data class Error(val message: String) : OcrExtractionResult
}

object OcrSubtitleExtractor {

    private data class RawSample(val timeMs: Long, val text: String)

    suspend fun extractSubtitles(
        context: Context,
        uri: Uri,
        durationMs: Long,
        cropBox: NormalizedRect,
        sourceLanguage: SourceLanguage,
        onProgress: (Float) -> Unit
    ): OcrExtractionResult = withContext(Dispatchers.IO) {
        val safeCrop = cropBox.clamped()
        val recognizer = createRecognizer(sourceLanguage)
        val chineseCheckRecognizer = if (sourceLanguage != SourceLanguage.CHINESE) {
            TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        } else {
            null
        }

        val retriever = MediaMetadataRetriever()
        val samples = mutableListOf<RawSample>()
        var chineseDetectedOnNonChineseMode = 0

        try {
            retriever.setDataSource(context, uri)
            val safeDuration = durationMs.coerceAtLeast(1000L)
            val stepMs = when {
                safeDuration <= 15_000L -> 500L
                safeDuration <= 45_000L -> 750L
                else -> (safeDuration / 45L).coerceAtLeast(900L)
            }

            val timestamps = mutableListOf<Long>()
            var t = 0L
            while (t < safeDuration) {
                timestamps.add(t)
                t += stepMs
            }
            if (timestamps.isEmpty()) timestamps.add(0L)

            timestamps.forEachIndexed { idx, timeMs ->
                onProgress((idx + 1).toFloat() / timestamps.size.toFloat())
                var frameBitmap: Bitmap? = null
                var croppedBitmap: Bitmap? = null
                try {
                    frameBitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                        retriever.getScaledFrameAtTime(
                            timeMs * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST,
                            960,
                            960
                        )
                    } else {
                        retriever.getFrameAtTime(
                            timeMs * 1000L,
                            MediaMetadataRetriever.OPTION_CLOSEST
                        )
                    }

                    if (frameBitmap != null) {
                        val cropX = (safeCrop.left * frameBitmap.width).toInt()
                            .coerceIn(0, (frameBitmap.width - 2).coerceAtLeast(0))
                        val cropY = (safeCrop.top * frameBitmap.height).toInt()
                            .coerceIn(0, (frameBitmap.height - 2).coerceAtLeast(0))
                        val cropW = (safeCrop.width * frameBitmap.width).toInt()
                            .coerceIn(1, frameBitmap.width - cropX)
                        val cropH = (safeCrop.height * frameBitmap.height).toInt()
                            .coerceIn(1, frameBitmap.height - cropY)

                        croppedBitmap = Bitmap.createBitmap(frameBitmap, cropX, cropY, cropW, cropH)
                        val image = InputImage.fromBitmap(croppedBitmap, 0)
                        val visionText = recognizer.process(image).await()
                        val recognized = visionText.text
                            .lines()
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                            .joinToString(" ")
                            .trim()

                        if (recognized.isNotBlank()) {
                            samples.add(RawSample(timeMs, recognized))
                        }

                        // Cross-check if user picked non-Chinese language when Chinese subtitles actually exist
                        if (chineseCheckRecognizer != null && idx % 3 == 0) {
                            val zhCheck = chineseCheckRecognizer.process(image).await().text
                            chineseDetectedOnNonChineseMode += TextSanitizer.countChineseCharacters(zhCheck)
                        }
                    }
                } finally {
                    if (croppedBitmap != null && croppedBitmap != frameBitmap) {
                        croppedBitmap.recycle()
                    }
                    frameBitmap?.recycle()
                }
            }

            val allText = samples.joinToString(" ") { it.text }
            val chineseCount = TextSanitizer.countChineseCharacters(allText)

            // Strict validation rule from specification:
            // 1. If default Chinese is selected and NO Chinese characters are detected -> block & force re-adjust box or language
            if (sourceLanguage == SourceLanguage.CHINESE && chineseCount == 0) {
                return@withContext OcrExtractionResult.ValidationBlocked(
                    title = "No Chinese Subtitles Detected",
                    message = if (allText.isBlank()) {
                        "No text was recognized inside the bounding box. Drag and resize the peach bounding box tightly around the subtitle region and try again."
                    } else {
                        "Recognized text contained 0 Chinese characters (found: \"${allText.take(40)}\"). Reposition the bounding box over the Chinese subtitles or switch the OCR language."
                    },
                    isWrongLanguageConfig = false
                )
            }

            // 2. If user selected non-Chinese language, but Chinese characters were detected -> block & force language correction
            if (sourceLanguage != SourceLanguage.CHINESE &&
                (chineseDetectedOnNonChineseMode > 0 || chineseCount > 0)
            ) {
                return@withContext OcrExtractionResult.ValidationBlocked(
                    title = "Wrong OCR Language Selected",
                    message = "Chinese subtitles were detected inside the box while OCR language is set to ${sourceLanguage.displayName}. Switch the OCR language back to Chinese (Default) or adjust the box.",
                    isWrongLanguageConfig = true
                )
            }

            if (samples.isEmpty()) {
                return@withContext OcrExtractionResult.ValidationBlocked(
                    title = "No Subtitles Found in Box",
                    message = "No readable subtitle text was detected inside the selected area. Adjust the bounding box over the subtitle region and retry.",
                    isWrongLanguageConfig = false
                )
            }

            val merged = mergeSamplesIntoSegments(samples, stepMs, safeDuration)
            OcrExtractionResult.Success(
                segments = merged,
                sampledFrames = timestamps.size,
                chineseCharactersFound = chineseCount
            )
        } catch (t: Throwable) {
            OcrExtractionResult.Error(t.message ?: "Local OCR extraction failed.")
        } finally {
            runCatching { recognizer.close() }
            runCatching { chineseCheckRecognizer?.close() }
            runCatching { retriever.release() }
        }
    }

    private fun createRecognizer(language: SourceLanguage): TextRecognizer {
        return when (language) {
            SourceLanguage.CHINESE -> TextRecognition.getClient(
                ChineseTextRecognizerOptions.Builder().build()
            )
            SourceLanguage.ENGLISH -> TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS
            )
            SourceLanguage.JAPANESE -> TextRecognition.getClient(
                JapaneseTextRecognizerOptions.Builder().build()
            )
            SourceLanguage.KOREAN -> TextRecognition.getClient(
                KoreanTextRecognizerOptions.Builder().build()
            )
        }
    }

    private fun mergeSamplesIntoSegments(
        samples: List<RawSample>,
        stepMs: Long,
        totalDurationMs: Long
    ): List<SrtSegment> {
        if (samples.isEmpty()) return emptyList()
        val segments = mutableListOf<SrtSegment>()
        var currentStart = samples.first().timeMs
        var currentLastSeen = samples.first().timeMs
        var currentBestText = samples.first().text

        for (i in 1 until samples.size) {
            val sample = samples[i]
            val closeInTime = (sample.timeMs - currentLastSeen) <= (stepMs * 2L)
            val similarText = textSimilarity(currentBestText, sample.text) >= 0.72f
            if (closeInTime && similarText) {
                currentLastSeen = sample.timeMs
                if (sample.text.length > currentBestText.length) {
                    currentBestText = sample.text
                }
            } else {
                val endMs = (currentLastSeen + stepMs).coerceAtMost(totalDurationMs)
                segments.add(
                    SrtSegment(
                        index = segments.size + 1,
                        startMs = currentStart,
                        endMs = max(endMs, currentStart + 400L).coerceAtMost(totalDurationMs),
                        originalText = currentBestText
                    )
                )
                currentStart = sample.timeMs
                currentLastSeen = sample.timeMs
                currentBestText = sample.text
            }
        }

        val finalEnd = (currentLastSeen + stepMs).coerceAtMost(totalDurationMs)
        segments.add(
            SrtSegment(
                index = segments.size + 1,
                startMs = currentStart,
                endMs = max(finalEnd, currentStart + 400L).coerceAtMost(totalDurationMs),
                originalText = currentBestText
            )
        )
        return segments
    }

    private fun textSimilarity(a: String, b: String): Float {
        if (a == b) return 1f
        val normA = a.replace(Regex("""\s+"""), "")
        val normB = b.replace(Regex("""\s+"""), "")
        if (normA.isEmpty() || normB.isEmpty()) return 0f
        if (normA == normB) return 1f
        val setA = normA.toSet()
        val setB = normB.toSet()
        val intersection = setA.intersect(setB).size.toFloat()
        val union = setA.union(setB).size.toFloat()
        val jaccard = if (union > 0f) intersection / union else 0f
        val lenRatio = min(normA.length, normB.length).toFloat() / max(normA.length, normB.length).toFloat()
        return (jaccard * 0.75f) + (lenRatio * 0.25f)
    }
}
