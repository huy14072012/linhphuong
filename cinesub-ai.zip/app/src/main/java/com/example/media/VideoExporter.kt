package com.example.media

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.model.ExportConfig
import com.example.model.SrtSegment
import com.example.model.VideoMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import kotlin.coroutines.resume

sealed interface VideoExportResult {
    data class Success(
        val cacheFilePath: String,
        val mediaStoreUri: String?,
        val fileSizeBytes: Long
    ) : VideoExportResult

    data class Failure(val message: String) : VideoExportResult
}

/**
 * Memory-safe, single-buffer subtitle BitmapOverlay that reuses one ARGB_8888 strip bitmap
 * and redraws only when the active SRT segment changes.
 */
@OptIn(UnstableApi::class)
private class SubtitleStripOverlay(
    private val segments: List<SrtSegment>,
    overlayWidthPx: Int = 960,
    overlayHeightPx: Int = 180
) : BitmapOverlay() {

    private val bitmap: Bitmap = Bitmap.createBitmap(
        overlayWidthPx.coerceAtLeast(320),
        overlayHeightPx.coerceAtLeast(100),
        Bitmap.Config.ARGB_8888
    )
    private val canvas = Canvas(bitmap)
    private var lastSegmentIndex: Int = Int.MIN_VALUE

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(195, 22, 32, 21)
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(210, 244, 151, 142) // Peach pink subtle border
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(250, 252, 249)
        textSize = 38f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    private val settings = OverlaySettings.Builder()
        .setOverlayFrameAnchor(0f, -0.76f)
        .setBackgroundFrameAnchor(0f, -0.76f)
        .build()

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val timeMs = presentationTimeUs / 1000L
        val active = segments.firstOrNull { timeMs in it.startMs..it.endMs }
        val targetIndex = active?.index ?: -1

        if (targetIndex != lastSegmentIndex) {
            lastSegmentIndex = targetIndex
            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            val text = active?.displayText?.trim().orEmpty()
            if (text.isNotEmpty()) {
                val maxTextWidth = (bitmap.width * 0.88f).toInt().coerceAtLeast(120)
                val layout = StaticLayout.Builder
                    .obtain(text, 0, text.length, textPaint, maxTextWidth)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setMaxLines(3)
                    .build()

                val boxWidth = (0 until layout.lineCount)
                    .maxOfOrNull { layout.getLineWidth(it) }
                    ?.plus(48f)
                    ?.coerceAtMost(bitmap.width.toFloat() - 16f)
                    ?: maxTextWidth.toFloat()
                val boxHeight = (layout.height + 28f).coerceAtMost(bitmap.height.toFloat() - 8f)
                val left = (bitmap.width - boxWidth) / 2f
                val top = (bitmap.height - boxHeight) / 2f
                val rect = RectF(left, top, left + boxWidth, top + boxHeight)

                canvas.drawRoundRect(rect, 18f, 18f, bgPaint)
                canvas.drawRoundRect(rect, 18f, 18f, strokePaint)

                canvas.save()
                canvas.translate((bitmap.width - maxTextWidth) / 2f, top + 14f)
                layout.draw(canvas)
                canvas.restore()
            }
        }
        return bitmap
    }

    override fun release() {
        super.release()
        if (!bitmap.isRecycled) {
            bitmap.recycle()
        }
    }
}

@OptIn(UnstableApi::class)
object VideoExporter {

    private var activeTransformer: Transformer? = null

    fun cancelExport() {
        Handler(Looper.getMainLooper()).post {
            runCatching { activeTransformer?.cancel() }
            activeTransformer = null
        }
    }

    suspend fun exportMp4(
        context: Context,
        videoMetadata: VideoMetadata,
        segments: List<SrtSegment>,
        voiceoverWavPath: String?,
        exportConfig: ExportConfig,
        onProgress: (Int, String) -> Unit
    ): VideoExportResult = withContext(Dispatchers.Main) {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outFile = File(exportDir, "matchacut_${System.currentTimeMillis()}.mp4")
        if (outFile.exists()) outFile.delete()

        val videoEffects = mutableListOf<Effect>()
        exportConfig.resolution.targetHeight?.let { targetH ->
            videoEffects.add(Presentation.createForHeight(targetH))
        }
        if (exportConfig.fps.fps.toFloat() < videoMetadata.fps - 1f) {
            videoEffects.add(FrameDropEffect.createDefaultFrameDropEffect(exportConfig.fps.fps.toFloat()))
        }

        val subtitleOverlay = if (exportConfig.burnSubtitles && segments.isNotEmpty()) {
            SubtitleStripOverlay(segments)
        } else {
            null
        }
        if (subtitleOverlay != null) {
            videoEffects.add(OverlayEffect(listOf(subtitleOverlay)))
        }

        val hasVoiceover = !voiceoverWavPath.isNullOrBlank() && File(voiceoverWavPath).exists()
        val removeOriginalAudio = hasVoiceover && !exportConfig.keepOriginalAudio

        val mainVideoItem = EditedMediaItem.Builder(MediaItem.fromUri(Uri.parse(videoMetadata.uriString)))
            .setRemoveAudio(removeOriginalAudio)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        val mainVideoSequence = EditedMediaItemSequence(listOf(mainVideoItem))

        val composition = if (hasVoiceover) {
            val voItem = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(File(voiceoverWavPath!!))))
                .setRemoveVideo(true)
                .build()
            val voSequence = EditedMediaItemSequence(listOf(voItem))
            Composition.Builder(listOf(mainVideoSequence, voSequence)).build()
        } else {
            Composition.Builder(listOf(mainVideoSequence)).build()
        }

        onProgress(5, "Initializing hardware encoder...")

        val exportResult = try {
            runTransformer(context, composition, outFile.absolutePath, onProgress)
        } catch (oom: OutOfMemoryError) {
            System.gc()
            return@withContext VideoExportResult.Failure(
                "Out of memory during export. Try choosing 720p resolution or 24/30 fps."
            )
        } catch (t: Throwable) {
            return@withContext VideoExportResult.Failure(
                t.message ?: "Hardware video export failed."
            )
        } finally {
            runCatching { subtitleOverlay?.release() }
        }

        if (exportResult != null) {
            return@withContext VideoExportResult.Failure(exportResult)
        }

        onProgress(96, "Saving MP4 to device...")
        val mediaUri = withContext(Dispatchers.IO) {
            saveToMediaStoreIfSupported(context, outFile)
        }
        onProgress(100, "Export complete")
        VideoExportResult.Success(
            cacheFilePath = outFile.absolutePath,
            mediaStoreUri = mediaUri?.toString(),
            fileSizeBytes = outFile.length()
        )
    }

    private suspend fun runTransformer(
        context: Context,
        composition: Composition,
        outputPath: String,
        onProgress: (Int, String) -> Unit
    ): String? = suspendCancellableCoroutine { cont ->
        val progressHolder = ProgressHolder()
        lateinit var transformer: Transformer
        val pollingScope = kotlinx.coroutines.CoroutineScope(Dispatchers.Main)

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                activeTransformer = null
                if (cont.isActive) cont.resume(null)
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException
            ) {
                activeTransformer = null
                val msg = when {
                    exportException.cause is OutOfMemoryError ->
                        "Device memory limit reached during encoding. Try 720p resolution."
                    else -> exportException.localizedMessage ?: "Export error (${exportException.errorCodeName})"
                }
                if (cont.isActive) cont.resume(msg)
            }
        }

        transformer = Transformer.Builder(context)
            .addListener(listener)
            .build()
        activeTransformer = transformer

        val pollJob = pollingScope.launch {
            while (isActive && cont.isActive) {
                val state = transformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(
                        progressHolder.progress.coerceIn(5, 95),
                        "Rendering video, subtitles & audio..."
                    )
                }
                delay(250L)
            }
        }

        cont.invokeOnCancellation {
            pollJob.cancel()
            runCatching { transformer.cancel() }
            activeTransformer = null
        }

        try {
            transformer.start(composition, outputPath)
        } catch (t: Throwable) {
            pollJob.cancel()
            activeTransformer = null
            if (cont.isActive) cont.resume(t.message ?: "Unable to start hardware Transformer.")
        }
    }

    private fun saveToMediaStoreIfSupported(context: Context, sourceFile: File): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        return runCatching {
            val resolver = context.contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, sourceFile.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/MatchaCut")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out, bufferSize = 64 * 1024)
                }
            }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        }.getOrNull()
    }
}
