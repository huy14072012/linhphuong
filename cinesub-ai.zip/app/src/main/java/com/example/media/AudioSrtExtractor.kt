package com.example.media

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.example.model.SrtSegment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder
import kotlin.math.sqrt

sealed interface AudioSrtResult {
    data class Success(
        val segments: List<SrtSegment>,
        val waveformPeaks: List<Float>
    ) : AudioSrtResult

    data class Error(val message: String) : AudioSrtResult
}

/**
 * Decodes local video audio stream via MediaExtractor + MediaCodec into 16-bit PCM,
 * computes real RMS energy windows and waveform peaks, and slices speech activity into SRT segments.
 */
object AudioSrtExtractor {

    suspend fun extractAudioSrt(
        context: Context,
        uri: Uri,
        durationMs: Long,
        onProgress: (Float) -> Unit
    ): AudioSrtResult = withContext(Dispatchers.IO) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(context, uri, null)
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = fmt
                    break
                }
            }

            if (audioTrackIndex < 0 || audioFormat == null) {
                return@withContext AudioSrtResult.Error("This video has no audio track for Audio-to-SRT extraction.")
            }

            extractor.selectTrack(audioTrackIndex)
            val mime = audioFormat.getString(MediaFormat.KEY_MIME)!!
            val sampleRate = audioFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE).coerceAtLeast(8000)
            val channels = audioFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)

            codec = MediaCodec.createDecoderByType(mime).apply {
                configure(audioFormat, null, null, 0)
                start()
            }

            val windowMs = 100L
            val samplesPerWindow = ((sampleRate * windowMs) / 1000L).toInt() * channels
            var currentSumSq = 0.0
            var currentCount = 0
            val windowRmsList = mutableListOf<Float>()

            val bufferInfo = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val timeoutUs = 10_000L
            val safeDurationUs = (durationMs.coerceAtLeast(1000L)) * 1000L

            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(timeoutUs)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)!!
                        val sampleSize = extractor.readSampleData(inBuf, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            val pts = extractor.sampleTime
                            codec.queueInputBuffer(inIdx, 0, sampleSize, pts, 0)
                            onProgress((pts.toFloat() / safeDurationUs.toFloat()).coerceIn(0f, 0.9f))
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && bufferInfo.size > 0) {
                        outBuf.position(bufferInfo.offset)
                        outBuf.limit(bufferInfo.offset + bufferInfo.size)
                        val shortBuf = outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        while (shortBuf.hasRemaining()) {
                            val sample = shortBuf.get().toDouble() / 32768.0
                            currentSumSq += sample * sample
                            currentCount++
                            if (currentCount >= samplesPerWindow) {
                                val rms = sqrt(currentSumSq / currentCount).toFloat()
                                windowRmsList.add(rms)
                                currentSumSq = 0.0
                                currentCount = 0
                            }
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                }
            }

            if (currentCount > 0) {
                windowRmsList.add(sqrt(currentSumSq / currentCount).toFloat())
            }

            onProgress(1f)

            if (windowRmsList.isEmpty()) {
                return@withContext AudioSrtResult.Error("No audio samples could be decoded from this video.")
            }

            val maxPeak = windowRmsList.maxOrNull()?.coerceAtLeast(0.01f) ?: 0.01f
            val normalizedWindows = windowRmsList.map { (it / maxPeak).coerceIn(0f, 1f) }
            val waveformPeaks = downsampleWaveform(normalizedWindows, 72)

            val segments = buildSpeechSegments(normalizedWindows, windowMs, durationMs)
            if (segments.isEmpty()) {
                return@withContext AudioSrtResult.Error("Audio track appears silent; no speech intervals detected.")
            }

            AudioSrtResult.Success(segments = segments, waveformPeaks = waveformPeaks)
        } catch (t: Throwable) {
            AudioSrtResult.Error(t.message ?: "Failed to decode local audio track.")
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun buildSpeechSegments(
        normalizedWindows: List<Float>,
        windowMs: Long,
        totalDurationMs: Long
    ): List<SrtSegment> {
        val sorted = normalizedWindows.sorted()
        val noiseFloor = sorted[(sorted.size * 0.25).toInt().coerceIn(0, sorted.lastIndex)]
        val threshold = (noiseFloor + 0.12f).coerceIn(0.10f, 0.35f)

        val rawIntervals = mutableListOf<Pair<Long, Long>>()
        var activeStart: Long? = null
        var silentWindows = 0

        normalizedWindows.forEachIndexed { idx, energy ->
            val timeMs = idx * windowMs
            if (energy >= threshold) {
                if (activeStart == null) activeStart = timeMs
                silentWindows = 0
            } else if (activeStart != null) {
                silentWindows++
                if (silentWindows >= 4) { // 400ms pause closes segment
                    val endMs = (timeMs - (silentWindows - 1) * windowMs).coerceAtLeast(activeStart!! + 450L)
                    rawIntervals.add(activeStart!! to endMs.coerceAtMost(totalDurationMs))
                    activeStart = null
                    silentWindows = 0
                }
            }
        }
        if (activeStart != null) {
            val endMs = (normalizedWindows.size * windowMs).coerceAtMost(totalDurationMs)
            rawIntervals.add(activeStart!! to endMs.coerceAtLeast(activeStart!! + 450L).coerceAtMost(totalDurationMs))
        }

        // Split overly long segments (>4.5s) and filter tiny blips (<350ms)
        val refined = mutableListOf<Pair<Long, Long>>()
        for ((s, e) in rawIntervals) {
            if (e - s < 350L) continue
            var cursor = s
            while (e - cursor > 4500L) {
                refined.add(cursor to (cursor + 4000L))
                cursor += 4000L
            }
            if (e - cursor >= 350L) {
                refined.add(cursor to e)
            }
        }

        return refined.mapIndexed { idx, (startMs, endMs) ->
            SrtSegment(
                index = idx + 1,
                startMs = startMs,
                endMs = endMs,
                originalText = "[Audio Segment ${idx + 1} · Tap to edit speech text]"
            )
        }
    }

    private fun downsampleWaveform(source: List<Float>, targetCount: Int): List<Float> {
        if (source.isEmpty()) return emptyList()
        if (source.size <= targetCount) return source
        val step = source.size.toFloat() / targetCount
        return List(targetCount) { i ->
            val start = (i * step).toInt().coerceIn(0, source.lastIndex)
            val end = ((i + 1) * step).toInt().coerceIn(start + 1, source.size)
            var peak = 0f
            for (k in start until end) {
                if (source[k] > peak) peak = source[k]
            }
            peak
        }
    }
}
