package com.example

import com.example.model.SrtSegment
import com.example.model.WorkflowStep
import com.example.network.VoiceCatalog
import com.example.util.SanitationResult
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.example.viewmodel.EditorUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkflowAndSanitizerTest {

    @Test
    fun voiceCatalogContainsMoreThan10VoicesIncludingNgocHuyenAndAdam() {
        val names = VoiceCatalog.voices.map { it.name }
        assertTrue("Expected > 10 voices, got ${names.size}", names.size > 10)
        assertTrue("Expected Ngọc Huyền in voice list", names.contains("Ngọc Huyền"))
        assertTrue("Expected Adam in voice list", names.contains("Adam"))
        assertEquals(names.size, names.distinct().size)
    }

    @Test
    fun srtParsingPreservesOriginalTimestampsAndIndices() {
        val originals = listOf(
            SrtSegment(index = 1, startMs = 1000L, endMs = 3250L, originalText = "你好世界"),
            SrtSegment(index = 2, startMs = 4000L, endMs = 6500L, originalText = "欢迎来到这里")
        )
        val geminiRaw = """
            ```srt
            1
            00:00:99,999 --> 00:01:99,999
            Xin chào thế giới

            2
            00:00:04,000 --> 00:00:06,500
            Chào mừng đến đây
            ```
        """.trimIndent()

        val translated = SrtUtils.parseTranslatedSrtPreservingTiming(geminiRaw, originals)
        assertEquals(2, translated.size)
        assertEquals(1000L, translated[0].startMs)
        assertEquals(3250L, translated[0].endMs)
        assertEquals("Xin chào thế giới", translated[0].translatedText)
        assertEquals(4000L, translated[1].startMs)
        assertEquals(6500L, translated[1].endMs)
        assertEquals("Chào mừng đến đây", translated[1].translatedText)
    }

    @Test
    fun textSanitizerStripsChineseCharactersAndBlocksSourceOnlyText() {
        assertTrue(TextSanitizer.containsChineseCharacters("你好世界"))
        assertFalse(TextSanitizer.containsChineseCharacters("Xin chào thế giới"))

        val cleaned = TextSanitizer.sanitizeForVoiceover("Xin chào 你好 bạn")
        assertFalse(TextSanitizer.containsChineseCharacters(cleaned))
        assertEquals("Xin chào bạn", cleaned)

        val blocked = TextSanitizer.validateSanitizedVoiceoverScript(
            listOf(SrtSegment(1, 0L, 1000L, "你好", translatedText = "你好"))
        )
        assertTrue(blocked is SanitationResult.Blocked)
    }

    @Test
    fun voiceoverRemainsStrictlyLockedUntilGeminiTranslationCompletes() {
        val segExtracted = listOf(SrtSegment(1, 0L, 1500L, "你好", translatedText = ""))
        val step2State = EditorUiState(
            workflowStep = WorkflowStep.SUBTITLES_EXTRACTED,
            segments = segExtracted
        )
        assertFalse(step2State.isVoiceoverUnlocked)

        val segTranslated = listOf(SrtSegment(1, 0L, 1500L, "你好", translatedText = "Xin chào"))
        val step3State = EditorUiState(
            workflowStep = WorkflowStep.TRANSLATED,
            segments = segTranslated
        )
        assertTrue(step3State.isVoiceoverUnlocked)
    }
}
