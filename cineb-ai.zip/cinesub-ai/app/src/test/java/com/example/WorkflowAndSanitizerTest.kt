package com.example

import com.example.model.ApiConfig
import com.example.model.AppLanguage
import com.example.model.SrtSegment
import com.example.model.TranslationProvider
import com.example.model.TtsEngineMode
import com.example.network.GeminiTranslator
import com.example.network.VoiceCatalog
import com.example.util.SanitationResult
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.example.util.stringsForLanguage
import com.example.viewmodel.EditorUiState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkflowAndSanitizerTest {

    @Test
    fun voiceCatalogContainsNgocHuyenNamMinhHoaiTayAndMoreThan10Voices() {
        val names = VoiceCatalog.voices.map { it.name }
        assertTrue("Expected > 10 voices, got ${names.size}", names.size > 10)
        assertTrue("Expected Ngọc Huyền in voice list", names.contains("Ngọc Huyền"))
        assertTrue("Expected Nam Minh in voice list", names.contains("Nam Minh"))
        assertTrue("Expected Hoài Tây in voice list", names.contains("Hoài Tây"))
        assertTrue("Expected Adam in voice list", names.contains("Adam"))
        assertEquals(names.size, names.distinct().size)
    }

    @Test
    fun defaultConfigUsesVietnameseUiFreeGoogleTranslateAndFreeBuiltinTts() {
        val state = EditorUiState()
        val cfg = ApiConfig()
        assertEquals(AppLanguage.VIETNAMESE, state.appLanguage)
        assertEquals(TranslationProvider.GOOGLE_TRANSLATE_FREE, cfg.translationProvider)
        assertFalse(cfg.translationProvider.requiresApiKey)
        assertEquals(TtsEngineMode.FREE_BUILTIN_TTS, cfg.ttsEngineMode)
        assertEquals("Nhập Video", stringsForLanguage(AppLanguage.VIETNAMESE).importVideo)
        assertEquals("Google Dịch", stringsForLanguage(AppLanguage.VIETNAMESE).translateAction)
    }

    @Test
    fun ocrPreprocessingCleansNoiseAndBrokenCjkSpacing() {
        val raw = "| 你 好\n世 界 ，今 天 天 气 真 好 ！ ~"
        val cleaned = TextSanitizer.cleanOcrTextForTranslation(raw)
        assertFalse(cleaned.contains("|"))
        assertFalse(cleaned.contains("~"))
        assertEquals("你好世界, 今天天气真好!", cleaned)
    }

    @Test
    fun contextualMarkerAndGoogleJsonParsingWorkAccurately() {
        val markerOutput = """
            [[1]] Xin chào thế giới
            [[2]] Hôm nay trời rất đẹp
        """.trimIndent()
        val map = GeminiTranslator.parseContextualMarkerOutput(markerOutput)
        assertEquals("Xin chào thế giới", map[1])
        assertEquals("Hôm nay trời rất đẹp", map[2])

        val gtxJson = """[[["Xin chào ", "你好", null, null, 1],["thế giới", "世界", null, null, 1]], null, "zh-CN"]"""
        assertEquals("Xin chào thế giới", GeminiTranslator.extractTextFromGoogleJson(gtxJson))
    }

    @Test
    fun srtImportAndExportRoundtripPreservesTimestampsAndText() {
        val rawSrt = """
            1
            00:00:01,250 --> 00:00:03,800
            Xin chào các bạn

            2
            00:00:04,000 --> 00:00:07,500
            Chào mừng đến với MatchaCut
        """.trimIndent()

        val imported = SrtUtils.parseSrtContent(rawSrt)
        assertEquals(2, imported.size)
        assertEquals(1250L, imported[0].startMs)
        assertEquals(3800L, imported[0].endMs)
        assertEquals("Xin chào các bạn", imported[0].originalText)
        assertEquals("Xin chào các bạn", imported[0].translatedText)

        val exported = SrtUtils.toSrtString(imported, useTranslated = true)
        assertTrue(exported.contains("00:00:01,250 --> 00:00:03,800"))
        assertTrue(exported.contains("Chào mừng đến với MatchaCut"))
    }

    @Test
    fun quotaAndTokenExhaustionErrorsAreDetectedExplicitly() {
        assertTrue(GeminiTranslator.isQuotaOrRateLimit(429, """{"error":{"status":"RESOURCE_EXHAUSTED"}}"""))
        assertTrue(GeminiTranslator.isQuotaOrRateLimit(402, """{"error":{"message":"Insufficient balance"}}"""))
        val msg = GeminiTranslator.formatApiErrorMessage(429, """{"error":{"message":"Quota exceeded"}}""", "OpenAI")
        assertTrue(msg.contains("Hết token") || msg.contains("429"))
    }

    @Test
    fun independentWorkflowAllowsImportedTargetSrtWhileBlockingRawChineseTts() {
        val importedVi = listOf(SrtSegment(1, 0L, 1500L, "Xin chào", translatedText = "Xin chào"))
        val stateWithVi = EditorUiState(segments = importedVi)
        assertTrue(stateWithVi.isVoiceoverUnlocked)
        assertTrue(TextSanitizer.validateSanitizedVoiceoverScript(importedVi) is SanitationResult.Valid)

        val rawChinese = listOf(SrtSegment(1, 0L, 1500L, "你好世界", translatedText = ""))
        assertTrue(TextSanitizer.validateSanitizedVoiceoverScript(rawChinese) is SanitationResult.Blocked)
    }
}
