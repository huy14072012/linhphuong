package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveTrack
import com.example.model.FilmstripFrame
import com.example.model.SrtSegment
import com.example.model.VideoMetadata
import com.example.ui.theme.MatchaGreenDark
import com.example.ui.theme.MatchaGreenDeep
import com.example.ui.theme.MatchaLightBg
import com.example.ui.theme.PeachPink
import com.example.ui.theme.PeachPinkSoft
import com.example.ui.theme.StudioBezel
import com.example.ui.theme.TimelineBg
import com.example.ui.theme.TimelineRuler
import com.example.util.LocalAppStrings
import com.example.util.SrtUtils
import kotlin.math.roundToInt

@Composable
fun MultiTrackTimeline(
    videoMetadata: VideoMetadata?,
    filmstrip: List<FilmstripFrame>,
    segments: List<SrtSegment>,
    selectedSegmentIndex: Int?,
    activeTrack: ActiveTrack,
    playbackPositionMs: Long,
    isVoiceoverUnlocked: Boolean,
    voiceoverVoiceName: String?,
    voiceoverWaveformPeaks: List<Float>,
    onSeek: (Long) -> Unit,
    onSelectTrack: (ActiveTrack) -> Unit,
    onSelectSegment: (SrtSegment) -> Unit,
    onLockedVoiceoverClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    val totalDurationMs = (videoMetadata?.durationMs ?: segments.maxOfOrNull { it.endMs } ?: 10_000L).coerceAtLeast(1000L)
    val playheadFraction = (playbackPositionMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)

    Surface(
        color = TimelineBg,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("multi_track_timeline")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.timelineHeader,
                    style = MaterialTheme.typography.labelSmall,
                    color = PeachPinkSoft,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${segments.size} SRT · ${voiceoverVoiceName ?: if (isVoiceoverUnlocked) strings.unlockedLabel else strings.lockedLabel}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MatchaLightBg.copy(alpha = 0.7f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            val latestDuration by rememberUpdatedState(totalDurationMs)
            val latestOnSeek by rememberUpdatedState(onSeek)

            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                val trackAreaWidthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
                val labelColWidth = 56.dp
                val labelColPx = with(LocalDensity.current) { labelColWidth.toPx() }
                val scrubWidthPx = (trackAreaWidthPx - labelColPx).coerceAtLeast(1f)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(videoMetadata?.uriString) {
                            detectTapGestures { offset ->
                                if (videoMetadata == null) return@detectTapGestures
                                val relX = (offset.x - labelColPx).coerceIn(0f, scrubWidthPx)
                                val targetMs = ((relX / scrubWidthPx) * latestDuration).toLong()
                                latestOnSeek(targetMs)
                            }
                        }
                        .pointerInput(videoMetadata?.uriString) {
                            detectDragGestures { change, _ ->
                                if (videoMetadata == null) return@detectDragGestures
                                change.consume()
                                val relX = (change.position.x - labelColPx).coerceIn(0f, scrubWidthPx)
                                val targetMs = ((relX / scrubWidthPx) * latestDuration).toLong()
                                latestOnSeek(targetMs)
                            }
                        }
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Spacer(modifier = Modifier.width(labelColWidth))
                        TimeRulerBar(durationMs = totalDurationMs, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TimelineTrackRow(
                        label = strings.trackVideo,
                        icon = Icons.Filled.Movie,
                        isActive = activeTrack == ActiveTrack.VIDEO,
                        onClick = { onSelectTrack(ActiveTrack.VIDEO) },
                        labelWidth = labelColWidth,
                        modifier = Modifier.testTag("track_video")
                    ) {
                        VideoFilmstripTrackContent(
                            videoMetadata = videoMetadata,
                            filmstrip = filmstrip,
                            isActive = activeTrack == ActiveTrack.VIDEO
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TimelineTrackRow(
                        label = strings.trackSrt,
                        icon = Icons.Filled.Subtitles,
                        isActive = activeTrack == ActiveTrack.SUBTITLE,
                        onClick = { onSelectTrack(ActiveTrack.SUBTITLE) },
                        labelWidth = labelColWidth,
                        modifier = Modifier.testTag("track_subtitle")
                    ) {
                        SubtitleTrackContent(
                            segments = segments,
                            totalDurationMs = totalDurationMs,
                            selectedSegmentIndex = selectedSegmentIndex,
                            isTrackActive = activeTrack == ActiveTrack.SUBTITLE,
                            onSelectSegment = onSelectSegment
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    TimelineTrackRow(
                        label = strings.trackVoice,
                        icon = if (isVoiceoverUnlocked) Icons.Filled.RecordVoiceOver else Icons.Filled.Lock,
                        isActive = activeTrack == ActiveTrack.VOICEOVER,
                        onClick = {
                            if (isVoiceoverUnlocked) onSelectTrack(ActiveTrack.VOICEOVER)
                            else onLockedVoiceoverClick()
                        },
                        labelWidth = labelColWidth,
                        modifier = Modifier.testTag("track_voiceover")
                    ) {
                        VoiceoverTrackContent(
                            isUnlocked = isVoiceoverUnlocked,
                            voiceName = voiceoverVoiceName,
                            waveformPeaks = voiceoverWaveformPeaks,
                            isTrackActive = activeTrack == ActiveTrack.VOICEOVER,
                            onLockedClick = onLockedVoiceoverClick
                        )
                    }
                }

                if (videoMetadata != null) {
                    val playheadOffsetPx = (labelColPx + (playheadFraction * scrubWidthPx)).roundToInt()
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(playheadOffsetPx - 6, 0) }
                            .width(12.dp)
                            .height(172.dp),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(PeachPink)
                        )
                        Box(
                            modifier = Modifier
                                .width(2.dp)
                                .fillMaxHeight()
                                .background(PeachPink)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TimeRulerBar(durationMs: Long, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .height(16.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(TimelineRuler.copy(alpha = 0.6f))
            .padding(horizontal = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val ticks = 5
        for (i in 0 until ticks) {
            val ms = (durationMs * i) / (ticks - 1)
            Text(
                text = SrtUtils.formatCompactTime(ms),
                style = MaterialTheme.typography.labelSmall,
                color = MatchaLightBg.copy(alpha = 0.72f),
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun TimelineTrackRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    onClick: () -> Unit,
    labelWidth: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            color = if (isActive) PeachPink else StudioBezel,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .width(labelWidth - 6.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onClick)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(horizontal = 2.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isActive) MatchaGreenDeep else MatchaLightBg,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isActive) MatchaGreenDeep else MatchaLightBg,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 9.sp
                )
            }
        }
        Spacer(modifier = Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            content()
        }
    }
}

@Composable
private fun VideoFilmstripTrackContent(
    videoMetadata: VideoMetadata?,
    filmstrip: List<FilmstripFrame>,
    isActive: Boolean
) {
    val strings = LocalAppStrings.current
    val borderColor = if (isActive) PeachPink else MatchaGreenDark.copy(alpha = 0.5f)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(8.dp))
            .background(StudioBezel)
            .border(1.5.dp, borderColor, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (videoMetadata == null) {
            Text(
                text = strings.videoTrackEmpty,
                style = MaterialTheme.typography.labelSmall,
                color = MatchaLightBg.copy(alpha = 0.45f)
            )
        } else if (filmstrip.isEmpty()) {
            Text(
                text = "${videoMetadata.displayName} (${videoMetadata.resolutionLabel})",
                style = MaterialTheme.typography.labelSmall,
                color = MatchaLightBg.copy(alpha = 0.85f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        } else {
            Row(modifier = Modifier.fillMaxSize()) {
                filmstrip.forEach { frame ->
                    if (!frame.bitmap.isRecycled) {
                        Image(
                            bitmap = frame.bitmap.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SubtitleTrackContent(
    segments: List<SrtSegment>,
    totalDurationMs: Long,
    selectedSegmentIndex: Int?,
    isTrackActive: Boolean,
    onSelectSegment: (SrtSegment) -> Unit
) {
    val strings = LocalAppStrings.current
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(8.dp))
            .background(StudioBezel)
            .border(
                1.2.dp,
                if (isTrackActive) PeachPink else TimelineRuler,
                RoundedCornerShape(8.dp)
            )
    ) {
        val trackW = maxWidth
        if (segments.isEmpty()) {
            Text(
                text = strings.srtTrackEmpty,
                style = MaterialTheme.typography.labelSmall,
                color = MatchaLightBg.copy(alpha = 0.48f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(horizontal = 10.dp)
            )
        } else {
            segments.forEach { seg ->
                val startFrac = (seg.startMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 0.96f)
                val endFrac = (seg.endMs.toFloat() / totalDurationMs.toFloat()).coerceIn(startFrac + 0.03f, 1f)
                val clipWidth = trackW * (endFrac - startFrac)
                val leftOffset = trackW * startFrac
                val isSelected = seg.index == selectedSegmentIndex || seg.translatedText.isNotBlank()

                Surface(
                    color = if (seg.index == selectedSegmentIndex) {
                        PeachPink
                    } else if (seg.translatedText.isNotBlank()) {
                        MatchaGreenDark
                    } else {
                        MatchaGreenDeep
                    },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .offset(x = leftOffset)
                        .width(clipWidth.coerceAtLeast(20.dp))
                        .fillMaxHeight()
                        .padding(vertical = 3.dp, horizontal = 1.dp)
                        .border(
                            1.dp,
                            if (isSelected) PeachPink else MatchaLightBg.copy(alpha = 0.25f),
                            RoundedCornerShape(6.dp)
                        )
                        .clickable { onSelectSegment(seg) }
                ) {
                    Box(
                        contentAlignment = Alignment.CenterStart,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Text(
                            text = "${seg.index}. ${seg.displayText}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (seg.index == selectedSegmentIndex) MatchaGreenDeep else Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun VoiceoverTrackContent(
    isUnlocked: Boolean,
    voiceName: String?,
    waveformPeaks: List<Float>,
    isTrackActive: Boolean,
    onLockedClick: () -> Unit
) {
    val strings = LocalAppStrings.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (!isUnlocked) {
                    Color(0xFF1A2219)
                } else if (voiceName != null) {
                    PeachPink.copy(alpha = 0.24f)
                } else {
                    StudioBezel
                }
            )
            .border(
                1.5.dp,
                when {
                    !isUnlocked -> TimelineRuler.copy(alpha = 0.6f)
                    isTrackActive || voiceName != null -> PeachPink
                    else -> MatchaGreenDark
                },
                RoundedCornerShape(8.dp)
            )
            .clickable(enabled = !isUnlocked, onClick = onLockedClick),
        contentAlignment = Alignment.CenterStart
    ) {
        when {
            !isUnlocked -> {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = strings.lockedLabel,
                        tint = PeachPink.copy(alpha = 0.75f),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = strings.voiceTrackLocked,
                        style = MaterialTheme.typography.labelSmall,
                        color = MatchaLightBg.copy(alpha = 0.55f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            voiceName == null -> {
                Text(
                    text = strings.voiceTrackReady,
                    style = MaterialTheme.typography.labelSmall,
                    color = PeachPinkSoft,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 10.dp)
                )
            }

            else -> {
                Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 6.dp)) {
                    val peaks = waveformPeaks.ifEmpty { List(48) { 0.4f } }
                    val barSpacing = size.width / peaks.size.toFloat()
                    val barW = (barSpacing * 0.55f).coerceAtLeast(2f)
                    val centerY = size.height / 2f
                    peaks.forEachIndexed { idx, amp ->
                        val barH = (amp * size.height * 0.88f).coerceAtLeast(4f)
                        val x = idx * barSpacing + (barSpacing - barW) / 2f
                        drawLine(
                            color = PeachPink,
                            start = Offset(x, centerY - barH / 2f),
                            end = Offset(x, centerY + barH / 2f),
                            strokeWidth = barW
                        )
                    }
                }
                Surface(
                    color = PeachPink,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.padding(start = 6.dp)
                ) {
                    Text(
                        text = voiceName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MatchaGreenDeep,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
