package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GTranslate
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.SourceLanguage
import com.example.model.TargetLanguage
import com.example.model.TranslationProvider
import com.example.model.WorkflowStep
import com.example.ui.theme.MatchaGreenDark
import com.example.ui.theme.MatchaGreenDeep
import com.example.ui.theme.MatchaMutedText
import com.example.ui.theme.MatchaOnDark
import com.example.ui.theme.MatchaOutline
import com.example.ui.theme.MatchaSurface
import com.example.ui.theme.MatchaSurfaceContainer
import com.example.ui.theme.PeachPink
import com.example.util.LocalAppStrings

@Composable
fun WorkflowToolbar(
    workflowStep: WorkflowStep,
    isBusy: Boolean,
    hasVideo: Boolean,
    hasSubtitles: Boolean,
    isVoiceoverUnlocked: Boolean,
    sourceLanguage: SourceLanguage,
    targetLanguage: TargetLanguage,
    translationProvider: TranslationProvider,
    onSelectSourceLanguage: (SourceLanguage) -> Unit,
    onSelectTargetLanguage: (TargetLanguage) -> Unit,
    onRunOcr: () -> Unit,
    onRunAudioSrt: () -> Unit,
    onImportSrt: () -> Unit,
    onOpenSrtEditor: () -> Unit,
    onTranslateGemini: () -> Unit,
    onOpenVoiceover: () -> Unit,
    modifier: Modifier = Modifier
) {
    val strings = LocalAppStrings.current
    var showSourceMenu by remember { mutableStateOf(false) }
    var showTargetMenu by remember { mutableStateOf(false) }

    Surface(
        color = MatchaSurface,
        tonalElevation = 1.dp,
        border = BorderStroke(1.dp, MatchaOutline.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box {
                    LanguageChip(
                        prefix = strings.ocrSrcPrefix,
                        label = sourceLanguage.displayName,
                        onClick = { showSourceMenu = true },
                        modifier = Modifier.testTag("source_language_chip")
                    )
                    DropdownMenu(
                        expanded = showSourceMenu,
                        onDismissRequest = { showSourceMenu = false }
                    ) {
                        SourceLanguage.entries.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text(lang.displayName) },
                                onClick = {
                                    onSelectSourceLanguage(lang)
                                    showSourceMenu = false
                                }
                            )
                        }
                    }
                }

                Box {
                    LanguageChip(
                        prefix = strings.targetPrefix,
                        label = targetLanguage.displayName,
                        onClick = { showTargetMenu = true },
                        modifier = Modifier.testTag("target_language_chip")
                    )
                    DropdownMenu(
                        expanded = showTargetMenu,
                        onDismissRequest = { showTargetMenu = false }
                    ) {
                        TargetLanguage.entries.forEach { lang ->
                            DropdownMenuItem(
                                text = { Text(lang.displayName) },
                                onClick = {
                                    onSelectTargetLanguage(lang)
                                    showTargetMenu = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ToolbarActionButton(
                    icon = Icons.Filled.DocumentScanner,
                    label = strings.ocrBoxAction,
                    sublabel = "Step 2A",
                    enabled = hasVideo && !isBusy,
                    isHighlighted = workflowStep == WorkflowStep.VIDEO_IMPORTED,
                    isLocked = false,
                    onClick = onRunOcr,
                    modifier = Modifier.testTag("extract_ocr_button")
                )

                ToolbarActionButton(
                    icon = Icons.Filled.GraphicEq,
                    label = strings.audioSrtAction,
                    sublabel = "Step 2B",
                    enabled = hasVideo && !isBusy,
                    isHighlighted = false,
                    isLocked = false,
                    onClick = onRunAudioSrt,
                    modifier = Modifier.testTag("extract_audio_srt_button")
                )

                ToolbarActionButton(
                    icon = Icons.Filled.FileOpen,
                    label = strings.importSrtAction,
                    sublabel = ".SRT",
                    enabled = !isBusy,
                    isHighlighted = false,
                    isLocked = false,
                    onClick = onImportSrt,
                    modifier = Modifier.testTag("import_srt_button")
                )

                ToolbarActionButton(
                    icon = Icons.Filled.EditNote,
                    label = strings.srtSaveAction,
                    sublabel = "SRT",
                    enabled = !isBusy,
                    isHighlighted = false,
                    isLocked = false,
                    onClick = onOpenSrtEditor,
                    modifier = Modifier.testTag("export_srt_button")
                )

                ToolbarActionButton(
                    icon = Icons.Filled.GTranslate,
                    label = strings.translateAction,
                    sublabel = if (!translationProvider.requiresApiKey) {
                        strings.translateSublabelFree
                    } else {
                        translationProvider.displayName
                    },
                    enabled = hasSubtitles && !isBusy,
                    isHighlighted = workflowStep == WorkflowStep.SUBTITLES_EXTRACTED,
                    isLocked = false,
                    onClick = onTranslateGemini,
                    modifier = Modifier.testTag("translate_gemini_button")
                )

                ToolbarActionButton(
                    icon = Icons.Filled.RecordVoiceOver,
                    label = strings.voiceoverAction,
                    sublabel = if (isVoiceoverUnlocked) strings.unlockedLabel else strings.lockedLabel,
                    enabled = hasSubtitles && !isBusy,
                    isHighlighted = workflowStep == WorkflowStep.TRANSLATED,
                    isLocked = false,
                    onClick = onOpenVoiceover,
                    modifier = Modifier.testTag("voiceover_button")
                )
            }
        }
    }
}

@Composable
private fun LanguageChip(
    prefix: String,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        color = MatchaSurfaceContainer,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Language,
                contentDescription = null,
                tint = MatchaGreenDark,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$prefix ",
                style = MaterialTheme.typography.labelMedium,
                color = MatchaMutedText
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MatchaGreenDeep,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ToolbarActionButton(
    icon: ImageVector,
    label: String,
    sublabel: String,
    enabled: Boolean,
    isHighlighted: Boolean,
    isLocked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val containerColor = when {
        isLocked -> MatchaSurfaceContainer.copy(alpha = 0.65f)
        isHighlighted -> PeachPink
        enabled -> MatchaGreenDark
        else -> MatchaSurfaceContainer.copy(alpha = 0.5f)
    }
    val contentColor = when {
        isLocked -> MatchaMutedText
        isHighlighted -> MatchaGreenDeep
        enabled -> MatchaOnDark
        else -> MatchaMutedText.copy(alpha = 0.55f)
    }

    Surface(
        onClick = onClick,
        enabled = enabled,
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(12.dp),
        border = if (isLocked) BorderStroke(1.dp, MatchaOutline) else null,
        modifier = modifier.minimumInteractiveComponentSize()
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = contentColor,
                modifier = Modifier.size(19.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = contentColor,
                maxLines = 1
            )
            Text(
                text = sublabel,
                style = MaterialTheme.typography.labelSmall,
                color = contentColor.copy(alpha = 0.8f),
                maxLines = 1
            )
        }
    }
}
