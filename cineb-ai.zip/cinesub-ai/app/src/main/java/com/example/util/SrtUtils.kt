package com.example.util

import com.example.model.SrtSegment
import java.util.Locale

object SrtUtils {

    private val fullTimestampRegex = Regex(
        """(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})"""
    )

    private val shortTimestampRegex = Regex(
        """(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2})[,.](\d{1,3})"""
    )

    fun formatSrtTimestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val hours = safe / 3_600_000L
        val minutes = (safe % 3_600_000L) / 60_000L
        val seconds = (safe % 60_000L) / 1_000L
        val millis = safe % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    fun formatCompactTime(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val totalSeconds = safe / 1_000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        val tenths = (safe % 1_000L) / 100L
        return String.format(Locale.US, "%02d:%02d.%d", minutes, seconds, tenths)
    }

    fun toSrtString(segments: List<SrtSegment>, useTranslated: Boolean): String {
        return buildString {
            segments.forEachIndexed { idx, seg ->
                val text = if (useTranslated) {
                    seg.translatedText.ifBlank { seg.originalText }
                } else {
                    seg.originalText
                }.trim()
                append(seg.index.takeIf { it > 0 } ?: (idx + 1))
                append('\n')
                append(formatSrtTimestamp(seg.startMs))
                append(" --> ")
                append(formatSrtTimestamp(seg.endMs))
                append('\n')
                append(text)
                append("\n\n")
            }
        }.trimEnd() + "\n"
    }

    /**
     * Parses an imported .srt file (UTF-8 with optional BOM, CRLF/LF, comma or dot ms)
     * into clean sequential SrtSegment items.
     */
    fun parseSrtContent(rawContent: String): List<SrtSegment> {
        val normalized = rawContent
            .removePrefix("\uFEFF")
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .trim()
        if (normalized.isEmpty()) return emptyList()

        val blocks = normalized.split(Regex("""\n\s*\n+""")).filter { it.isNotBlank() }
        val results = mutableListOf<SrtSegment>()

        for (block in blocks) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) continue

            val tsIdx = lines.indexOfFirst {
                fullTimestampRegex.containsMatchIn(it) || shortTimestampRegex.containsMatchIn(it)
            }
            if (tsIdx < 0) continue

            val tsRange = parseTimestampLine(lines[tsIdx]) ?: continue
            val text = lines.drop(tsIdx + 1)
                .joinToString("\n")
                .replace(Regex("""<[^>]+>"""), "")
                .trim()
            if (text.isBlank()) continue

            val hasCjk = TextSanitizer.containsChineseCharacters(text)
            results.add(
                SrtSegment(
                    index = results.size + 1,
                    startMs = tsRange.first,
                    endMs = tsRange.second.coerceAtLeast(tsRange.first + 200L),
                    originalText = text,
                    translatedText = if (hasCjk) "" else text
                )
            )
        }

        return results
    }

    private fun parseTimestampLine(line: String): Pair<Long, Long>? {
        fullTimestampRegex.find(line)?.let { m ->
            val sh = m.groupValues[1].toLong()
            val sm = m.groupValues[2].toLong()
            val ss = m.groupValues[3].toLong()
            val sms = m.groupValues[4].padEnd(3, '0').take(3).toLong()

            val eh = m.groupValues[5].toLong()
            val em = m.groupValues[6].toLong()
            val es = m.groupValues[7].toLong()
            val ems = m.groupValues[8].padEnd(3, '0').take(3).toLong()

            val startMs = ((sh * 3600L) + (sm * 60L) + ss) * 1000L + sms
            val endMs = ((eh * 3600L) + (em * 60L) + es) * 1000L + ems
            return startMs to endMs
        }
        shortTimestampRegex.find(line)?.let { m ->
            val sm = m.groupValues[1].toLong()
            val ss = m.groupValues[2].toLong()
            val sms = m.groupValues[3].padEnd(3, '0').take(3).toLong()

            val em = m.groupValues[4].toLong()
            val es = m.groupValues[5].toLong()
            val ems = m.groupValues[6].padEnd(3, '0').take(3).toLong()

            val startMs = ((sm * 60L) + ss) * 1000L + sms
            val endMs = ((em * 60L) + es) * 1000L + ems
            return startMs to endMs
        }
        return null
    }

    /**
     * Parses a returned SRT string while strictly preserving original indices and timestamps.
     */
    fun parseTranslatedSrtPreservingTiming(
        rawResponse: String,
        originalSegments: List<SrtSegment>
    ): List<SrtSegment> {
        val cleaned = rawResponse
            .replace(Regex("""^```(?:srt|plaintext|text)?\s*""", RegexOption.MULTILINE), "")
            .replace(Regex("""```\s*$""", RegexOption.MULTILINE), "")
            .trim()

        val blocks = cleaned.split(Regex("""\r?\n\s*\r?\n""")).filter { it.isNotBlank() }
        val parsedByIndex = mutableMapOf<Int, String>()
        val sequentialTexts = mutableListOf<String>()

        for (block in blocks) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) continue

            val tsLineIdx = lines.indexOfFirst { fullTimestampRegex.containsMatchIn(it) }
            if (tsLineIdx >= 0) {
                val parsedIndex = if (tsLineIdx > 0) {
                    lines[tsLineIdx - 1].trim().toIntOrNull()
                } else {
                    null
                }
                val textLines = lines.drop(tsLineIdx + 1)
                val joined = textLines.joinToString("\n").trim()
                if (joined.isNotBlank()) {
                    sequentialTexts.add(joined)
                    if (parsedIndex != null) {
                        parsedByIndex[parsedIndex] = joined
                    }
                }
            }
        }

        return originalSegments.mapIndexed { pos, original ->
            val translated = parsedByIndex[original.index]
                ?: sequentialTexts.getOrNull(pos)
                ?: ""
            original.copy(translatedText = translated.trim())
        }
    }
}
