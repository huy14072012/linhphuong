package com.example.network

import com.example.model.ApiConfig
import com.example.model.SourceLanguage
import com.example.model.SrtSegment
import com.example.model.TargetLanguage
import com.example.model.TranslationProvider
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

sealed interface TranslationResult {
    data class Success(val translatedSegments: List<SrtSegment>) : TranslationResult
    data class Error(
        val message: String,
        val isTokenOrQuotaError: Boolean = false,
        val partialSegments: List<SrtSegment> = emptyList(),
        val translatedCount: Int = 0
    ) : TranslationResult
}

object GeminiTranslator {

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    private val googleTranslateEndpoints = listOf(
        "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t",
        "https://clients5.google.com/translate_a/single?client=dict-chrome-ex&dt=t"
    )

    private val indexedMarkerRegex = Regex(
        """(?:^|\n)\s*(?:\[\[|\[|【|⟦|<)?\s*(\d{1,5})\s*(?:\]\]|\]|】|⟧|>)\s*[:：\-]?\s*"""
    )

    suspend fun translateSrt(
        apiConfig: ApiConfig,
        segments: List<SrtSegment>,
        targetLanguage: TargetLanguage,
        sourceLanguage: SourceLanguage = SourceLanguage.CHINESE,
        onlyUntranslated: Boolean = false,
        onBatchProgress: (Float, String) -> Unit = { _, _ -> },
        onPartialTranslated: (List<SrtSegment>) -> Unit = {}
    ): TranslationResult = withContext(Dispatchers.IO) {
        if (segments.isEmpty()) {
            return@withContext TranslationResult.Error("Chưa có phụ đề nào để dịch.")
        }

        // Default to free Google Translate whenever provider is GOOGLE_TRANSLATE_FREE
        // or when user hasn't entered a paid API key
        val effectiveProvider = if (!apiConfig.translationProvider.requiresApiKey ||
            apiConfig.geminiApiKey.isBlank()
        ) {
            TranslationProvider.GOOGLE_TRANSLATE_FREE
        } else {
            apiConfig.translationProvider
        }

        val workingList = segments.toMutableList()
        val targetIndices = if (onlyUntranslated) {
            workingList.indices.filter { workingList[it].translatedText.isBlank() }
        } else {
            workingList.indices.toList()
        }

        if (targetIndices.isEmpty()) {
            onBatchProgress(1f, "Tất cả ${workingList.size} dòng đã được dịch")
            return@withContext TranslationResult.Success(workingList)
        }

        val batchSize = apiConfig.translationBatchSize.coerceIn(1, 10)
        val delayMs = apiConfig.translationDelayMs.coerceIn(250L, 5000L)
        val indexBatches = targetIndices.chunked(batchSize)
        var completedInRun = 0

        for ((batchIdx, posBatch) in indexBatches.withIndex()) {
            val batchSegments = posBatch.map { workingList[it] }
            val fromIdx = batchSegments.first().index
            val toIdx = batchSegments.last().index

            onBatchProgress(
                batchIdx.toFloat() / indexBatches.size.toFloat(),
                "Đang dịch lô ${batchIdx + 1}/${indexBatches.size} (dòng #$fromIdx–#$toIdx) · ${effectiveProvider.displayName}"
            )

            var attemptResult = executeBatchWithRetry(
                effectiveProvider = effectiveProvider,
                apiConfig = apiConfig,
                batch = batchSegments,
                sourceLanguage = sourceLanguage,
                targetLanguage = targetLanguage,
                onRetryWait = { waitLabel ->
                    onBatchProgress(batchIdx.toFloat() / indexBatches.size.toFloat(), waitLabel)
                }
            )

            when (attemptResult) {
                is TranslationResult.Success -> {
                    posBatch.forEachIndexed { localIdx, listPos ->
                        val translatedSeg = attemptResult.translatedSegments[localIdx]
                        workingList[listPos] = translatedSeg
                    }
                    completedInRun += posBatch.size
                    onPartialTranslated(workingList.toList())
                }

                is TranslationResult.Error -> {
                    val savedCount = workingList.count { it.translatedText.isNotBlank() }
                    val preservedMsg = buildString {
                        append(attemptResult.message)
                        if (savedCount > 0) {
                            append("\n\nĐã tự động giữ lại $savedCount/${workingList.size} dòng đã dịch thành công (không bị mất tiến độ).")
                        }
                    }
                    return@withContext TranslationResult.Error(
                        message = preservedMsg,
                        isTokenOrQuotaError = attemptResult.isTokenOrQuotaError,
                        partialSegments = workingList.toList(),
                        translatedCount = savedCount
                    )
                }
            }

            if (batchIdx < indexBatches.lastIndex) {
                onBatchProgress(
                    (batchIdx + 1).toFloat() / indexBatches.size.toFloat(),
                    "Đã dịch $completedInRun/${targetIndices.size} dòng · Đang chuyển lô tiếp theo..."
                )
                delay(delayMs)
            }
        }

        onBatchProgress(1f, "Dịch hoàn tất ${workingList.size} dòng")
        TranslationResult.Success(workingList.toList())
    }

    private suspend fun executeBatchWithRetry(
        effectiveProvider: TranslationProvider,
        apiConfig: ApiConfig,
        batch: List<SrtSegment>,
        sourceLanguage: SourceLanguage,
        targetLanguage: TargetLanguage,
        onRetryWait: (String) -> Unit
    ): TranslationResult {
        val retryDelays = listOf(900L, 1800L)
        var lastError: TranslationResult.Error? = null

        for (attempt in 0..retryDelays.size) {
            val result = if (effectiveProvider == TranslationProvider.GOOGLE_TRANSLATE_FREE) {
                translateBatchWithGoogleFree(batch, sourceLanguage, targetLanguage)
            } else {
                executeAiSingleBatch(apiConfig, batch, targetLanguage)
            }

            if (result is TranslationResult.Success) {
                return result
            }

            lastError = result as TranslationResult.Error
            val canRetry = attempt < retryDelays.size
            if (canRetry) {
                val waitMs = retryDelays[attempt]
                onRetryWait("Mạng chập chờn · Tự động thử lại (${attempt + 1}/${retryDelays.size}) sau ${waitMs}ms...")
                delay(waitMs)
            }
        }

        return lastError ?: TranslationResult.Error("Dịch thất bại không rõ nguyên nhân.")
    }

    /**
     * Free Google Translate batch translation with:
     * 1) OCR pre-processing (noise removal, CJK spacing fix, broken line join)
     * 2) Contextual block translation via numbered markers `[[id]]` so surrounding lines give full sentence context
     * 3) Smart fallback to single-cue translation if Google alters/merges a marker
     */
    private fun translateBatchWithGoogleFree(
        batch: List<SrtSegment>,
        sourceLanguage: SourceLanguage,
        targetLanguage: TargetLanguage
    ): TranslationResult {
        return try {
            val preprocessed = batch.map { seg ->
                val cleanedSource = TextSanitizer.cleanOcrTextForTranslation(seg.originalText)
                    .ifBlank { seg.originalText.trim() }
                seg to cleanedSource
            }

            if (preprocessed.size == 1) {
                val (seg, cleanSrc) = preprocessed.first()
                val translated = callGoogleTranslateRaw(
                    text = cleanSrc,
                    sourceLangCode = googleSourceLangCode(sourceLanguage, cleanSrc),
                    targetLangCode = targetLanguage.code
                )
                val finalOut = postProcessTranslated(translated, targetLanguage)
                return TranslationResult.Success(listOf(seg.copy(translatedText = finalOut)))
            }

            // Contextual multi-line block with unambiguous [[index]] markers
            val contextualPayload = preprocessed.joinToString("\n") { (seg, cleanSrc) ->
                "[[${seg.index}]] $cleanSrc"
            }

            val firstClean = preprocessed.joinToString(" ") { it.second }
            val sl = googleSourceLangCode(sourceLanguage, firstClean)
            val rawBatchTranslation = callGoogleTranslateRaw(
                text = contextualPayload,
                sourceLangCode = sl,
                targetLangCode = targetLanguage.code
            )

            val parsedByMarker = parseContextualMarkerOutput(rawBatchTranslation)

            val finalSegments = preprocessed.map { (seg, cleanSrc) ->
                val matched = parsedByMarker[seg.index]
                val resolved = if (!matched.isNullOrBlank()) {
                    matched
                } else {
                    // Fallback per-cue when a marker wasn't preserved verbatim
                    callGoogleTranslateRaw(
                        text = cleanSrc,
                        sourceLangCode = googleSourceLangCode(sourceLanguage, cleanSrc),
                        targetLangCode = targetLanguage.code
                    )
                }
                seg.copy(translatedText = postProcessTranslated(resolved, targetLanguage))
            }

            TranslationResult.Success(finalSegments)
        } catch (apiEx: ApiQuotaOrTokenException) {
            TranslationResult.Error(apiEx.message ?: "Giới hạn truy cập Google Dịch.", isTokenOrQuotaError = true)
        } catch (ioEx: IOException) {
            TranslationResult.Error("Lỗi kết nối mạng khi gọi Google Dịch: ${ioEx.message ?: "Kiểm tra Wi-Fi/4G"}")
        } catch (t: Throwable) {
            TranslationResult.Error(t.message ?: "Lỗi Google Dịch không xác định.")
        }
    }

    fun parseContextualMarkerOutput(rawOutput: String): Map<Int, String> {
        val normalized = rawOutput.replace("\r\n", "\n").trim()
        if (normalized.isEmpty()) return emptyMap()

        val matches = indexedMarkerRegex.findAll(normalized).toList()
        if (matches.isEmpty()) return emptyMap()

        val map = mutableMapOf<Int, String>()
        for (i in matches.indices) {
            val current = matches[i]
            val id = current.groupValues[1].toIntOrNull() ?: continue
            val contentStart = current.range.last + 1
            val contentEnd = if (i + 1 < matches.size) matches[i + 1].range.first else normalized.length
            if (contentStart <= contentEnd) {
                val slice = normalized.substring(contentStart, contentEnd).trim()
                if (slice.isNotBlank()) {
                    map[id] = slice
                }
            }
        }
        return map
    }

    private fun googleSourceLangCode(configuredSource: SourceLanguage, text: String): String {
        return when {
            TextSanitizer.containsChineseCharacters(text) -> "zh-CN"
            configuredSource == SourceLanguage.CHINESE -> "auto"
            else -> configuredSource.code
        }
    }

    private fun postProcessTranslated(raw: String, targetLanguage: TargetLanguage): String {
        val cleaned = TextSanitizer.cleanTranslatedSubtitleText(raw)
        return if (targetLanguage.code != "zh") {
            TextSanitizer.sanitizeForVoiceover(cleaned).ifBlank { cleaned }
        } else {
            cleaned
        }
    }

    private fun callGoogleTranslateRaw(
        text: String,
        sourceLangCode: String,
        targetLangCode: String
    ): String {
        if (text.isBlank()) return ""
        var lastError: Throwable? = null

        for (endpoint in googleTranslateEndpoints) {
            try {
                val formBody = FormBody.Builder()
                    .add("sl", sourceLangCode)
                    .add("tl", targetLangCode)
                    .add("q", text)
                    .build()

                val request = Request.Builder()
                    .url(endpoint)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36")
                    .post(formBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    val rawBody = response.body?.string().orEmpty()
                    if (response.code == 429) {
                        throw ApiQuotaOrTokenException(
                            "Google Dịch tạm giới hạn tốc độ (HTTP 429). Vui lòng chờ vài giây rồi thử tiếp."
                        )
                    }
                    if (!response.isSuccessful) {
                        throw IllegalStateException("Google Dịch lỗi HTTP ${response.code}")
                    }
                    val translated = extractTextFromGoogleJson(rawBody)
                    if (translated.isNotBlank()) {
                        return translated
                    }
                    throw IllegalStateException("Google Dịch trả về phản hồi rỗng.")
                }
            } catch (apiEx: ApiQuotaOrTokenException) {
                lastError = apiEx
            } catch (t: Throwable) {
                lastError = t
            }
        }

        throw lastError ?: IllegalStateException("Không thể kết nối tới Google Dịch.")
    }

    private val moshi = Moshi.Builder().build()
    private val listAdapter = moshi.adapter(List::class.java)

    fun extractTextFromGoogleJson(rawJson: String): String {
        val trimmed = rawJson.trim()
        if (trimmed.isEmpty()) return ""
        val root = listAdapter.fromJson(trimmed) ?: return ""
        val sentences = root.firstOrNull() as? List<*> ?: return ""
        return buildString {
            for (entry in sentences) {
                val pair = entry as? List<*> ?: continue
                val part = pair.firstOrNull() as? String ?: continue
                append(part)
            }
        }.trim()
    }

    private fun executeAiSingleBatch(
        apiConfig: ApiConfig,
        batch: List<SrtSegment>,
        targetLanguage: TargetLanguage
    ): TranslationResult {
        val cleanedBatch = batch.map { seg ->
            seg.copy(
                originalText = TextSanitizer.cleanOcrTextForTranslation(seg.originalText)
                    .ifBlank { seg.originalText }
            )
        }
        val inputSrt = SrtUtils.toSrtString(cleanedBatch, useTranslated = false)
        val systemInstruction = """
            You are an expert audiovisual subtitle translator.
            Translate the following SRT subtitle block(s) into ${targetLanguage.displayName}.
            STRICT RULES:
            1. Preserve every subtitle index number and every timestamp line (HH:MM:SS,mmm --> HH:MM:SS,mmm) EXACTLY as given.
            2. Do NOT merge, split, add, or drop any subtitle block.
            3. Output ONLY valid SRT format. No markdown code fences, no explanations, no intro/outro text.
            4. Translate 100% of the dialogue naturally and concisely for spoken voiceover in ${targetLanguage.displayName}. Leave ZERO Chinese characters or untranslated source words in the output.
        """.trimIndent()

        return try {
            val rawText = if (apiConfig.translationProvider == TranslationProvider.GEMINI) {
                callGeminiEndpoint(apiConfig, systemInstruction, inputSrt)
            } else {
                callOpenAiCompatibleEndpoint(apiConfig, systemInstruction, inputSrt)
            }

            val parsed = SrtUtils.parseTranslatedSrtPreservingTiming(rawText, batch)
            val emptyCount = parsed.count { it.translatedText.isBlank() }
            if (emptyCount == parsed.size) {
                return TranslationResult.Error(
                    "Không đọc được định dạng SRT từ ${apiConfig.translationProvider.displayName}."
                )
            }

            val cleaned = parsed.map { seg ->
                val stripped = postProcessTranslated(seg.translatedText, targetLanguage)
                seg.copy(translatedText = stripped.ifBlank { seg.translatedText.trim() })
            }

            TranslationResult.Success(cleaned)
        } catch (apiEx: ApiQuotaOrTokenException) {
            TranslationResult.Error(apiEx.message ?: "Hết token / giới hạn API.", isTokenOrQuotaError = true)
        } catch (t: Throwable) {
            TranslationResult.Error(
                t.message ?: "Lỗi mạng khi gọi ${apiConfig.translationProvider.displayName}."
            )
        }
    }

    private fun callGeminiEndpoint(
        apiConfig: ApiConfig,
        systemInstruction: String,
        inputSrt: String
    ): String {
        val baseUrl = apiConfig.translationEndpointUrl.trim()
            .ifBlank { TranslationProvider.GEMINI.defaultEndpoint }
            .trimEnd('/')
        val model = apiConfig.geminiModel.trim().ifBlank { TranslationProvider.GEMINI.defaultModel }
        val url = if (baseUrl.contains(":generateContent")) {
            "$baseUrl?key=${apiConfig.geminiApiKey.trim()}"
        } else {
            "$baseUrl/models/$model:generateContent?key=${apiConfig.geminiApiKey.trim()}"
        }

        val requestJson = JSONObject().apply {
            put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
            )
            put(
                "contents",
                JSONArray().put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", inputSrt)))
                )
            )
            put("generationConfig", JSONObject().put("temperature", 0.2))
        }

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val formatted = formatApiErrorMessage(response.code, rawBody, "Google Gemini")
                if (isQuotaOrRateLimit(response.code, rawBody)) {
                    throw ApiQuotaOrTokenException(formatted)
                }
                throw IllegalStateException(formatted)
            }

            val root = JSONObject(rawBody)
            val candidate = root.optJSONArray("candidates")?.optJSONObject(0)
            val finishReason = candidate?.optString("finishReason").orEmpty()
            if (finishReason == "MAX_TOKENS") {
                throw ApiQuotaOrTokenException(
                    "Đạt giới hạn token đầu ra (MAX_TOKENS) của Gemini. Hãy giảm 'Số dòng mỗi lô' xuống 1–2 dòng."
                )
            }

            val text = candidate
                ?.optJSONObject("content")
                ?.optJSONArray("parts")
                ?.optJSONObject(0)
                ?.optString("text")
                .orEmpty()

            if (text.isBlank()) {
                throw IllegalStateException("Gemini trả về phản hồi rỗng.")
            }
            return text
        }
    }

    private fun callOpenAiCompatibleEndpoint(
        apiConfig: ApiConfig,
        systemInstruction: String,
        inputSrt: String
    ): String {
        val provider = apiConfig.translationProvider
        val endpoint = apiConfig.translationEndpointUrl.trim().ifBlank { provider.defaultEndpoint }
        val model = apiConfig.geminiModel.trim().ifBlank { provider.defaultModel }

        val requestJson = JSONObject().apply {
            put("model", model)
            put("temperature", 0.2)
            put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", systemInstruction))
                    .put(JSONObject().put("role", "user").put("content", inputSrt))
            )
        }

        val request = Request.Builder()
            .url(endpoint)
            .header("Authorization", "Bearer ${apiConfig.geminiApiKey.trim()}")
            .header("Content-Type", "application/json")
            .post(requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val rawBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val formatted = formatApiErrorMessage(response.code, rawBody, provider.displayName)
                if (isQuotaOrRateLimit(response.code, rawBody)) {
                    throw ApiQuotaOrTokenException(formatted)
                }
                throw IllegalStateException(formatted)
            }

            val root = JSONObject(rawBody)
            val choice = root.optJSONArray("choices")?.optJSONObject(0)
            val finishReason = choice?.optString("finish_reason").orEmpty()
            if (finishReason == "length") {
                throw ApiQuotaOrTokenException(
                    "Đạt giới hạn token đầu ra (finish_reason: length) của ${provider.displayName}. Hãy giảm 'Số dòng mỗi lô'."
                )
            }

            val text = choice
                ?.optJSONObject("message")
                ?.optString("content")
                .orEmpty()

            if (text.isBlank()) {
                throw IllegalStateException("${provider.displayName} trả về phản hồi rỗng.")
            }
            return text
        }
    }

    private class ApiQuotaOrTokenException(message: String) : Exception(message)

    fun isQuotaOrRateLimit(httpCode: Int, rawBody: String): Boolean {
        if (httpCode == 429 || httpCode == 402) return true
        val lower = rawBody.lowercase(Locale.US)
        return lower.contains("insufficient_quota") ||
            lower.contains("resource_exhausted") ||
            lower.contains("rate_limit") ||
            lower.contains("quota") ||
            lower.contains("token") && lower.contains("limit") ||
            lower.contains("insufficient balance") ||
            lower.contains("credit")
    }

    fun formatApiErrorMessage(httpCode: Int, rawBody: String, providerName: String): String {
        val parsedMsg = runCatching {
            val json = JSONObject(rawBody)
            json.optJSONObject("error")?.optString("message")
                ?.takeIf { it.isNotBlank() }
                ?: json.optString("message").takeIf { it.isNotBlank() }
        }.getOrNull().orEmpty()

        val lower = (rawBody + " " + parsedMsg).lowercase(Locale.US)
        return when {
            httpCode == 402 || lower.contains("insufficient_quota") || lower.contains("insufficient balance") || lower.contains("credit") ->
                "Hết token / hết số dư tài khoản $providerName (HTTP $httpCode).\nChi tiết: ${parsedMsg.ifBlank { "Quota / credit exhausted." }}"
            httpCode == 429 || lower.contains("resource_exhausted") || lower.contains("rate_limit") || lower.contains("quota") ->
                "Hết token miễn phí hoặc chạm giới hạn tốc độ $providerName (HTTP 429).\nHãy tăng 'Giãn cách giữa các lô (ms)' hoặc chuyển sang Google Dịch (Miễn phí).\nChi tiết: ${parsedMsg.ifBlank { "Rate limit / quota exceeded." }}"
            httpCode == 401 || httpCode == 403 ->
                "API Key $providerName không hợp lệ hoặc bị từ chối quyền (HTTP $httpCode).\nChi tiết: ${parsedMsg.ifBlank { "Unauthorized" }}"
            lower.contains("context_length") || lower.contains("max_tokens") ->
                "Vượt quá giới hạn token ngữ cảnh của $providerName.\nChi tiết: $parsedMsg"
            else ->
                "$providerName lỗi (HTTP $httpCode): ${parsedMsg.ifBlank { rawBody.take(200) }}"
        }
    }
}
