package com.example.util

import com.example.model.SrtSegment
import java.util.Locale

object SrtUtils {

    private val fullTimestampRegex = Regex(
        """(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})"""
    )

    private val shortTimestampRegex = Regex(
        """(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2})[,.](\d{1,3})"""
    )

    fun formatSrtTimestamp(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val hours = safe / 3_600_000L
        val minutes = (safe % 3_600_000L) / 60_000L
        val seconds = (safe % 60_000L) / 1_000L
        val millis = safe % 1_000L
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    fun formatCompactTime(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        val totalSeconds = safe / 1_000L
        val minutes = totalSeconds / 60L
        val seconds = totalSeconds % 60L
        val tenths = (safe % 1_000L) / 100L
        return String.format(Locale.US, "%02d:%02d.%d", minutes, seconds, tenths)
    }

    fun toSrtString(segments: List<SrtSegment>, useTranslated: Boolean): String {
        val sorted = segments.sortedBy { it.startMs }
        return buildString {
            sorted.forEachIndexed { idx, seg ->
                val text = if (useTranslated) {
                    seg.translatedText.ifBlank { seg.originalText }
                } else {
                    seg.originalText
                }.replace("\r\n", "\n").trim().replace("\n", "\r\n")
                append(idx + 1)
                append("\r\n")
                append(formatSrtTimestamp(seg.startMs))
                append(" --> ")
                append(formatSrtTimestamp(seg.endMs))
                append("\r\n")
                append(text)
                append("\r\n\r\n")
            }
        }.trimEnd() + "\r\n"
    }

    fun decodeSrtBytes(bytes: ByteArray): String {
        if (bytes.isEmpty()) return ""
        return when {
            bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte() ->
                String(bytes, Charsets.UTF_16LE)
            bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte() ->
                String(bytes, Charsets.UTF_16BE)
            bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte() ->
                String(bytes, 3, bytes.size - 3, Charsets.UTF_8)
            else -> String(bytes, Charsets.UTF_8)
        }
    }

    fun parseSrtTimestampSingle(raw: String): Long? {
        val m = Regex("""^\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*$""").find(raw)
        if (m != null) {
            val h = m.groupValues[1].toLong()
            val min = m.groupValues[2].toLong()
            val s = m.groupValues[3].toLong()
            val ms = m.groupValues[4].padEnd(3, '0').take(3).toLong()
            return ((h * 3600L) + (min * 60L) + s) * 1000L + ms
        }
        val shortM = Regex("""^\s*(\d{1,2}):(\d{2})[,.](\d{1,3})\s*$""").find(raw) ?: return null
        val min = shortM.groupValues[1].toLong()
        val s = shortM.groupValues[2].toLong()
        val ms = shortM.groupValues[3].padEnd(3, '0').take(3).toLong()
        return ((min * 60L) + s) * 1000L + ms
    }

    /**
     * Parses an imported .srt file (UTF-8 / UTF-16 with optional BOM, CRLF/LF, comma or dot ms)
     * into clean sequential SrtSegment items sorted chronologically.
     */
    fun parseSrtContent(rawContent: String): List<SrtSegment> {
        val normalized = rawContent
            .removePrefix("\uFEFF")
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .trim()
        if (normalized.isEmpty()) return emptyList()

        val blocks = normalized.split(Regex("""\n\s*\n+""")).filter { it.isNotBlank() }
        val results = mutableListOf<SrtSegment>()

        for (block in blocks) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) continue

            val tsIdx = lines.indexOfFirst {
                fullTimestampRegex.containsMatchIn(it) || shortTimestampRegex.containsMatchIn(it)
            }
            if (tsIdx < 0) continue

            val tsRange = parseTimestampLine(lines[tsIdx]) ?: continue
            val text = lines.drop(tsIdx + 1)
                .joinToString("\n")
                .replace(Regex("""<[^>]+>"""), "")
                .trim()
            if (text.isBlank()) continue

            val hasCjk = TextSanitizer.containsChineseCharacters(text)
            results.add(
                SrtSegment(
                    index = results.size + 1,
                    startMs = tsRange.first,
                    endMs = tsRange.second.coerceAtLeast(tsRange.first + 200L),
                    originalText = text,
                    translatedText = if (hasCjk) "" else text
                )
            )
        }

        return results
            .sortedBy { it.startMs }
            .mapIndexed { idx, seg -> seg.copy(index = idx + 1) }
    }

    private fun parseTimestampLine(line: String): Pair<Long, Long>? {
        fullTimestampRegex.find(line)?.let { m ->
            val sh = m.groupValues[1].toLong()
            val sm = m.groupValues[2].toLong()
            val ss = m.groupValues[3].toLong()
            val sms = m.groupValues[4].padEnd(3, '0').take(3).toLong()

            val eh = m.groupValues[5].toLong()
            val em = m.groupValues[6].toLong()
            val es = m.groupValues[7].toLong()
            val ems = m.groupValues[8].padEnd(3, '0').take(3).toLong()

            val startMs = ((sh * 3600L) + (sm * 60L) + ss) * 1000L + sms
            val endMs = ((eh * 3600L) + (em * 60L) + es) * 1000L + ems
            return startMs to endMs
        }
        shortTimestampRegex.find(line)?.let { m ->
            val sm = m.groupValues[1].toLong()
            val ss = m.groupValues[2].toLong()
            val sms = m.groupValues[3].padEnd(3, '0').take(3).toLong()

            val em = m.groupValues[4].toLong()
            val es = m.groupValues[5].toLong()
            val ems = m.groupValues[6].padEnd(3, '0').take(3).toLong()

            val startMs = ((sm * 60L) + ss) * 1000L + sms
            val endMs = ((em * 60L) + es) * 1000L + ems
            return startMs to endMs
        }
        return null
    }

    /**
     * Parses a returned SRT string while strictly preserving original indices and timestamps.
     */
    fun parseTranslatedSrtPreservingTiming(
        rawResponse: String,
        originalSegments: List<SrtSegment>
    ): List<SrtSegment> {
        val cleaned = rawResponse
            .replace(Regex("""^```(?:srt|plaintext|text)?\s*""", RegexOption.MULTILINE), "")
            .replace(Regex("""```\s*$""", RegexOption.MULTILINE), "")
            .trim()

        val blocks = cleaned.split(Regex("""\r?\n\s*\r?\n""")).filter { it.isNotBlank() }
        val parsedByIndex = mutableMapOf<Int, String>()
        val sequentialTexts = mutableListOf<String>()

        for (block in blocks) {
            val lines = block.lines().map { it.trimEnd() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) continue

            val tsLineIdx = lines.indexOfFirst { fullTimestampRegex.containsMatchIn(it) }
            if (tsLineIdx >= 0) {
                val parsedIndex = if (tsLineIdx > 0) {
                    lines[tsLineIdx - 1].trim().toIntOrNull()
                } else {
                    null
                }
                val textLines = lines.drop(tsLineIdx + 1)
                val joined = textLines.joinToString("\n").trim()
                if (joined.isNotBlank()) {
                    sequentialTexts.add(joined)
                    if (parsedIndex != null) {
                        parsedByIndex[parsedIndex] = joined
                    }
                }
            }
        }

        return originalSegments.mapIndexed { pos, original ->
            val translated = parsedByIndex[original.index]
                ?: sequentialTexts.getOrNull(pos)
                ?: ""
            original.copy(translatedText = translated.trim())
        }
    }
}
