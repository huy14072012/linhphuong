package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.GTranslate
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.model.ApiConfig
import com.example.model.AppLanguage
import com.example.model.ExportConfig
import com.example.model.ExportFps
import com.example.model.ExportResolution
import com.example.model.ExportState
import com.example.model.GlossaryRule
import com.example.model.SrtSegment
import com.example.model.TargetLanguage
import com.example.model.TranslationProvider
import com.example.model.TtsEngineMode
import com.example.model.TtsPayloadPreset
import com.example.network.VoiceCatalog
import com.example.ui.theme.MatchaGreenDark
import com.example.ui.theme.MatchaGreenDeep
import com.example.ui.theme.MatchaLightBg
import com.example.ui.theme.MatchaMutedText
import com.example.ui.theme.MatchaOnDark
import com.example.ui.theme.MatchaOutline
import com.example.ui.theme.MatchaSurface
import com.example.ui.theme.MatchaSurfaceContainer
import com.example.ui.theme.PeachPink
import com.example.ui.theme.PeachPinkDeep
import com.example.ui.theme.PeachPinkSoft
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.util.LocalAppStrings
import com.example.util.SrtUtils
import com.example.util.TextSanitizer
import com.example.viewmodel.ValidationAlert

@Composable
fun ApiSettingsDialog(
    appLanguage: AppLanguage,
    currentConfig: ApiConfig,
    onSelectAppLanguage: (AppLanguage) -> Unit,
    onSave: (ApiConfig) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var selectedLang by remember(appLanguage) { mutableStateOf(appLanguage) }
    var selectedProvider by remember(currentConfig) { mutableStateOf(currentConfig.translationProvider) }
    var endpointUrl by remember(currentConfig) { mutableStateOf(currentConfig.translationEndpointUrl) }
    var geminiKey by remember(currentConfig) { mutableStateOf(currentConfig.geminiApiKey) }
    var geminiModel by remember(currentConfig) { mutableStateOf(currentConfig.geminiModel) }
    var batchSizeText by remember(currentConfig) { mutableStateOf(currentConfig.translationBatchSize.toString()) }
    var batchDelayText by remember(currentConfig) { mutableStateOf(currentConfig.translationDelayMs.toString()) }
    var ttsUrl by remember(currentConfig) { mutableStateOf(currentConfig.ttsEndpointUrl) }
    var ttsKey by remember(currentConfig) { mutableStateOf(currentConfig.ttsApiKey) }
    var ttsPreset by remember(currentConfig) { mutableStateOf(currentConfig.ttsPayloadPreset) }
    var ttsMode by remember(currentConfig) { mutableStateOf(currentConfig.ttsEngineMode) }
    var autoAlignTiming by remember(currentConfig) { mutableStateOf(currentConfig.autoAlignVoiceTiming) }
    var showApiKey by remember { mutableStateOf(false) }
    var showTtsKey by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MatchaSurface,
        title = {
            Text(
                text = strings.settingsDialogTitle,
                style = MaterialTheme.typography.titleMedium,
                color = MatchaGreenDeep
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 450.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // App UI Language Section (Vietnamese priority #1)
                Text(
                    text = strings.appLanguageSection,
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = selectedLang == lang,
                            onClick = {
                                selectedLang = lang
                                onSelectAppLanguage(lang)
                            },
                            label = {
                                Text(
                                    text = lang.displayName,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PeachPink,
                                selectedLabelColor = MatchaGreenDeep
                            ),
                            modifier = Modifier.testTag("app_lang_chip_${lang.code}")
                        )
                    }
                }

                // Multi-provider Translation API Section
                Text(
                    text = strings.translationProviderSection,
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TranslationProvider.entries.forEach { provider ->
                        FilterChip(
                            selected = selectedProvider == provider,
                            onClick = {
                                selectedProvider = provider
                                endpointUrl = provider.defaultEndpoint
                                geminiModel = provider.defaultModel
                            },
                            label = {
                                Text(
                                    text = provider.displayName,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PeachPink,
                                selectedLabelColor = MatchaGreenDeep
                            ),
                            modifier = Modifier.testTag("provider_chip_${provider.name}")
                        )
                    }
                }

                if (!selectedProvider.requiresApiKey) {
                    Surface(
                        color = MatchaSurfaceContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = strings.googleFreeHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaGreenDeep,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = geminiKey,
                        onValueChange = { geminiKey = it },
                        label = { Text("${selectedProvider.displayName} ${strings.apiKeyLabel}") },
                        placeholder = { Text(if (selectedProvider == TranslationProvider.GEMINI) "AIzaSy..." else "sk-...") },
                        singleLine = true,
                        visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    imageVector = if (showApiKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = "Toggle key visibility"
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gemini_api_key_input")
                    )

                    OutlinedTextField(
                        value = endpointUrl,
                        onValueChange = { endpointUrl = it },
                        label = { Text(strings.endpointUrlLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = geminiModel,
                        onValueChange = { geminiModel = it },
                        label = { Text(strings.modelIdLabel) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = batchSizeText,
                        onValueChange = { batchSizeText = it.filter { ch -> ch.isDigit() } },
                        label = { Text(strings.batchSizeLabel) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = batchDelayText,
                        onValueChange = { batchDelayText = it.filter { ch -> ch.isDigit() } },
                        label = { Text(strings.batchDelayLabel) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Step 4 TTS Section (Expressive Story TTS by default)
                Text(
                    text = strings.ttsSectionTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                ) {
                    FilterChip(
                        selected = ttsMode == TtsEngineMode.EXPRESSIVE_STORY_TTS,
                        onClick = { ttsMode = TtsEngineMode.EXPRESSIVE_STORY_TTS },
                        label = {
                            Text(
                                text = strings.ttsExpressiveLabel,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PeachPink,
                            selectedLabelColor = MatchaGreenDeep
                        ),
                        modifier = Modifier.testTag("tts_mode_expressive")
                    )
                    FilterChip(
                        selected = ttsMode == TtsEngineMode.FREE_BUILTIN_TTS,
                        onClick = { ttsMode = TtsEngineMode.FREE_BUILTIN_TTS },
                        label = {
                            Text(
                                text = strings.ttsFreeBuiltinLabel,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PeachPink,
                            selectedLabelColor = MatchaGreenDeep
                        ),
                        modifier = Modifier.testTag("tts_mode_builtin")
                    )
                    FilterChip(
                        selected = ttsMode == TtsEngineMode.CONFIGURABLE_API,
                        onClick = { ttsMode = TtsEngineMode.CONFIGURABLE_API },
                        label = {
                            Text(
                                text = strings.ttsCustomApiLabel,
                                style = MaterialTheme.typography.labelMedium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PeachPink,
                            selectedLabelColor = MatchaGreenDeep
                        ),
                        modifier = Modifier.testTag("tts_mode_custom")
                    )
                }

                if (ttsMode != TtsEngineMode.CONFIGURABLE_API) {
                    Surface(
                        color = MatchaSurfaceContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (ttsMode == TtsEngineMode.EXPRESSIVE_STORY_TTS) {
                                strings.ttsExpressiveHint
                            } else {
                                strings.ttsFreeHint
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaGreenDeep,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = ttsUrl,
                        onValueChange = { ttsUrl = it },
                        label = { Text("TTS / Voiceover Endpoint URL") },
                        placeholder = { Text("https://api.example.com/v1/audio/speech") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("tts_endpoint_input")
                    )

                    OutlinedTextField(
                        value = ttsKey,
                        onValueChange = { ttsKey = it },
                        label = { Text("TTS API Key (Optional)") },
                        singleLine = true,
                        visualTransformation = if (showTtsKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showTtsKey = !showTtsKey }) {
                                Icon(
                                    imageVector = if (showTtsKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    contentDescription = "Toggle TTS key visibility"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TtsPayloadPreset.entries.forEach { preset ->
                            FilterChip(
                                selected = ttsPreset == preset,
                                onClick = { ttsPreset = preset },
                                label = { Text(preset.label, style = MaterialTheme.typography.labelMedium) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MatchaGreenDark,
                                    selectedLabelColor = MatchaOnDark
                                )
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = strings.autoAlignTimingLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MatchaGreenDeep,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = strings.autoAlignTimingHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaMutedText
                        )
                    }
                    Switch(
                        checked = autoAlignTiming,
                        onCheckedChange = { autoAlignTiming = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MatchaGreenDeep,
                            checkedTrackColor = PeachPink
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val batchSize = (batchSizeText.toIntOrNull() ?: 5).coerceIn(1, 10)
                    val batchDelay = (batchDelayText.toLongOrNull() ?: 650L).coerceIn(250L, 5000L)
                    onSave(
                        ApiConfig(
                            translationProvider = selectedProvider,
                            translationEndpointUrl = endpointUrl.ifBlank { selectedProvider.defaultEndpoint },
                            geminiApiKey = geminiKey,
                            geminiModel = geminiModel.ifBlank { selectedProvider.defaultModel },
                            translationBatchSize = batchSize,
                            translationDelayMs = batchDelay,
                            ttsEndpointUrl = ttsUrl,
                            ttsApiKey = ttsKey,
                            ttsPayloadPreset = ttsPreset,
                            ttsEngineMode = ttsMode,
                            autoAlignVoiceTiming = autoAlignTiming
                        )
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PeachPink,
                    contentColor = MatchaGreenDeep
                ),
                modifier = Modifier.testTag("save_api_settings_button")
            ) {
                Text(strings.saveSettings)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel, color = MatchaGreenDark)
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SrtEditorSheet(
    segments: List<SrtSegment>,
    targetLanguage: TargetLanguage,
    onUpdateSegment: (Int, String, String) -> Unit,
    onUpdateSegmentTiming: (Int, Long, Long) -> Unit = { _, _, _ -> },
    onDeleteSegment: (Int) -> Unit = {},
    onRetryTranslateSegment: (Int) -> Unit = {},
    onSeekToMs: (Long) -> Unit,
    onImportSrtClick: () -> Unit,
    onExportSrtClick: (Boolean) -> Unit,
    onOpenGlossary: () -> Unit = {},
    onTranslateClick: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val hasTranslated = segments.any { it.translatedText.isNotBlank() }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MatchaLightBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = strings.srtInspectorTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = MatchaGreenDeep
                )
                Text(
                    text = "${segments.size} SRT · ${targetLanguage.displayName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MatchaMutedText
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onImportSrtClick,
                        border = BorderStroke(1.dp, MatchaGreenDark),
                        modifier = Modifier.testTag("import_srt_file_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FileOpen,
                            contentDescription = null,
                            tint = MatchaGreenDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.importSrtBtn, color = MatchaGreenDark)
                    }

                    OutlinedButton(
                        onClick = { onExportSrtClick(true) },
                        enabled = segments.isNotEmpty(),
                        border = BorderStroke(1.dp, MatchaGreenDark),
                        modifier = Modifier.testTag("save_srt_file_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Download,
                            contentDescription = null,
                            tint = MatchaGreenDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.saveSrt, color = MatchaGreenDark)
                    }

                    if (hasTranslated) {
                        OutlinedButton(
                            onClick = { onExportSrtClick(false) },
                            border = BorderStroke(1.dp, MatchaOutline)
                        ) {
                            Text(strings.saveSrtOrig, color = MatchaMutedText)
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onOpenGlossary()
                        },
                        border = BorderStroke(1.dp, MatchaGreenDark),
                        modifier = Modifier.testTag("sheet_glossary_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CollectionsBookmark,
                            contentDescription = null,
                            tint = MatchaGreenDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.glossaryAction, color = MatchaGreenDark)
                    }

                    Button(
                        onClick = {
                            onDismiss()
                            onTranslateClick(false)
                        },
                        enabled = segments.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PeachPink,
                            contentColor = MatchaGreenDeep
                        ),
                        modifier = Modifier.testTag("sheet_translate_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.GTranslate,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(strings.translateNow)
                    }

                    if (hasTranslated) {
                        OutlinedButton(
                            onClick = {
                                onDismiss()
                                onTranslateClick(true)
                            },
                            border = BorderStroke(1.dp, PeachPink)
                        ) {
                            Text(strings.translateAllBtn, color = MatchaGreenDeep)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (segments.isEmpty()) {
                Surface(
                    color = MatchaSurface,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MatchaOutline.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.srtTrackEmpty,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MatchaMutedText,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(segments, key = { it.index }) { seg ->
                        var showTimecodeEditor by remember(seg.index) { mutableStateOf(false) }
                        var startTcText by remember(seg.index, seg.startMs) { mutableStateOf(SrtUtils.formatSrtTimestamp(seg.startMs)) }
                        var endTcText by remember(seg.index, seg.endMs) { mutableStateOf(SrtUtils.formatSrtTimestamp(seg.endMs)) }
                        Surface(
                            color = MatchaSurface,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, MatchaOutline.copy(alpha = 0.6f))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "#${seg.index} · ${SrtUtils.formatSrtTimestamp(seg.startMs)} --> ${SrtUtils.formatSrtTimestamp(seg.endMs)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MatchaGreenDark,
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { showTimecodeEditor = !showTimecodeEditor }
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            color = MatchaSurfaceContainer,
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .clickable { onSeekToMs(seg.startMs) }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.PlayArrow,
                                                    contentDescription = "Jump to cue",
                                                    tint = MatchaGreenDeep,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Text(
                                                    text = SrtUtils.formatCompactTime(seg.startMs),
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MatchaGreenDeep
                                                )
                                            }
                                        }
                                        IconButton(
                                            onClick = { onRetryTranslateSegment(seg.index) },
                                            modifier = Modifier
                                                .size(28.dp)
                                                .testTag("retry_translate_cue_${seg.index}")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Refresh,
                                                contentDescription = "Retry line translation",
                                                tint = MatchaGreenDark,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteSegment(seg.index) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.DeleteOutline,
                                                contentDescription = "Delete cue",
                                                tint = StatusError,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                if (showTimecodeEditor) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = startTcText,
                                            onValueChange = {
                                                startTcText = it
                                                val parsed = SrtUtils.parseSrtTimestampSingle(it)
                                                if (parsed != null) {
                                                    onUpdateSegmentTiming(seg.index, parsed, seg.endMs)
                                                }
                                            },
                                            label = { Text("Start") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = endTcText,
                                            onValueChange = {
                                                endTcText = it
                                                val parsed = SrtUtils.parseSrtTimestampSingle(it)
                                                if (parsed != null) {
                                                    onUpdateSegmentTiming(seg.index, seg.startMs, parsed)
                                                }
                                            },
                                            label = { Text("End") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        color = MatchaSurfaceContainer,
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(
                                                onClick = { onUpdateSegmentTiming(seg.index, (seg.startMs - 200L).coerceAtLeast(0L), seg.endMs) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Filled.Remove, contentDescription = "-0.2s start", tint = MatchaGreenDeep, modifier = Modifier.size(13.dp))
                                            }
                                            Text("Start ±0.2s", style = MaterialTheme.typography.labelSmall, color = MatchaGreenDeep)
                                            IconButton(
                                                onClick = { onUpdateSegmentTiming(seg.index, (seg.startMs + 200L).coerceAtMost((seg.endMs - 250L).coerceAtLeast(0L)), seg.endMs) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Filled.Add, contentDescription = "+0.2s start", tint = MatchaGreenDeep, modifier = Modifier.size(13.dp))
                                            }
                                        }
                                    }
                                    Surface(
                                        color = MatchaSurfaceContainer,
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(
                                                onClick = { onUpdateSegmentTiming(seg.index, seg.startMs, (seg.endMs - 200L).coerceAtLeast(seg.startMs + 250L)) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Filled.Remove, contentDescription = "-0.2s end", tint = MatchaGreenDeep, modifier = Modifier.size(13.dp))
                                            }
                                            Text("End ±0.2s", style = MaterialTheme.typography.labelSmall, color = MatchaGreenDeep)
                                            IconButton(
                                                onClick = { onUpdateSegmentTiming(seg.index, seg.startMs, seg.endMs + 200L) },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(Icons.Filled.Add, contentDescription = "+0.2s end", tint = MatchaGreenDeep, modifier = Modifier.size(13.dp))
                                            }
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = seg.originalText,
                                    onValueChange = { onUpdateSegment(seg.index, it, seg.translatedText) },
                                    label = { Text(strings.sourceTextLabel) },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                OutlinedTextField(
                                    value = seg.translatedText,
                                    onValueChange = { onUpdateSegment(seg.index, seg.originalText, it) },
                                    label = { Text("${strings.translatedTextLabel} (${targetLanguage.displayName})") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("edit_translated_segment_${seg.index}")
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlossarySheet(
    rules: List<GlossaryRule>,
    onAddRule: (String, String) -> Unit,
    onToggleRule: (String) -> Unit,
    onDeleteRule: (String) -> Unit,
    onLoadStarterPreset: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var newSource by remember { mutableStateOf("") }
    var newTarget by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MatchaLightBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.glossaryTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MatchaGreenDeep
                    )
                    Text(
                        text = strings.glossaryHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = MatchaMutedText
                    )
                }
                OutlinedButton(
                    onClick = onLoadStarterPreset,
                    border = BorderStroke(1.dp, MatchaGreenDark),
                    modifier = Modifier.testTag("glossary_load_preset_button")
                ) {
                    Text(strings.loadPresetBtn, color = MatchaGreenDark)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newSource,
                    onValueChange = { newSource = it },
                    label = { Text(strings.sourceTermLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("glossary_source_input")
                )
                OutlinedTextField(
                    value = newTarget,
                    onValueChange = { newTarget = it },
                    label = { Text(strings.targetTermLabel) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("glossary_target_input")
                )
                Button(
                    onClick = {
                        if (newSource.isNotBlank() && newTarget.isNotBlank()) {
                            onAddRule(newSource.trim(), newTarget.trim())
                            newSource = ""
                            newTarget = ""
                        }
                    },
                    enabled = newSource.isNotBlank() && newTarget.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PeachPink,
                        contentColor = MatchaGreenDeep
                    ),
                    modifier = Modifier.testTag("glossary_add_button")
                ) {
                    Text(strings.addTermBtn)
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 320.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(rules, key = { it.id }) { rule ->
                    Surface(
                        color = MatchaSurface,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MatchaOutline.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${rule.sourceTerm}  →  ${rule.targetTerm}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (rule.enabled) MatchaGreenDeep else MatchaMutedText,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(
                                    checked = rule.enabled,
                                    onCheckedChange = { onToggleRule(rule.id) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = MatchaGreenDeep,
                                        checkedTrackColor = PeachPink
                                    )
                                )
                                IconButton(
                                    onClick = { onDeleteRule(rule.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.DeleteOutline,
                                        contentDescription = "Delete term",
                                        tint = StatusError,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceoverSheet(
    segments: List<SrtSegment>,
    selectedVoiceId: String,
    targetLanguage: TargetLanguage,
    apiConfig: ApiConfig,
    onSelectVoice: (String) -> Unit,
    onGenerateVoiceover: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    val sanitizedLines = remember(segments) {
        segments.map { TextSanitizer.sanitizeForVoiceover(it.translatedText) }.filter { it.isNotBlank() }
    }
    val chineseCharsRemaining = remember(sanitizedLines) {
        sanitizedLines.sumOf { TextSanitizer.countChineseCharacters(it) }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MatchaLightBg
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.voiceoverStudioTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MatchaGreenDeep
                    )
                    Text(
                        text = "${VoiceCatalog.voices.size} giọng đọc · ${strings.voiceoverFreeBadge}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MatchaGreenDark,
                        fontWeight = FontWeight.Medium
                    )
                }

                TextButton(onClick = {
                    onDismiss()
                    onOpenSettings()
                }) {
                    Text(strings.apiSettings, color = MatchaGreenDark)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = if (chineseCharsRemaining == 0) MatchaSurfaceContainer else PeachPinkSoft,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (chineseCharsRemaining == 0) MatchaGreenDark else StatusError),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.VerifiedUser,
                        contentDescription = null,
                        tint = if (chineseCharsRemaining == 0) StatusSuccess else StatusError,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "${strings.sanitationTitle}: $chineseCharsRemaining",
                            style = MaterialTheme.typography.labelLarge,
                            color = MatchaGreenDeep
                        )
                        Text(
                            text = "${strings.sanitationSubtitle} (${sanitizedLines.size} · ${targetLanguage.displayName})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaMutedText
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 310.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(VoiceCatalog.voices, key = { it.id }) { voice ->
                    val isSelected = voice.id == selectedVoiceId
                    Surface(
                        color = if (isSelected) PeachPinkSoft else MatchaSurface,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) PeachPink else MatchaOutline.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectVoice(voice.id) }
                            .testTag("voice_card_${voice.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) PeachPink else MatchaSurfaceContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.GraphicEq,
                                        contentDescription = null,
                                        tint = MatchaGreenDeep,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = voice.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MatchaGreenDeep
                                    )
                                    Text(
                                        text = "${voice.language} · ${voice.gender} · ${voice.style}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MatchaMutedText
                                    )
                                }
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = PeachPinkDeep
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onGenerateVoiceover,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PeachPink,
                    contentColor = MatchaGreenDeep
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("generate_voiceover_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.RecordVoiceOver,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                val chosen = VoiceCatalog.findById(selectedVoiceId)
                Text(
                    text = "${chosen.name} · ${strings.generateVoiceoverBtn}",
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}

@Composable
fun ExportOptionsDialog(
    initialConfig: ExportConfig,
    hasSubtitles: Boolean,
    hasVoiceover: Boolean,
    onStartExport: (ExportConfig) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    var selectedRes by remember(initialConfig) { mutableStateOf(initialConfig.resolution) }
    var selectedFps by remember(initialConfig) { mutableStateOf(initialConfig.fps) }
    var burnSubs by remember(initialConfig, hasSubtitles) { mutableStateOf(hasSubtitles) }
    var keepOrigAudio by remember(initialConfig, hasVoiceover) { mutableStateOf(!hasVoiceover) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MatchaSurface,
        title = {
            Text(
                text = strings.exportDialogTitle,
                style = MaterialTheme.typography.titleMedium,
                color = MatchaGreenDeep
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = strings.targetResolutionLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ExportResolution.entries.forEach { res ->
                        FilterChip(
                            selected = selectedRes == res,
                            onClick = { selectedRes = res },
                            label = { Text(res.label, style = MaterialTheme.typography.labelMedium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PeachPink,
                                selectedLabelColor = MatchaGreenDeep
                            ),
                            modifier = Modifier.testTag("export_res_${res.name}")
                        )
                    }
                }

                Text(
                    text = strings.targetFpsLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = MatchaGreenDark
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExportFps.entries.forEach { fps ->
                        FilterChip(
                            selected = selectedFps == fps,
                            onClick = { selectedFps = fps },
                            label = { Text(fps.label, style = MaterialTheme.typography.labelMedium) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PeachPink,
                                selectedLabelColor = MatchaGreenDeep
                            ),
                            modifier = Modifier.testTag("export_fps_${fps.fps}")
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(strings.burnSubtitlesLabel, style = MaterialTheme.typography.bodyMedium, color = MatchaGreenDeep)
                        Text(
                            text = strings.burnSubtitlesHint,
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaMutedText
                        )
                    }
                    Switch(
                        checked = burnSubs && hasSubtitles,
                        enabled = hasSubtitles,
                        onCheckedChange = { burnSubs = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MatchaGreenDeep, checkedTrackColor = PeachPink)
                    )
                }

                if (hasVoiceover) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(strings.keepOriginalAudioLabel, style = MaterialTheme.typography.bodyMedium, color = MatchaGreenDeep)
                            Text(
                                text = strings.keepOriginalAudioHint,
                                style = MaterialTheme.typography.bodySmall,
                                color = MatchaMutedText
                            )
                        }
                        Switch(
                            checked = keepOrigAudio,
                            onCheckedChange = { keepOrigAudio = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = MatchaGreenDeep, checkedTrackColor = PeachPink)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onStartExport(
                        ExportConfig(
                            resolution = selectedRes,
                            fps = selectedFps,
                            burnSubtitles = burnSubs && hasSubtitles,
                            keepOriginalAudio = keepOrigAudio
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = PeachPink,
                    contentColor = MatchaGreenDeep
                ),
                modifier = Modifier.testTag("confirm_export_mp4_button")
            ) {
                Text(strings.renderExportBtn)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(strings.cancel, color = MatchaGreenDark)
            }
        }
    )
}

@Composable
fun ExportStatusDialog(
    exportState: ExportState,
    onCancel: () -> Unit,
    onSaveCopyAs: () -> Unit,
    onShareMp4: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    when (exportState) {
        ExportState.Idle -> Unit
        is ExportState.Running -> {
            AlertDialog(
                onDismissRequest = {},
                containerColor = MatchaSurface,
                title = {
                    Text(strings.exportingTitle, style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(exportState.stageLabel, style = MaterialTheme.typography.bodyMedium, color = MatchaMutedText)
                        LinearProgressIndicator(
                            progress = { (exportState.progressPercent / 100f).coerceIn(0f, 1f) },
                            color = PeachPink,
                            trackColor = MatchaSurfaceContainer,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "${exportState.progressPercent}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = MatchaGreenDark
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = onCancel) {
                        Text(strings.cancelExportBtn, color = StatusError)
                    }
                }
            )
        }

        is ExportState.Completed -> {
            val sizeMb = String.format(java.util.Locale.US, "%.2f MB", exportState.fileSizeBytes / (1024f * 1024f))
            AlertDialog(
                onDismissRequest = onDismiss,
                containerColor = MatchaSurface,
                icon = {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(32.dp))
                },
                title = {
                    Text(strings.exportCompleteTitle, style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Size: $sizeMb", style = MaterialTheme.typography.bodyMedium, color = MatchaGreenDeep)
                        Text(
                            text = if (exportState.mediaStoreUri != null) {
                                "Movies/MatchaCut"
                            } else {
                                "Cache MP4"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MatchaMutedText
                        )
                    }
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onSaveCopyAs) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.saveCopyBtn)
                        }
                        Button(
                            onClick = { onShareMp4(exportState.outputPath) },
                            colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.shareBtn)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = onDismiss) {
                        Text(strings.doneBtn, color = MatchaGreenDark)
                    }
                }
            )
        }

        is ExportState.Failed -> {
            AlertDialog(
                onDismissRequest = onDismiss,
                containerColor = MatchaSurface,
                icon = {
                    Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = StatusError, modifier = Modifier.size(32.dp))
                },
                title = {
                    Text(strings.exportFailedTitle, style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
                },
                text = {
                    Text(exportState.message, style = MaterialTheme.typography.bodyMedium, color = MatchaMutedText)
                },
                confirmButton = {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                    ) {
                        Text("OK")
                    }
                }
            )
        }
    }
}

@Composable
fun ValidationAlertDialog(
    alert: ValidationAlert,
    onFixToChinese: () -> Unit,
    onTranslateNow: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val strings = LocalAppStrings.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MatchaSurface,
        icon = {
            Icon(Icons.Filled.WarningAmber, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(30.dp))
        },
        title = {
            Text(alert.title, style = MaterialTheme.typography.titleMedium, color = MatchaGreenDeep)
        },
        text = {
            Text(alert.message, style = MaterialTheme.typography.bodyMedium, color = MatchaMutedText)
        },
        confirmButton = {
            when {
                alert.showLanguageFixButton -> {
                    Button(
                        onClick = {
                            onFixToChinese()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                    ) {
                        Text(strings.useChineseDefaultBtn)
                    }
                }
                alert.showTranslateActionButton -> {
                    Button(
                        onClick = {
                            onDismiss()
                            onTranslateNow()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                    ) {
                        Text(strings.translateNow)
                    }
                }
                else -> {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = PeachPink, contentColor = MatchaGreenDeep)
                    ) {
                        Text(strings.adjustRetryBtn)
                    }
                }
            }
        },
        dismissButton = if (alert.showLanguageFixButton || alert.showTranslateActionButton) {
            {
                TextButton(onClick = onDismiss) {
                    Text(strings.cancel, color = MatchaGreenDark)
                }
            }
        } else null
    )
}
