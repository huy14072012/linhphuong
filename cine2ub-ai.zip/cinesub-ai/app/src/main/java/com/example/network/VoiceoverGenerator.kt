package com.example.network

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import com.example.model.ApiConfig
import com.example.model.SrtSegment
import com.example.model.TargetLanguage
import com.example.model.TtsEngineMode
import com.example.model.TtsPayloadPreset
import com.example.model.VoiceOption
import com.example.util.SanitationResult
import com.example.util.TextSanitizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.sqrt

object VoiceCatalog {
    val voices: List<VoiceOption> = listOf(
        VoiceOption(
            id = "ngoc_huyen",
            name = "Ngọc Huyền",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nữ",
            style = "Kể chuyện truyền cảm, nhấn nhá tự nhiên",
            apiVoiceCode = "ngoc_huyen",
            pitch = 1.05f,
            speechRate = 0.98f
        ),
        VoiceOption(
            id = "nam_minh",
            name = "Nam Minh",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nam",
            style = "Thuyết minh rõ ràng, có lực",
            apiVoiceCode = "nam_minh",
            pitch = 0.90f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "hoai_tay",
            name = "Hoài Tây",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nam",
            style = "Trầm ấm, dẫn truyện cảm xúc",
            apiVoiceCode = "hoai_tay",
            pitch = 0.82f,
            speechRate = 0.93f
        ),
        VoiceOption(
            id = "linh_dan",
            name = "Linh Đan",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nữ",
            style = "Tươi sáng, hoạt hình / vlog",
            apiVoiceCode = "linh_dan",
            pitch = 1.13f,
            speechRate = 1.03f
        ),
        VoiceOption(
            id = "minh_triet",
            name = "Minh Triết",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nam",
            style = "Review phim / tiên hiệp kịch tính",
            apiVoiceCode = "minh_triet",
            pitch = 0.86f,
            speechRate = 1.02f
        ),
        VoiceOption(
            id = "thao_vy",
            name = "Thảo Vy",
            language = "Tiếng Việt",
            languageCode = "vi",
            gender = "Nữ",
            style = "Dịu dàng, lồng tiếng nhân vật nữ",
            apiVoiceCode = "thao_vy",
            pitch = 1.09f,
            speechRate = 0.95f
        ),
        VoiceOption(
            id = "adam",
            name = "Adam",
            language = "English (US)",
            languageCode = "en",
            gender = "Male",
            style = "Deep Studio Narrator",
            apiVoiceCode = "adam",
            pitch = 0.85f,
            speechRate = 0.96f
        ),
        VoiceOption(
            id = "rachel",
            name = "Rachel",
            language = "English (US)",
            languageCode = "en",
            gender = "Female",
            style = "Conversational Clear",
            apiVoiceCode = "rachel",
            pitch = 1.06f,
            speechRate = 1.02f
        ),
        VoiceOption(
            id = "bella",
            name = "Bella",
            language = "English (UK)",
            languageCode = "en",
            gender = "Female",
            style = "Soft Storytelling",
            apiVoiceCode = "bella",
            pitch = 1.10f,
            speechRate = 0.96f
        ),
        VoiceOption(
            id = "antoni",
            name = "Antoni",
            language = "English (US)",
            languageCode = "en",
            gender = "Male",
            style = "Expressive Creator",
            apiVoiceCode = "antoni",
            pitch = 0.94f,
            speechRate = 1.04f
        ),
        VoiceOption(
            id = "josh",
            name = "Josh",
            language = "English (US)",
            languageCode = "en",
            gender = "Male",
            style = "Energetic Host",
            apiVoiceCode = "josh",
            pitch = 0.92f,
            speechRate = 1.08f
        ),
        VoiceOption(
            id = "aria",
            name = "Aria",
            language = "English (AU)",
            languageCode = "en",
            gender = "Female",
            style = "Crisp Tutorial",
            apiVoiceCode = "aria",
            pitch = 1.04f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "sora",
            name = "Sora",
            language = "日本語",
            languageCode = "ja",
            gender = "Female",
            style = "Gentle Lifestyle",
            apiVoiceCode = "sora",
            pitch = 1.08f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "kenji",
            name = "Kenji",
            language = "日本語",
            languageCode = "ja",
            gender = "Male",
            style = "Studio Commercial",
            apiVoiceCode = "kenji",
            pitch = 0.88f,
            speechRate = 1.02f
        ),
        VoiceOption(
            id = "elena",
            name = "Elena",
            language = "Español",
            languageCode = "es",
            gender = "Female",
            style = "Warm Editorial",
            apiVoiceCode = "elena",
            pitch = 1.05f,
            speechRate = 1.00f
        ),
        VoiceOption(
            id = "lucas",
            name = "Lucas",
            language = "Français",
            languageCode = "fr",
            gender = "Male",
            style = "Smooth Cinema",
            apiVoiceCode = "lucas",
            pitch = 0.90f,
            speechRate = 0.98f
        )
    )

    fun findById(id: String): VoiceOption = voices.find { it.id == id } ?: voices.first()
}

sealed interface VoiceoverResult {
    data class Success(
        val masterWavPath: String,
        val updatedSegments: List<SrtSegment>,
        val waveformPeaks: List<Float>,
        val voiceName: String
    ) : VoiceoverResult

    data class Error(val message: String) : VoiceoverResult
}

object VoiceoverGenerator {

    private const val MASTER_SAMPLE_RATE = 24_000
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun generateTimelineVoiceover(
        context: Context,
        segments: List<SrtSegment>,
        totalVideoDurationMs: Long,
        voice: VoiceOption,
        targetLanguage: TargetLanguage,
        apiConfig: ApiConfig,
        onProgress: (Float, String) -> Unit
    ): VoiceoverResult = withContext(Dispatchers.IO) {
        val sanitizedSegments = when (val check = TextSanitizer.validateSanitizedVoiceoverScript(segments)) {
            is SanitationResult.Blocked -> return@withContext VoiceoverResult.Error(check.reason)
            is SanitationResult.Valid -> check.sanitizedSegments
        }

        if (apiConfig.ttsEngineMode == TtsEngineMode.CONFIGURABLE_API &&
            apiConfig.ttsEndpointUrl.trim().isBlank()
        ) {
            return@withContext VoiceoverResult.Error(
                "TTS API Endpoint URL đang trống. Hãy chọn chế độ 'Truyền cảm thông minh' hoặc nhập Endpoint URL trong Cài đặt."
            )
        }

        val voDir = File(context.cacheDir, "voiceover").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        val segmentPcmMap = mutableMapOf<Int, ShortArray>()
        val updatedSegments = mutableListOf<SrtSegment>()
        var ttsEngine: TextToSpeech? = null
        val isExpressiveMode = apiConfig.ttsEngineMode == TtsEngineMode.EXPRESSIVE_STORY_TTS

        try {
            if (apiConfig.ttsEngineMode != TtsEngineMode.CONFIGURABLE_API) {
                ttsEngine = initAndConfigureBuiltinTts(
                    context = context,
                    voice = voice,
                    targetLanguage = targetLanguage,
                    preferHighQualityOnline = isExpressiveMode
                )
                if (ttsEngine == null) {
                    return@withContext VoiceoverResult.Error(
                        "Không thể khởi tạo bộ đọc giọng nói TextToSpeech trên thiết bị. Hãy kiểm tra cài đặt Google Speech Services trên máy."
                    )
                }
            }

            sanitizedSegments.forEachIndexed { idx, segment ->
                onProgress(
                    (idx.toFloat() / sanitizedSegments.size.toFloat()) * 0.85f,
                    "Đang tạo giọng ${voice.name} · ${idx + 1}/${sanitizedSegments.size}"
                )

                val nextStartMs = sanitizedSegments.getOrNull(idx + 1)?.startMs ?: totalVideoDurationMs
                val cueWindowMs = computeCueAvailableWindowMs(segment, nextStartMs)
                val adaptiveRate = if (apiConfig.autoAlignVoiceTiming) {
                    computeAdaptiveSpeechRate(segment.translatedText, cueWindowMs, voice.speechRate)
                } else {
                    voice.speechRate
                }
                val expressivePitch = computeExpressivePitch(segment.translatedText, voice.pitch, isExpressiveMode)

                val clipFile = File(voDir, "seg_${segment.index}.wav")
                val decodedPcm = if (apiConfig.ttsEngineMode == TtsEngineMode.CONFIGURABLE_API) {
                    synthesizeViaRemoteApi(
                        endpointUrl = apiConfig.ttsEndpointUrl.trim(),
                        apiKey = apiConfig.ttsApiKey.trim(),
                        preset = apiConfig.ttsPayloadPreset,
                        voice = voice,
                        text = segment.translatedText,
                        outFile = clipFile
                    )
                    decodeAudioFileToMono24kPcm(clipFile)
                } else if (isExpressiveMode) {
                    val expressivePcm = synthesizeExpressivePhrasePcm(
                        tts = ttsEngine!!,
                        text = segment.translatedText,
                        baseRate = adaptiveRate,
                        basePitch = voice.pitch,
                        tempDir = voDir,
                        segmentIndex = segment.index,
                        targetLangDisplay = targetLanguage.displayName
                    )
                    writeMonoWav(clipFile, expressivePcm, MASTER_SAMPLE_RATE)
                    expressivePcm
                } else {
                    ttsEngine!!.setPitch(expressivePitch)
                    ttsEngine.setSpeechRate(adaptiveRate)
                    val ok = synthesizeViaSystemTts(ttsEngine, segment.translatedText, clipFile)
                    if (!ok || !clipFile.exists() || clipFile.length() == 0L) {
                        throw IllegalStateException(
                            "Thiết bị không thể tạo âm thanh cho dòng #${segment.index}. Vui lòng kiểm tra gói giọng nói (${targetLanguage.displayName}) trong Cài đặt Text-to-Speech của Android."
                        )
                    }
                    decodeAudioFileToMono24kPcm(clipFile)
                }
                val trimmedPcm = trimSilencePadding(decodedPcm)
                val fittedPcm = if (apiConfig.autoAlignVoiceTiming) {
                    fitPcmToWindowWithoutOverlap(trimmedPcm, cueWindowMs)
                } else {
                    trimmedPcm
                }
                val polishedPcm = applyGentleFadeAndNormalize(fittedPcm)

                val durationMs = ((polishedPcm.size * 1000L) / MASTER_SAMPLE_RATE).coerceAtLeast(100L)
                segmentPcmMap[segment.index] = polishedPcm
                updatedSegments.add(
                    segment.copy(
                        voiceoverAudioPath = clipFile.absolutePath,
                        voiceoverDurationMs = durationMs
                    )
                )
            }

            onProgress(0.92f, "Đang căn nhịp & ghép giọng đọc vào Timeline...")
            val safeDurationMs = maxOf(
                totalVideoDurationMs,
                updatedSegments.maxOfOrNull { maxOf(it.endMs, it.startMs + it.voiceoverDurationMs) } ?: 1000L
            )
            val totalSamples = ((safeDurationMs * MASTER_SAMPLE_RATE) / 1000L).toInt()
                .coerceAtLeast(MASTER_SAMPLE_RATE)
            val masterSamples = ShortArray(totalSamples)

            for (idx in updatedSegments.indices) {
                val seg = updatedSegments[idx]
                val segPcm = segmentPcmMap[seg.index] ?: continue
                val startSample = ((seg.startMs * MASTER_SAMPLE_RATE) / 1000L).toInt()
                    .coerceIn(0, (totalSamples - 1).coerceAtLeast(0))

                // Guard against overlap with next segment's start timestamp
                val nextStartMs = updatedSegments.getOrNull(idx + 1)?.startMs
                val maxEndSample = if (nextStartMs != null) {
                    (((nextStartMs - 60L).coerceAtLeast(seg.startMs + 200L) * MASTER_SAMPLE_RATE) / 1000L).toInt()
                        .coerceAtMost(totalSamples)
                } else {
                    totalSamples
                }

                for (i in segPcm.indices) {
                    val dst = startSample + i
                    if (dst >= maxEndSample || dst >= totalSamples) break
                    val mixed = masterSamples[dst].toInt() + segPcm[i].toInt()
                    masterSamples[dst] = mixed.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }
            }

            val masterWav = File(voDir, "voiceover_master.wav")
            writeMonoWav(masterWav, masterSamples, MASTER_SAMPLE_RATE)

            val peaks = computeWaveformPeaks(masterSamples, 72)
            onProgress(1f, "Hoàn tất lồng tiếng chuẩn nhịp")
            VoiceoverResult.Success(
                masterWavPath = masterWav.absolutePath,
                updatedSegments = updatedSegments,
                waveformPeaks = peaks,
                voiceName = voice.name
            )
        } catch (t: Throwable) {
            VoiceoverResult.Error(t.message ?: "Lỗi tạo giọng lồng tiếng.")
        } finally {
            runCatching { ttsEngine?.shutdown() }
        }
    }

    fun computeCueAvailableWindowMs(segment: SrtSegment, nextStartMs: Long): Long {
        val rawSlot = (segment.endMs - segment.startMs).coerceAtLeast(450L)
        val gapToNext = (nextStartMs - segment.startMs - 80L).coerceAtLeast(rawSlot)
        // Allow using a small pause tail up to +450ms if there is silent room before next line
        return minOf(gapToNext, rawSlot + 450L).coerceAtLeast(450L)
    }

    /**
     * Automatically adapts speech rate based on Vietnamese/text character density vs available cue window
     * so calm short lines aren't rushed and long lines fit cleanly without getting cut off.
     */
    fun computeAdaptiveSpeechRate(text: String, windowMs: Long, baseRate: Float): Float {
        val cleanLen = text.replace(Regex("""\s+"""), " ").trim().length.coerceAtLeast(1)
        // Typical natural Vietnamese TTS rate is ~13.2 chars/sec at 1.0x + ~120ms punctuation breath
        val punctCount = text.count { it == ',' || it == '.' || it == '!' || it == '?' || it == ';' }
        val estimatedBaseMs = ((cleanLen / 13.2f) * 1000f) + (punctCount * 110f)
        val targetRatio = (estimatedBaseMs / windowMs.toFloat())
        val adjusted = when {
            targetRatio > 1.05f -> (baseRate * targetRatio).coerceIn(baseRate, 1.38f)
            targetRatio < 0.55f -> (baseRate * 0.92f).coerceAtLeast(0.84f)
            else -> baseRate
        }
        return adjusted.coerceIn(0.82f, 1.38f)
    }

    private fun computeExpressivePitch(text: String, basePitch: Float, isExpressiveMode: Boolean): Float {
        if (!isExpressiveMode) return basePitch
        val trimmed = text.trim()
        return when {
            trimmed.endsWith("!") -> (basePitch * 1.04f).coerceAtMost(1.25f)
            trimmed.endsWith("?") -> (basePitch * 1.02f).coerceAtMost(1.22f)
            trimmed.endsWith("...") || trimmed.endsWith("…") -> (basePitch * 0.96f).coerceAtLeast(0.75f)
            else -> basePitch
        }
    }

    /**
     * Wraps text in lightweight SSML for natural pauses at commas/periods and subtle pitch cadence.
     */
    fun buildExpressiveSsml(text: String, rate: Float, pitch: Float): String {
        val escaped = text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace(Regex(""",\s*"""), ", <break time=\"140ms\"/>")
            .replace(Regex(""";\s*"""), "; <break time=\"180ms\"/>")
            .replace(Regex("""\.\.\.\s*|…\s*"""), " <break time=\"260ms\"/>")
            .replace(Regex("""([.!?])\s+"""), "$1 <break time=\"220ms\"/>")

        val ratePct = (rate * 100f).toInt().coerceIn(80, 145)
        val pitchDelta = ((pitch - 1.0f) * 100f).toInt()
        val pitchAttr = if (pitchDelta >= 0) "+${pitchDelta}%" else "${pitchDelta}%"

        return "<speak><prosody rate=\"${ratePct}%\" pitch=\"$pitchAttr\">$escaped</prosody></speak>"
    }

    data class ExpressiveClause(val text: String, val pauseAfterMs: Long, val pitchScale: Float)

    /**
     * Splits a subtitle sentence on natural Vietnamese punctuation pauses so Expressive Story TTS
     * adds calibrated breath pauses and natural sentence-ending inflection without ever risking
     * TTS engines literally reading raw XML/SSML tags aloud.
     */
    fun splitExpressiveClauses(text: String): List<ExpressiveClause> {
        val clean = text.replace(Regex("""\s+"""), " ").trim()
        if (clean.isEmpty()) return emptyList()

        val parts = mutableListOf<ExpressiveClause>()
        val regex = Regex("""([^,;!?…]+(?:\.\.\.|[,;!?…])?)""")
        for (m in regex.findAll(clean)) {
            val rawClause = m.value.trim()
            if (rawClause.isEmpty()) continue
            val pauseMs = when {
                rawClause.endsWith("...") || rawClause.endsWith("…") -> 220L
                rawClause.endsWith("!") || rawClause.endsWith("?") -> 180L
                rawClause.endsWith(";") -> 160L
                rawClause.endsWith(",") -> 125L
                else -> 0L
            }
            val pitchScale = when {
                rawClause.endsWith("?") -> 1.04f
                rawClause.endsWith("!") -> 1.05f
                rawClause.endsWith("...") || rawClause.endsWith("…") -> 0.96f
                else -> 1.0f
            }
            val spoken = rawClause.trimEnd(',', ';')
            if (spoken.any { it.isLetterOrDigit() }) {
                parts.add(ExpressiveClause(spoken, pauseMs, pitchScale))
            }
        }
        return if (parts.isEmpty()) listOf(ExpressiveClause(clean, 0L, 1.0f)) else parts
    }

    private suspend fun synthesizeExpressivePhrasePcm(
        tts: TextToSpeech,
        text: String,
        baseRate: Float,
        basePitch: Float,
        tempDir: File,
        segmentIndex: Int,
        targetLangDisplay: String
    ): ShortArray {
        val clauses = splitExpressiveClauses(text)
        if (clauses.size <= 1) {
            val singleFile = File(tempDir, "seg_${segmentIndex}_raw.wav")
            tts.setPitch(computeExpressivePitch(text, basePitch, isExpressiveMode = true))
            tts.setSpeechRate(baseRate)
            val ok = synthesizeViaSystemTts(tts, text, singleFile)
            if (!ok || !singleFile.exists() || singleFile.length() == 0L) {
                throw IllegalStateException(
                    "Thiết bị không thể tạo âm thanh cho dòng #$segmentIndex. Vui lòng kiểm tra gói giọng nói ($targetLangDisplay) trong Cài đặt Text-to-Speech của Android."
                )
            }
            return decodeAudioFileToMono24kPcm(singleFile)
        }

        val combined = mutableListOf<ShortArray>()
        clauses.forEachIndexed { idx, clause ->
            val clauseFile = File(tempDir, "seg_${segmentIndex}_c${idx}.wav")
            tts.setPitch((basePitch * clause.pitchScale).coerceIn(0.75f, 1.25f))
            tts.setSpeechRate(baseRate)
            val ok = synthesizeViaSystemTts(tts, clause.text, clauseFile)
            if (!ok || !clauseFile.exists() || clauseFile.length() == 0L) {
                throw IllegalStateException(
                    "Thiết bị không thể tạo âm thanh cho dòng #$segmentIndex. Vui lòng kiểm tra gói giọng nói ($targetLangDisplay) trong Cài đặt Text-to-Speech của Android."
                )
            }
            val pcm = trimSilencePadding(decodeAudioFileToMono24kPcm(clauseFile))
            combined.add(pcm)
            if (idx < clauses.lastIndex && clause.pauseAfterMs > 0L) {
                val pauseSamples = ((clause.pauseAfterMs * MASTER_SAMPLE_RATE) / 1000L).toInt()
                if (pauseSamples > 0) combined.add(ShortArray(pauseSamples))
            }
        }
        val totalLen = combined.sumOf { it.size }
        val merged = ShortArray(totalLen)
        var cursor = 0
        for (chunk in combined) {
            chunk.copyInto(merged, destinationOffset = cursor)
            cursor += chunk.size
        }
        return merged
    }

    /**
     * Strips leading/trailing dead silence padded by TTS engines so speech starts right on cue.
     */
    private fun trimSilencePadding(samples: ShortArray): ShortArray {
        if (samples.size < 400) return samples
        val threshold = 240
        var start = 0
        while (start < samples.size - 1 && abs(samples[start].toInt()) < threshold) {
            start++
        }
        var end = samples.lastIndex
        while (end > start && abs(samples[end].toInt()) < threshold) {
            end--
        }
        val leadMargin = (MASTER_SAMPLE_RATE * 0.025f).toInt()
        val tailMargin = (MASTER_SAMPLE_RATE * 0.045f).toInt()
        val safeStart = (start - leadMargin).coerceAtLeast(0)
        val safeEnd = (end + tailMargin).coerceAtMost(samples.lastIndex)
        if (safeEnd <= safeStart) return samples
        return samples.copyOfRange(safeStart, safeEnd + 1)
    }

    /**
     * Fits trimmed PCM into the subtitle's available time window so consecutive lines never collide.
     * Gently compresses up to 1.25x if slightly overlong, then cleanly fades out at window end.
     */
    private fun fitPcmToWindowWithoutOverlap(samples: ShortArray, windowMs: Long): ShortArray {
        if (samples.isEmpty()) return samples
        val maxSamples = ((windowMs * MASTER_SAMPLE_RATE) / 1000L).toInt().coerceAtLeast(2400)
        if (samples.size <= maxSamples) return samples

        val ratio = samples.size.toFloat() / maxSamples.toFloat()
        val cappedOutLen = if (ratio <= 1.28f) {
            maxSamples
        } else {
            (samples.size / 1.25f).toInt().coerceAtLeast(maxSamples)
        }

        val resampled = ShortArray(cappedOutLen) { i ->
            val srcPos = (i.toDouble() * samples.size) / cappedOutLen
            val idx0 = srcPos.toInt().coerceIn(0, samples.lastIndex)
            val idx1 = (idx0 + 1).coerceIn(0, samples.lastIndex)
            val frac = srcPos - idx0
            ((samples[idx0] * (1.0 - frac)) + (samples[idx1] * frac)).toInt().toShort()
        }
        return if (resampled.size > maxSamples) resampled.copyOfRange(0, maxSamples) else resampled
    }

    private fun applyGentleFadeAndNormalize(samples: ShortArray): ShortArray {
        if (samples.isEmpty()) return samples
        val out = samples.copyOf()

        // Normalize RMS to consistent studio speech level (~0.18 RMS) without clipping
        var sumSq = 0.0
        for (s in out) {
            val v = s.toDouble() / 32768.0
            sumSq += v * v
        }
        val rms = sqrt(sumSq / out.size.toDouble()).toFloat()
        if (rms > 0.01f) {
            val gain = (0.19f / rms).coerceIn(0.7f, 2.2f)
            for (i in out.indices) {
                out[i] = (out[i] * gain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
        }

        val fadeSamples = minOf((MASTER_SAMPLE_RATE * 0.018f).toInt(), out.size / 6)
        for (i in 0 until fadeSamples) {
            val f = i.toFloat() / fadeSamples.coerceAtLeast(1).toFloat()
            out[i] = (out[i] * f).toInt().toShort()
            val tailIdx = out.lastIndex - i
            out[tailIdx] = (out[tailIdx] * f).toInt().toShort()
        }
        return out
    }

    private fun synthesizeViaRemoteApi(
        endpointUrl: String,
        apiKey: String,
        preset: TtsPayloadPreset,
        voice: VoiceOption,
        text: String,
        outFile: File
    ) {
        if (TextSanitizer.containsChineseCharacters(text)) {
            throw IllegalStateException("Blocked: source Chinese characters detected in TTS payload.")
        }

        val jsonBody = when (preset) {
            TtsPayloadPreset.OPENAI_COMPATIBLE -> JSONObject()
                .put("model", "tts-1")
                .put("voice", voice.apiVoiceCode)
                .put("input", text)
                .put("response_format", "wav")
            TtsPayloadPreset.CUSTOM_JSON -> JSONObject()
                .put("voice", voice.name)
                .put("voice_id", voice.apiVoiceCode)
                .put("text", text)
                .put("format", "wav")
            TtsPayloadPreset.ELEVENLABS_STYLE -> JSONObject()
                .put("text", text)
                .put("model_id", "eleven_multilingual_v2")
                .put("voice", voice.apiVoiceCode)
        }

        val reqBuilder = Request.Builder()
            .url(endpointUrl)
            .post(jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))

        if (apiKey.isNotBlank()) {
            if (preset == TtsPayloadPreset.ELEVENLABS_STYLE) {
                reqBuilder.header("xi-api-key", apiKey)
            } else {
                reqBuilder.header("Authorization", "Bearer $apiKey")
            }
        }

        httpClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                val errBody = resp.body?.string().orEmpty().take(200)
                throw IllegalStateException("TTS endpoint error (${resp.code}): $errBody")
            }

            val contentType = resp.header("Content-Type").orEmpty().lowercase(Locale.US)
            val bytes = resp.body?.bytes() ?: throw IllegalStateException("Empty TTS audio response")

            if (contentType.contains("application/json")) {
                val json = JSONObject(String(bytes, Charsets.UTF_8))
                val b64 = json.optString("audioContent")
                    .ifBlank { json.optString("audio") }
                    .ifBlank { json.optString("data") }
                if (b64.isBlank()) {
                    throw IllegalStateException("TTS JSON response missing audio base64 field.")
                }
                val decoded = Base64.decode(b64, Base64.DEFAULT)
                FileOutputStream(outFile).use { it.write(decoded) }
            } else {
                FileOutputStream(outFile).use { it.write(bytes) }
            }
        }
    }

    private suspend fun initAndConfigureBuiltinTts(
        context: Context,
        voice: VoiceOption,
        targetLanguage: TargetLanguage,
        preferHighQualityOnline: Boolean
    ): TextToSpeech? = suspendCancellableCoroutine { cont ->
        var ttsRef: TextToSpeech? = null
        ttsRef = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val desiredLocale = localeForCode(targetLanguage.code)
                val langSupport = ttsRef?.setLanguage(desiredLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (langSupport == TextToSpeech.LANG_MISSING_DATA ||
                    langSupport == TextToSpeech.LANG_NOT_SUPPORTED
                ) {
                    val voiceLocale = localeForCode(voice.languageCode)
                    val voiceLangSupport = ttsRef?.setLanguage(voiceLocale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                    if (voiceLangSupport == TextToSpeech.LANG_MISSING_DATA ||
                        voiceLangSupport == TextToSpeech.LANG_NOT_SUPPORTED
                    ) {
                        ttsRef?.setLanguage(Locale.getDefault())
                    }
                }

                runCatching {
                    val availableVoices = ttsRef?.voices.orEmpty()
                    val bestDeviceVoice = selectBestDeviceVoice(
                        availableVoices = availableVoices,
                        preferredLangCode = targetLanguage.code,
                        voiceOption = voice,
                        preferHighQualityOnline = preferHighQualityOnline
                    )
                    if (bestDeviceVoice != null) {
                        ttsRef?.voice = bestDeviceVoice
                    }
                }

                ttsRef?.setPitch(voice.pitch)
                ttsRef?.setSpeechRate(voice.speechRate)

                if (cont.isActive) cont.resume(ttsRef)
            } else {
                if (cont.isActive) cont.resume(null)
            }
        }
        cont.invokeOnCancellation { runCatching { ttsRef?.shutdown() } }
    }

    private fun selectBestDeviceVoice(
        availableVoices: Set<Voice>,
        preferredLangCode: String,
        voiceOption: VoiceOption,
        preferHighQualityOnline: Boolean
    ): Voice? {
        if (availableVoices.isEmpty()) return null
        val langVoices = availableVoices.filter {
            it.locale.language.equals(preferredLangCode, ignoreCase = true) ||
                it.locale.language.equals(voiceOption.languageCode, ignoreCase = true)
        }
        val pool = langVoices.ifEmpty { availableVoices.toList() }
        val isMaleTarget = voiceOption.gender.contains("Nam", ignoreCase = true) ||
            voiceOption.gender.contains("Male", ignoreCase = true)

        return pool.sortedWith(
            compareByDescending<Voice> { v ->
                val nameLower = v.name.lowercase(Locale.US)
                val genderMatch = if (isMaleTarget) {
                    nameLower.contains("male") || nameLower.contains("-vid-") ||
                        nameLower.contains("-vic-") || nameLower.contains("b-local") ||
                        nameLower.contains("d-local") || nameLower.contains("b-network") ||
                        nameLower.contains("d-network")
                } else {
                    nameLower.contains("female") || nameLower.contains("-gft-") ||
                        nameLower.contains("-vie-") || nameLower.contains("a-local") ||
                        nameLower.contains("c-local") || nameLower.contains("a-network") ||
                        nameLower.contains("c-network")
                }
                if (genderMatch) 1 else 0
            }.thenByDescending { v ->
                if (preferHighQualityOnline) {
                    v.quality + (if (v.name.contains("network", ignoreCase = true)) 150 else 0)
                } else {
                    (if (!v.isNetworkConnectionRequired) 500 else 0) + v.quality
                }
            }
        ).firstOrNull()
    }

    private fun localeForCode(code: String): Locale = when (code.lowercase(Locale.US)) {
        "vi" -> Locale("vi", "VN")
        "en" -> Locale.US
        "es" -> Locale("es", "ES")
        "fr" -> Locale.FRENCH
        "ja" -> Locale.JAPANESE
        "ko" -> Locale.KOREAN
        "th" -> Locale("th", "TH")
        "id" -> Locale("in", "ID")
        else -> Locale.getDefault()
    }

    private suspend fun synthesizeViaSystemTts(
        tts: TextToSpeech,
        text: String,
        outFile: File
    ): Boolean = suspendCancellableCoroutine { cont ->
        val utteranceId = "utt_${System.nanoTime()}"
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId && cont.isActive) cont.resume(true)
            }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                if (id == utteranceId && cont.isActive) cont.resume(false)
            }
            override fun onError(id: String?, errorCode: Int) {
                if (id == utteranceId && cont.isActive) cont.resume(false)
            }
        })
        val params = Bundle()
        val result = tts.synthesizeToFile(text, params, outFile, utteranceId)
        if (result != TextToSpeech.SUCCESS && cont.isActive) {
            cont.resume(false)
        }
    }

    private fun decodeAudioFileToMono24kPcm(file: File): ShortArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(file.absolutePath)
            var audioIdx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val trackFmt = extractor.getTrackFormat(i)
                if (trackFmt.getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")) {
                    audioIdx = i
                    fmt = trackFmt
                    break
                }
            }
            if (audioIdx < 0 || fmt == null) return ShortArray(0)

            extractor.selectTrack(audioIdx)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            var srcSampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var srcChannels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            codec = MediaCodec.createDecoderByType(mime).apply {
                configure(fmt, null, null, 0)
                start()
            }

            val pcmOut = ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000L)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(inBuf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 10_000L)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFmt = codec.outputFormat
                    if (newFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        srcSampleRate = newFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    }
                    if (newFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        srcChannels = newFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                } else if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && info.size > 0) {
                        val chunk = ByteArray(info.size)
                        outBuf.position(info.offset)
                        outBuf.get(chunk)
                        pcmOut.write(chunk)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                }
            }

            val rawBytes = pcmOut.toByteArray()
            val shortCount = rawBytes.size / 2
            val rawShorts = ShortArray(shortCount)
            ByteBuffer.wrap(rawBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(rawShorts)

            val monoCount = shortCount / srcChannels.coerceAtLeast(1)
            val mono = ShortArray(monoCount) { i ->
                var sum = 0
                for (c in 0 until srcChannels) {
                    sum += rawShorts[i * srcChannels + c].toInt()
                }
                (sum / srcChannels.coerceAtLeast(1)).toShort()
            }

            if (srcSampleRate == MASTER_SAMPLE_RATE || mono.isEmpty()) return mono
            val outLen = ((mono.size.toLong() * MASTER_SAMPLE_RATE) / srcSampleRate.coerceAtLeast(8000)).toInt()
                .coerceAtLeast(1)
            return ShortArray(outLen) { i ->
                val srcPos = (i.toDouble() * srcSampleRate) / MASTER_SAMPLE_RATE
                val idx0 = srcPos.toInt().coerceIn(0, mono.lastIndex)
                val idx1 = (idx0 + 1).coerceIn(0, mono.lastIndex)
                val frac = srcPos - idx0
                ((mono[idx0] * (1.0 - frac)) + (mono[idx1] * frac)).toInt().toShort()
            }
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    private fun writeMonoWav(file: File, samples: ShortArray, sampleRate: Int) {
        val dataSize = samples.size * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray())
            putInt(36 + dataSize)
            put("WAVE".toByteArray())
            put("fmt ".toByteArray())
            putInt(16)
            putShort(1)
            putShort(1)
            putInt(sampleRate)
            putInt(sampleRate * 2)
            putShort(2)
            putShort(16)
            put("data".toByteArray())
            putInt(dataSize)
        }
        FileOutputStream(file).use { fos ->
            fos.write(header.array())
            val buf = ByteBuffer.allocate(minOf(dataSize, 32768)).order(ByteOrder.LITTLE_ENDIAN)
            var idx = 0
            while (idx < samples.size) {
                buf.clear()
                while (buf.hasRemaining() && idx < samples.size) {
                    buf.putShort(samples[idx++])
                }
                fos.write(buf.array(), 0, buf.position())
            }
        }
    }

    private fun computeWaveformPeaks(samples: ShortArray, buckets: Int): List<Float> {
        if (samples.isEmpty()) return emptyList()
        val step = (samples.size / buckets).coerceAtLeast(1)
        val raw = List(buckets) { b ->
            val start = (b * step).coerceIn(0, samples.lastIndex)
            val end = ((b + 1) * step).coerceAtMost(samples.size)
            var peak = 0
            for (i in start until end) {
                val v = abs(samples[i].toInt())
                if (v > peak) peak = v
            }
            peak / 32768f
        }
        val maxVal = raw.maxOrNull()?.coerceAtLeast(0.05f) ?: 0.05f
        return raw.map { (it / maxVal).coerceIn(0.05f, 1f) }
    }
}
